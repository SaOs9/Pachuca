<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catobjgeneral';
$error = '';

if(isset($_GET['idObjGeneral'])){
	$idObjGeneral = $_GET['idObjGeneral'];

	$stmt = $conn->prepare("SELECT * FROM pmd_catobjgeneral WHERE idObjGeneral = :idObjGeneral");
	$stmt->execute([
		':idObjGeneral' => $idObjGeneral
	]);
	
	if($stmt->rowCount() > 0){
		$row = $stmt->fetch(PDO::FETCH_OBJ);

		$stmt_obje = $conn->prepare("SELECT * FROM pmd_catobjestrategicos");
		$stmt_obje->execute();
	}else{
		header('Location: l_catobjgeneral');
	}
}else{
	header('Location: l_catobjgeneral');
}

if($_POST){
	$objEstrategicoId = trim($_POST['objEstrategicoId']);
	$cveObjGeneral = trim($_POST['cveObjGeneral']);
	$ObjGeneral = trim($_POST['ObjGeneral']);

	if(empty($objEstrategicoId) || empty($cveObjGeneral) || empty($ObjGeneral)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("UPDATE pmd_catobjgeneral SET objEstrategicoId = :objEstrategicoId,cveObjGeneral = :cveObjGeneral,ObjGeneral = :ObjGeneral WHERE idObjGeneral = :idObjGeneral");
		$stmt->execute([
			':objEstrategicoId' => $objEstrategicoId,
			':cveObjGeneral' => $cveObjGeneral,
			':ObjGeneral' => $ObjGeneral,
			':idObjGeneral' => $idObjGeneral
		]);
		header('Location: l_catobjgeneral?msg='.urlencode('Registro actualizado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">Estrategico</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Editar estrategico</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="objEstrategicoId" name="objEstrategicoId">
								<option value="">Seleccionar</option>
								<?php while($row_obje = $stmt_obje->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_obje->idObjEstrategico ?>"
										<?php echo $row_obje->idObjEstrategico == $row->objEstrategicoId ? 'selected' : '' ?>>
										<?php echo $row_obje->ObjEstrategico ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="objEstrategicoId">Objetivo estrategico</label>
						</div>
						<div class="form-floating mb-3">
							<input class="form-control" id="cveObjGeneral" name="cveObjGeneral" placeholder="Clave" value="<?php echo $row->cveObjGeneral ?>">
							<label for="cveObjGeneral">Clave</label>
						</div>
						<div class="form-floating mb-3">
							<textarea class="form-control" id="ObjGeneral" name="ObjGeneral" placeholder="Descripción"><?php echo $row->ObjGeneral ?></textarea>
							<label for="ObjGeneral">Objetivo general</label>
						</div>
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catobjgeneral';
$error = '';

//Y si existe //
if(isset($_SESSION['id_estrategico']) && !empty($_SESSION['id_estrategico'])){
	$identifica="WHERE idObjEstrategico='".$_SESSION['id_estrategico']."'";
	}else{$identifica=null;} 

	if(isset($_SESSION['id_eje']) && !empty($_SESSION['id_general'])){
		$identifica2="WHERE idEje='".$_SESSION['id_eje']."'";
		}else{$identifica2=null;} 

$stmt_obje = $conn->prepare("SELECT * FROM pmd_catobjestrategicos $identifica");
$stmt_eje = $conn->prepare("SELECT * FROM pmd_cateje");
$stmt_obje->execute();
$stmt_eje->execute();

if($_POST){
	$objEstrategicoId = trim($_POST['objEstrategicoId']);
	$cveObjGeneral = trim($_POST['cveObjGeneral']);
	$ObjGeneral = trim($_POST['ObjGeneral']);

	if(empty($objEstrategicoId) || empty($cveObjGeneral) || empty($ObjGeneral)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("INSERT INTO pmd_catobjgeneral (objEstrategicoId,cveObjGeneral,ObjGeneral) VALUES (:objEstrategicoId,:cveObjGeneral,:ObjGeneral)");
		$stmt->execute([
			':objEstrategicoId' => $objEstrategicoId,
			':cveObjGeneral' => $cveObjGeneral,
			':ObjGeneral' => $ObjGeneral
		]);
		$last_id=$conn->lastInsertId();
		$_SESSION['id_general']=$last_id;
		header('Location: l_catobjgeneral?msg='.urlencode('Registro creado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">Estrategico</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Crear Nuevo Objetivo General</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">

					<div class="form-floating mb-3">
							<select type="text" class="form-select" id="ejeId" name="ejeId">
								<option value="">Seleccionar</option>
								<?php while($row_eje = $stmt_eje->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_eje->idEje ?>">
										<?php echo $row_eje->eje ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="ejeId">Eje</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="objEstrategicoId" name="objEstrategicoId">
								<option value="">Seleccionar</option>
								<?php while($row_obje = $stmt_obje->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_obje->idObjEstrategico ?>">
										<?php echo $row_obje->ObjEstrategico ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="objEstrategicoId">Objetivo estrategico</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="cveObjGeneral" name="cveObjGeneral" placeholder="Clave">
							<label for="cveObjGeneral">Clave</label>
						</div>
						<div class="form-floating mb-3">
							<textarea class="form-control" id="ObjGeneral" name="ObjGeneral" placeholder="Descripción"></textarea>
							<label for="ObjGeneral">Objetivo general</label>
						</div>
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
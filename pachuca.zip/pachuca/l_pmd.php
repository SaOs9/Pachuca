<?php
require_once './php/connection.php';
require_once './php/security.php';
$menu = 'pmd';

if (!isset ($_GET['pagina'])) {  
    $pagina = 0;  
	$btn='<a class="next" href = "/l_pmd?pagina=1">Siguiente</a>'; 
} else {  
    $pagina = $_GET['pagina'];  
}

$results_per_page = 10;  
$offset = ($pagina) * $results_per_page;  
$res = $conn->query('SELECT COUNT(*) FROM pmd');
$num_rows = $res->fetchColumn();
$number_of_page = ceil ($num_rows / $results_per_page);  
if(isset($_GET['pagina'])){
$pagina++;
$btn='<a class="next" href = "/l_pmd?pagina='.$pagina.'">Siguiente</a>'; 
}
if(isset($_GET['pagina']) && $_GET['pagina']>$number_of_page-2){
$btn='<a class="next" href = "/l_pmd">Volver</a>'; 
}
if (!isset ($_GET['pagina'])){$offset=0;}

$stmt = $conn->prepare("
	SELECT p.*,u.unidadAdministrativa,a.alineaT,me.OdsMeta,i.pah_GDI_Indicador,c.procCalidad,l.lineaAccion,mu.municipio,g.grupoEdad,s.sector,z.genero
	FROM pmd p
	LEFT JOIN pmd_catunidadadmva u ON p.pmd_IdUnidadAdm = u.idUnidadAdm
	LEFT JOIN pmd_catalineat a ON p.pmd_idAlineaT = a.IdAlineaT
	LEFT JOIN pmd_catodsmetas me ON p.pmd_idOdsMetas = me.idOdsMetas
	LEFT JOIN pmd_catgdmi i ON p.pmd_GDMI_Id = i.pah_GDIM_Id
	LEFT JOIN pmd_catcalidad c ON p.pmd_idCalidad = c.idCalidad
	LEFT JOIN pmd_catlineaaccion l ON p.pmd_idLineaAccion = l.idLineaAccion
	LEFT JOIN pmd_municipio mu ON p.pmd_idMunicipio = mu.idMunicipio
	LEFT JOIN pmd_catgrupoedad g ON p.pmd_idGrupoEdad = g.idGrupoEdad
	LEFT JOIN pmd_catsectorp s ON p.pmd_idSectorP = s.idSectorP
	LEFT JOIN pmd_catgenero z ON p.pmd_idGenero = z.idGenero
	Limit 10 OFFSET ".$offset);
$stmt->execute();

if(isset($_POST['idPmd'])){
	$idPmd = $_POST['idPmd'];
	$stmt = $conn->prepare("DELETE FROM pmd WHERE idPmd = :idPmd");
	$stmt->execute([
		':idPmd' => $idPmd
	]);
	header('Location: l_pmd?msg='.urlencode('Registro eliminado'));
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tabla PMD</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css">
<script type="text/javascript" src="js/script.js"></script>
</head>

<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="./assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">
			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">PMD</h1>
				</div>
				<style>
                 tbody.datos {
                   background-color: #f0f8ff8f;
                  padding: 1px;
                 box-shadow: inset 0px 0px 7px 0px #2196f3;
                   }
				   input#busca {
                   border: 0;
                   width: 210px;
                   background-color: #212529;
                   color: white;
                   border-right: 1px solid #444;
                }
				form#sender {
                  display: flex;
                  width: 100%;
                }
				a.next {
					text-align: center;
                     float: right;
                     padding: 7px;
                     background-color: #212529;
                     border: 0;
                     border-radius: 5px;
                     color: white;
                     width: 101px;
                     height: 37px;
                     text-decoration: none;
                }
				</style>
				
				
				<?php 
				echo$btn;
				if(isset($_GET['msg'])): ?>
				<div class="alert alert-success">
					<i class="fa fa-exclamation-circle"></i> <?php echo $_GET['msg'] ?>
				</div>				
				<?php endif; ?>
				<a href="c_pmd" class="btn btn-dark mb-4">
					<i class="fa fa-plus"></i> Nuevo
				</a>
				<div class="table-responsive">
					<table class="table table-striped align-middle dataTable">
						<thead class="table-dark">
							<tr>
								<th>ID</th>
								<th>Unidad Administrativa</th>
								<th>Alineat</th>
								<th>Meta</th>
								<th>Indicador</th>
								<th>Calidad</th>
								<th>Linea de Acción</th>
								<th>Municipio</th>
								<th>Grupo de Edad</th>
								<th>Genero</th>
								<th>SectorP</th>
								<th></th>
							</tr>

						<div class="row text-center" id="idPmd" style="position: absolute;top: 140px;left: 50%">
						</div>

						<div class="filter-group">
							<label>Unidad Administrativa</label>
							<select class="form-control" id="idPmd" onchange="load(1);"> 
								<option value="">Todas</option>
								<option value="Asamblea Municipal">Asamblea Municipal</option>
								<option value="Sindicaturas">Sindicaturas</option>
								<option value="Oficialía Mayor">Oficialía Mayor</option>
								<option value="Dirección de Giras y Logística">Dirección de Giras y Logística</option>
								<option value="Dirección de Atención Telefónica SERVITEL">Dirección de Atención Telefónica SERVITEL</option>
								<option value="Particular">Particular</option>
								<option value="Secretaria Particular">Secretaria Particular</option>
								<option value="SIPPINA">SIPPINA</option>
								<option value="Dirección General Jurídica">Dirección General Jurídica</option>
								<option value="Dirección de lo Contencioso">Dirección de lo Contencioso</option>
								<option value="Dirección de la Oficialía del Registro del Estado">Dirección de la Oficialía del Registro del Estado</option>
								<option value="Dirección de Desarrollo Político">Dirección de Desarrollo Político</option>
								<option value="Dirección de Vinculación Ciudadana">Dirección de Vinculación Ciudadana</option>						
								<option value="Dirección de Reglamentos y Espectáculos">Dirección de Reglamentos y Espectáculos</option>		
								<option value="Dirección de Protección Civil, Bomberos y Gestión">Dirección de Protección Civil, Bomberos y Gestión</option>

							</select>
						</div>

						
						<div class="filter-group">
							<label>AlineaT</label>
							<select class="form-control" id="idPmd" onchange="load(1);"> 
								<option value="">Todos</option>
								<option value="Desarrollo y Protección de los Derechos de Niñas">Desarrollo y Protección de los Derechos de Niñas</option>
								<option value="Equidad de genero SIPINNA">Equidad de genero SIPINNA</option>
								<option value="Innovación y desarrollo sostenible">Innovación y desarrollo sostenible</option>								
							</select>
						</div>

						<div class="filter-group">
							<label>Indicador</label>
							<select class="form-control" id="idPmd" onchange="load(1);"> 
								<option value="">Todos</option>
								<option value="Bando de Policía y Gobierno">Bando de Policía y Gobierno</option>
								<option value="Manuales de Organización">Manuales de Organización</option>
								<option value="Tabulador de sueldos o documentos con la estructur">Tabulador de sueldos o documentos con la estructur</option>
								<option value="Unidades administrativas existentes en función de">Unidades administrativas existentes en función de</option>
								<option value="Servidores públicos por cada 1,000 habitantes">Servidores públicos por cada 1,000 habitantes</option>								
							</select>
						</div>

						<div class="filter-group">
							<label>Calidad</label>
							<select class="form-control" id="location" onchange="load(1);"> 
								<option value="">Todos</option>
								<option value="Adquisición de bienes y servicios">Adquisición de bienes y servicios</option>
								<option value="Atención de quejas, denuncias y financiamiento de">Atención de quejas, denuncias y financiamiento de</option>
								<option value="Atención para el Desarrollo Integral de la Familia">Atención para el Desarrollo Integral de la Familia</option>
								<option value="Atención y apoyo a las mujeres de Pachuca">Atención y apoyo a las mujeres de Pachuca</option>
								<option value="Atención y tratamiento a solicitudes de información">Atención y tratamiento a solicitudes de información</option>
																
								<option value="C-2 Centro de comando y comunicaciones">C-2 Centro de comando y comunicaciones</option>
								<option value="Constancia, autorización y reconocimiento de actos">Constancia, autorización y reconocimiento de actos</option>
								<option value="Control y revisión a la obtención y aplicación de">Atención para el Desarrollo Integral de la Familia</option>
								<option value="Atención y apoyo a las mujeres de Pachuca">Control y revisión a la obtención y aplicación de</option>
								<option value="Dictamen ambiental para regularización de establec">Dictamen ambiental para regularización de establec</option>								
																
							</select>
						</div>

						
						</thead>
						<tbody class="datos"> </tbody> <tbody>
							<?php while($row = $stmt->fetch(PDO::FETCH_OBJ)): ?>
							<tr>
								<td><?php echo $row->idPmd ?></td>
								<td><?php echo $row->unidadAdministrativa ?></td>
								<td><?php echo $row->alineaT ?></td>
								<td><?php echo $row->OdsMeta ?></td>
								<td><?php echo $row->pah_GDI_Indicador ?></td>
								<td><?php echo $row->procCalidad ?></td>
								<td><?php echo $row->lineaAccion ?></td>
								<td><?php echo $row->municipio ?></td>
								<td><?php echo $row->grupoEdad ?></td>
								<td><?php echo $row->genero ?></td>
								<td><?php echo $row->sector ?></td>
								<td>
									<div class="d-flex gap-2"> 
										<a href="e_pmd?idPmd=<?php echo $row->idPmd ?>" class="btn btn-dark btn-sm"><i class="fa fa-pencil"></i></a>
										<form method="POST">
											<input type="hidden" name="idPmd" value="<?php echo $row->idPmd ?>">
											<button class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar?')"><i class="fa fa-trash-alt"></i></button>
										</form>
									</div>
								</td>
							</tr>
							<?php endwhile; ?>
						</tbody>
					</table>
				</div>
			</main>
		</div>
	</div>
	<div class="tipo" id="pmd"></div>
	<?php
     echo$btn;
	require_once './inc/script.php' 
	?>
</body>
</html>
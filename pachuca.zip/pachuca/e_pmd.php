<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'pmd';
$error = '';

$stmt_u = $conn->query("SELECT * FROM pmd_catunidadadmva");
$stmt_a = $conn->query("SELECT * FROM pmd_catalineat");
$stmt_me = $conn->query("SELECT * FROM pmd_catodsmetas");
$stmt_i = $conn->query("SELECT * FROM pmd_catgdmi");
$stmt_c = $conn->query("SELECT * FROM pmd_catcalidad");
$stmt_l = $conn->query("SELECT * FROM pmd_catlineaaccion");
$stmt_mu = $conn->query("SELECT * FROM pmd_municipio");
$stmt_g = $conn->query("SELECT * FROM pmd_catgrupoedad");
$stmt_z = $conn->query("SELECT * FROM pmd_catgenero");
$stmt_s = $conn->query("SELECT * FROM pmd_catsectorp");


$row;
if (isset($_GET['idPmd'])) {
	$idPmd = $_GET['idPmd'];
	$stmt = $conn->prepare("SELECT * FROM pmd WHERE idPmd = :idPmd");
	$stmt->execute([
		':idPmd' => $idPmd
	]);

	if ($stmt->rowCount() > 0) {
		$row = $stmt->fetch(PDO::FETCH_OBJ);
	}
}


if ($_POST) {
	$pmd_IdUnidadAdm = trim($_POST['pmd_IdUnidadAdm']);
	$pmd_idAlineaT = trim($_POST['pmd_idAlineaT']);
	$pmd_idOdsMetas = trim($_POST['pmd_idOdsMetas']);
	$pmd_GDMI_Id = trim($_POST['pmd_GDMI_Id']);
	$pmd_idCalidad = trim($_POST['pmd_idCalidad']);
	$pmd_idLineaAccion = trim($_POST['pmd_idLineaAccion']);
	$pmd_idMunicipio = trim($_POST['pmd_idMunicipio']);
	$pmd_idGrupoEdad = trim($_POST['pmd_idGrupoEdad']);
	$pmd_idSectorP = trim($_POST['pmd_idSectorP']);
	$pmd_idGenero = trim($_POST['pmd_idGenero']);


	if (empty($pmd_IdUnidadAdm) || empty($pmd_idAlineaT) || empty($pmd_idOdsMetas) || empty($pmd_GDMI_Id) || empty($pmd_idCalidad) || empty($pmd_idLineaAccion) || empty($pmd_idMunicipio) || empty($pmd_idGrupoEdad) || empty($pmd_idSectorP) || empty($pmd_idGenero)) {
		$error = 'Todos los campos son requeridos';
	} else {
		$stmt = $conn->prepare("UPDATE pmd SET 
		pmd_IdUnidadAdm = :pmd_IdUnidadAdm,
		pmd_idAlineaT= :pmd_idAlineaT,
		pmd_idOdsMetas= :pmd_idOdsMetas,
		pmd_GDMI_Id= :pmd_GDMI_Id,
		pmd_idCalidad= :pmd_idCalidad,
		pmd_idLineaAccion= :pmd_idLineaAccion,
		pmd_idMunicipio= :pmd_idMunicipio,
		pmd_idGrupoEdad= :pmd_idGrupoEdad,
		pmd_idGenero= :pmd_idGenero,
		pmd_idSectorP= :pmd_idSectorP 
		WHERE idPmd = :idPmd");

		$stmt->execute([
			':pmd_IdUnidadAdm' => $pmd_IdUnidadAdm,
			':pmd_idAlineaT' => $pmd_idAlineaT,
			':pmd_idOdsMetas' => $pmd_idOdsMetas,
			':pmd_GDMI_Id' => $pmd_GDMI_Id,
			':pmd_idCalidad' => $pmd_idCalidad,
			':pmd_idLineaAccion' => $pmd_idLineaAccion,
			':pmd_idMunicipio' => $pmd_idMunicipio,
			':pmd_idGrupoEdad' => $pmd_idGrupoEdad,
			':pmd_idGenero' => $pmd_idGenero,
			':pmd_idSectorP' => $pmd_idSectorP,
			':idPmd'=> $idPmd
		]);
		header('Location: l_pmd?msg=' . urlencode('Registro Editado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>

<body>

	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">PMD</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Editar el PMD</h5>
					<?php if (!empty($error)) : ?>
						<div class="alert alert-danger">
							<?php echo $error ?>
						</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_IdUnidadAdm" name="pmd_IdUnidadAdm">
								<option value="">Seleccionar</option>
								<?php while ($row_u = $stmt_u->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_u->idUnidadAdm ?>" <?php if ($row_u->idUnidadAdm == $row->pmd_IdUnidadAdm) {
																							echo "selected";
																						} ?>>
										<?php echo $row_u->unidadAdministrativa ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_IdUnidadAdm">Unidad administrativa</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_idAlineaT" name="pmd_idAlineaT">
								<option value="">Seleccionar</option>
								<?php while ($row_a = $stmt_a->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_a->IdAlineaT ?>" <?php if ($row_a->IdAlineaT == $row->pmd_idAlineaT) {
																						echo "selected";
																					} ?>>
										<?php echo $row_a->alineaT ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_idAlineaT">Alineat</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_idOdsMetas" name="pmd_idOdsMetas">
								<option value="">Seleccionar</option>
								<?php while ($row_me = $stmt_me->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_me->idOdsMetas ?>" <?php if ($row_me->idOdsMetas == $row->pmd_idOdsMetas) {
																							echo "selected";
																						} ?>>
										<?php echo $row_me->OdsMeta ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_idOdsMetas">Meta</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_GDMI_Id" name="pmd_GDMI_Id">
								<option value="">Seleccionar</option>
								<?php while ($row_i = $stmt_i->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_i->pah_GDIM_Id ?>" <?php if ($row_i->pah_GDIM_Id == $row->pmd_GDMI_Id) {
																							echo "selected";
																						} ?>>
										<?php echo $row_i->pah_GDI_Indicador ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_GDMI_Id">Indicador</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_idCalidad" name="pmd_idCalidad">
								<option value="">Seleccionar</option>
								<?php while ($row_c = $stmt_c->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_c->idCalidad ?>" <?php if ($row_c->idCalidad == $row->pmd_idCalidad) {
																						echo "selected";
																					} ?>>
										<?php echo $row_c->procCalidad ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_idCalidad">Calidad</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_idLineaAccion" name="pmd_idLineaAccion">
								<option value="">Seleccionar</option>
								<?php while ($row_l = $stmt_l->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_l->idLineaAccion ?> " <?php if ($row_l->idLineaAccion == $row->pmd_idLineaAccion) {
																								echo "selected";
																							} ?>>
										<?php echo $row_l->lineaAccion ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_idLineaAccion">Linea de acción</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_idMunicipio" name="pmd_idMunicipio">
								<option value="">Seleccionar</option>
								<?php while ($row_mu = $stmt_mu->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_mu->idMunicipio ?>" <?php if ($row_mu->idMunicipio == $row->pmd_idMunicipio) {
																							echo "selected";
																						} ?>>
										<?php echo $row_mu->municipio ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_idMunicipio">Municipio</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_idGrupoEdad" name="pmd_idGrupoEdad">
								<option value="">Seleccionar</option>
								<?php while ($row_g = $stmt_g->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_g->idGrupoEdad ?>" <?php if ($row_g->idGrupoEdad == $row->pmd_idGrupoEdad) {
																							echo "selected";
																						} ?>>
										<?php echo $row_g->grupoEdad ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_idGrupoEdad">Grupo de edad</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_idSectorP" name="pmd_idSectorP">
								<option value="">Seleccionar</option>
								<?php while ($row_s = $stmt_s->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_s->idSectorP ?>" <?php if ($row_s->idSectorP == $row->pmd_idSectorP) {
																						echo "selected";
																					} ?>>
										<?php echo $row_s->sector ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_idSectorP">SectorP</label>
						</div>

						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pmd_idGenero" name="pmd_idGenero">
								<option value="">Seleccionar</option>
								<?php while ($row_z = $stmt_z->fetch(PDO::FETCH_OBJ)) : ?>
									<option value="<?php echo $row_z->idGenero ?>" <?php if ($row_z->idGenero == $row->pmd_idGenero) {
																						echo "selected";
																					} ?>>
										<?php echo $row_z->genero ?>
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pmd_idGenero">Genero</label>
						</div>

						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>

</html>
<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catobjestrategicos';
$error = '';

if(isset($_GET['idObjEstrategico'])){
	$idObjEstrategico = $_GET['idObjEstrategico'];
	$stmt = $conn->prepare("SELECT * FROM pmd_catobjestrategicos WHERE idObjEstrategico = :idObjEstrategico");
	$stmt->execute([
		':idObjEstrategico' => $idObjEstrategico
	]);

	if($stmt->rowCount() > 0){
		$row = $stmt->fetch(PDO::FETCH_OBJ);

		$stmt_eje = $conn->prepare("SELECT * FROM pmd_cateje ORDER BY idEje ASC");
		$stmt_eje->execute();
	}else{
		header('Location: l_catobjestrategicos');
	}
}else{
	header('Location: l_catobjestrategicos');
}

if($_POST){
	$ejeId = trim($_POST['ejeId']);
	$cveObjEstrategico = trim($_POST['cveObjEstrategico']);
	$ObjEstrategico = trim($_POST['ObjEstrategico']);

	if(empty($ejeId) || empty($cveObjEstrategico) || empty($ObjEstrategico)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("UPDATE pmd_catobjestrategicos SET ejeId = :ejeId, cveObjEstrategico = :cveObjEstrategico, ObjEstrategico = :ObjEstrategico WHERE idObjEstrategico = :idObjEstrategico");
		$stmt->execute([
			':ejeId' => $ejeId,
			':cveObjEstrategico' => $cveObjEstrategico,
			':ObjEstrategico' => $ObjEstrategico,
			':idObjEstrategico' => $idObjEstrategico
		]);
		header('Location: l_catobjestrategicos?msg='.urlencode('Registro actualizado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">Subejes</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Editar subeje</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="ejeId" name="ejeId">
								<option value="">Seleccionar</option>
								<?php while($row_eje = $stmt_eje->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_eje->idEje  ?>" <?php echo $row_eje->idEje  == $row->ejeId ? 'selected' : '' ?>>
										<?php echo $row_eje->eje ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="ejeId">Eje</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="cveObjEstrategico" name="cveObjEstrategico" placeholder="Clave" value="<?php echo $row->cveObjEstrategico ?>">
							<label for="cveObjEstrategico">Clave</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="ObjEstrategico" name="ObjEstrategico" placeholder="Nombre" value="<?php echo $row->ObjEstrategico ?>">
							<label for="ObjEstrategico">Nombre</label>
						</div>
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catgdmm';

$error = '';

if($_POST){
	$pah_GDM_Modulo = trim($_POST['pah_GDM_Modulo']);

	if(empty($pah_GDM_Modulo)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("INSERT INTO pmd_catgdmm (pah_GDM_Modulo) VALUES (:pah_GDM_Modulo)");
		$stmt->execute([
			'pah_GDM_Modulo' => $pah_GDM_Modulo
		]);
		header('Location: l_catgdmm?msg='.urlencode('Registro creado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">GDMM</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Crear Nuevo Modulo</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="pah_GDM_Modulo" name="pah_GDM_Modulo" placeholder="Nombre">
							<label for="pah_GDM_Modulo">Módulo</label>
						</div>
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
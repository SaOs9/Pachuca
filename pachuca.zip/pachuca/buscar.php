<?php 
require_once './php/db-li.php';
$myRow=[];
if (isset($_POST['bs'])) { 
$q=htmlspecialchars($_POST['bs']);
$tipo=htmlspecialchars($_POST['tipo']);
if($tipo=='pmd'){
$db="pmd_catunidadadmva WHERE unidadAdministrativa";
}
$sql="SELECT * FROM $db LIKE LOWER('%$q%')";
$resultado=$conexion->query($sql);
while ($row = $resultado->fetch_assoc()) {
$stmt_x = $conexion->query("SELECT * FROM pmd WHERE pmd_IdUnidadAdm  ='".$row['idUnidadAdm']."'"); $x=$stmt_x->fetch_array();
$stmt_a = $conexion->query("SELECT * FROM pmd_catalineat WHERE 	IdAlineaT  ='".$x['pmd_idAlineaT']."'"); 
if(!empty($stmt_a) && $stmt_a->num_rows>0){
    $a=$stmt_a->fetch_array();
}else {
    $a['alineaT'] = "";
}
$stmt_me = $conexion->query("SELECT * FROM pmd_catodsmetas WHERE idOdsMetas ='".$x['pmd_idOdsMetas']."'");
$b=$stmt_me->fetch_array();

$stmt_i = $conexion->query("SELECT * FROM pmd_catgdmi WHERE pah_GDIM_Id  ='".$x['pmd_GDMI_Id']."'");
if(!empty($stmt_i) && $stmt_i->num_rows>0){
    $c=$stmt_i->fetch_array();
}else {
    $c['pah_GDI_Indicador'] = "";
}

$stmt_c = $conexion->query("SELECT * FROM pmd_catcalidad WHERE idCalidad  ='".$x['pmd_idCalidad']."'");
if(!empty($stmt_c) && $stmt_c->num_rows>0){
    $d=$stmt_c->fetch_array();
}else {
    $d['procCalidad'] = "";
}
$stmt_l = $conexion->query("SELECT * FROM pmd_catlineaaccion WHERE idLineaAccion ='".$x['pmd_idLineaAccion']."'");
$e=$stmt_l->fetch_array();

$stmt_mu = $conexion->query("SELECT * FROM pmd_municipio WHERE idMunicipio  ='".$x['pmd_idMunicipio']."'");
$f=$stmt_mu->fetch_array();

$stmt_g = $conexion->query("SELECT * FROM pmd_catgrupoedad WHERE idGrupoEdad ='".$x['pmd_idGrupoEdad']."'");
$g=$stmt_g->fetch_array();

$stmt_z = $conexion->query("SELECT * FROM pmd_catgenero WHERE idGenero ='".$x['pmd_idGenero']."'");
$h=$stmt_z->fetch_array();

$stmt_s = $conexion->query("SELECT * FROM pmd_catsectorp WHERE idSectorP  ='".$x['pmd_idSectorP']."'");
$j=$stmt_s->fetch_array();
        if(!empty($x['idPmd'])){
        $myRow['row'][]= array(
            "id"=>$x['idPmd'],
            "unidad"=>$row['unidadAdministrativa'],
            "alineat"=>$a['alineaT'],
            "meta"=>$b['OdsMeta'],
            "indicador"=>$c['pah_GDI_Indicador'],
            "calidad"=>$d['procCalidad'],
            "accion"=>$e['lineaAccion'],
            "municipio"=>$f['municipio'],
            "edad"=>$g['grupoEdad'],
            "genero"=>$h['genero'],
            "sector"=>$j['sector'],
            "botones"=>"<div class='d-flex gap-2'> 
            <a href='e_pmd?idPmd=".$x['idPmd']." ' class='btn btn-dark btn-sm'><i class='fa fa-pencil'></i></a>
            <form method='POST'>
            <input type='hidden' name='idPmd' value='".$x['idPmd']."'>
            <button class='btn btn-danger btn-sm' onclick='return confirm('¿Eliminar?')'><i class='fa fa-trash-alt'></i></button>
            </form> 
            </div>");  
        }
}
$myArray['posts']= $myRow; 
echo json_encode($myArray);
}



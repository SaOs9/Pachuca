create database pachucaw_pmd;
use pachucaw_pmd;


-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 08-11-2021 a las 15:50:50
-- Versión del servidor: 5.7.36
-- Versión de PHP: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pachucaw_pmd`
--

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `dependenciasPmd`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `dependenciasPmd` (
`idPmd` int(11)
,`unidadAdministrativaNue` varchar(11)
,`unidadAdministrativa` varchar(254)
,`dependenciaNue` int(11)
,`dependencia` varchar(254)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `ejesPmd`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `ejesPmd` (
`idPmd` int(11)
,`idEje` int(11)
,`eje` varchar(80)
,`cveObjEstrategico` varchar(11)
,`ObjEstrategico` varchar(80)
,`cveObjGeneral` varchar(11)
,`ObjGeneral` varchar(400)
,`cveLineaAccion` varchar(11)
,`lineaAccion` varchar(500)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `guiaPmd`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `guiaPmd` (
`idPmd` int(11)
,`pah_GDMI_Clave` varchar(8)
,`pah_GDI_Indicador` varchar(254)
,`pah_GDMT_Clave` varchar(8)
,`pah_GDMT_Numero` int(11)
,`pah_GDMT_Tema` varchar(254)
,`pah_GDM_Modulo` varchar(80)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `municipioPmd`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `municipioPmd` (
`idPmd` int(11)
,`municipio` varchar(254)
,`entidad` varchar(254)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `odsPmd`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `odsPmd` (
`idPmd` int(11)
,`objetivoOdsId` int(11)
,`cveOdsMetas` varchar(8)
,`OdsMeta` mediumtext
,`OdsObjetivo` varchar(254)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `otrosPmd`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `otrosPmd` (
`idPmd` int(11)
,`procCalidad` varchar(350)
,`alineaT` varchar(254)
,`grupoEdad` varchar(254)
,`genero` varchar(254)
,`sector` varchar(254)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd`
--

CREATE TABLE `pmd` (
  `idPmd` int(11) NOT NULL,
  `pmd_IdUnidadAdm` int(11) DEFAULT NULL,
  `pmd_idAlineaT` int(11) DEFAULT NULL,
  `pmd_idOdsMetas` int(11) DEFAULT NULL,
  `pmd_GDMI_Id` int(11) DEFAULT NULL,
  `pmd_idCalidad` int(11) DEFAULT NULL,
  `pmd_idLineaAccion` int(11) DEFAULT NULL,
  `pmd_idMunicipio` int(11) DEFAULT NULL,
  `pmd_idGrupoEdad` int(11) DEFAULT NULL,
  `pmd_idGenero` int(11) DEFAULT NULL,
  `pmd_idSectorP` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd`
--

INSERT INTO `pmd` (`idPmd`, `pmd_IdUnidadAdm`, `pmd_idAlineaT`, `pmd_idOdsMetas`, `pmd_GDMI_Id`, `pmd_idCalidad`, `pmd_idLineaAccion`, `pmd_idMunicipio`, `pmd_idGrupoEdad`, `pmd_idGenero`, `pmd_idSectorP`) VALUES
(5, 4, NULL, 145, NULL, NULL, 18, 48, 2, 4, 4),
(6, 4, NULL, 145, NULL, NULL, 19, 48, 4, 4, 6),
(7, 5, 3, 80, 128, 23, 20, 48, 4, 4, 6),
(8, 5, 3, 80, 128, 23, 21, 48, 4, 4, 6),
(9, 6, NULL, 139, 129, NULL, 22, 48, 4, 4, 6),
(15, 7, 3, 139, NULL, NULL, 23, 48, 4, 4, 6),
(16, 7, 3, 168, NULL, NULL, 24, 48, 4, 4, 6),
(17, 50, 3, 80, NULL, NULL, 32, 48, 4, 4, 4),
(18, 50, 3, 80, 111, NULL, 33, 48, 4, 4, 4),
(19, 50, 3, 80, 113, NULL, 34, 48, 4, 4, 4),
(20, 51, 3, 76, 85, 13, 50, 48, 4, 4, 4),
(21, 51, 3, 57, NULL, 13, 51, 48, 4, 4, 4),
(22, 51, 3, 80, 85, 13, 35, 48, 4, 4, 4),
(23, 52, 3, 80, NULL, NULL, 36, 48, 4, 4, 4),
(24, 52, 3, 80, NULL, NULL, 37, 48, 4, 4, 4),
(25, 52, 3, 79, NULL, 16, 38, 48, 4, 4, 4),
(26, 53, 3, 143, NULL, 1, 13, 48, 4, 4, 4),
(27, 54, 3, 65, NULL, 12, 1, 48, 4, 4, 4),
(28, 54, 3, 31, 18, 12, 52, 48, 4, 4, 4),
(29, 54, 3, 63, 1, NULL, 60, 48, 4, 4, 4),
(30, 23, NULL, 144, 13, 9, 2, 48, 4, 4, 4),
(31, 23, NULL, 144, 130, 9, 3, 48, 4, 4, 4),
(32, 23, NULL, 144, 13, 9, 4, 48, 4, 4, 4),
(33, 24, NULL, 143, 15, 9, 5, 48, 4, 4, 4),
(34, 24, NULL, 144, 14, 9, 6, 48, 4, 4, 4),
(35, 24, NULL, 144, 13, 9, 7, 48, 4, 4, 4),
(36, 25, NULL, 144, 13, 2, 8, 48, 4, 4, 4),
(37, 25, NULL, 144, 13, 2, 9, 48, 4, 4, 4),
(38, 26, 3, 80, 13, 9, 47, 48, 4, 4, 4),
(39, 27, NULL, 144, 125, 5, 64, 48, 4, 4, 4),
(40, 27, NULL, 139, 123, 5, 65, 48, 4, 4, 4),
(41, 27, NULL, 139, 126, 5, 66, 48, 4, 4, 4),
(42, 28, NULL, 144, 13, 2, 10, 48, 4, 4, 4),
(43, 28, NULL, 143, 14, 2, 14, 48, 4, 4, 4),
(44, 9, NULL, 145, NULL, NULL, 67, 48, 4, 4, 6),
(45, 10, NULL, 145, NULL, NULL, 68, 48, 4, 4, 4),
(46, 10, NULL, 145, NULL, NULL, 69, 48, 2, 1, 6),
(47, 11, 2, 147, 58, 8, 53, 48, 4, 4, 4),
(48, 11, 2, 147, 58, 8, 39, 48, 4, 4, 4),
(49, 11, 2, 147, 58, 8, 61, 48, 4, 4, 4),
(50, 11, 2, 147, 58, 8, 40, 48, 2, 3, 6),
(51, 11, 2, 147, 58, 8, 70, 48, 2, 3, 6),
(52, 11, 2, 147, 58, 8, 41, 48, 4, 4, 6),
(53, 11, 2, 147, 58, 8, 42, 48, 4, 4, 4),
(54, 12, 3, 145, NULL, NULL, 25, 48, 4, 4, 4),
(55, 12, 3, 82, NULL, NULL, 26, 48, 4, 4, 4),
(56, 13, NULL, 145, NULL, NULL, 27, 48, 4, 4, 4),
(57, 13, NULL, 145, NULL, NULL, 15, 48, 4, 4, 4),
(58, 14, 3, 63, NULL, 19, 16, 48, 4, 4, 4),
(59, 14, 3, 63, NULL, 20, 28, 48, 4, 4, 4),
(60, 16, 3, 144, NULL, 18, 29, 48, 4, 4, 6),
(61, 16, 3, 144, NULL, 18, 30, 48, 4, 4, 6),
(62, 34, NULL, 93, 113, NULL, 43, 48, 4, 4, 6),
(63, 34, NULL, 93, 113, NULL, 44, 48, 4, 4, 6),
(64, 39, NULL, 144, 54, NULL, 54, 48, 4, 4, 4),
(65, 17, 3, 80, 23, 6, 17, 48, 4, 4, 4),
(66, 18, NULL, 151, 25, NULL, 11, 48, 4, 4, 4),
(67, 18, NULL, 151, 27, NULL, 82, 48, 4, 4, 4),
(68, 18, NULL, 144, 27, NULL, 62, 48, 4, 4, 4),
(69, 18, NULL, 144, 27, NULL, 83, 48, 4, 4, 4),
(70, 18, NULL, 144, 27, NULL, 84, 48, 4, 4, 4),
(71, 18, NULL, 143, NULL, NULL, 85, 48, 4, 4, 4),
(72, 19, NULL, 144, NULL, 11, 48, 48, 4, 4, 4),
(73, 19, NULL, 144, 29, 11, 86, 48, 4, 4, 4),
(74, 19, NULL, 144, 29, 11, 87, 48, 4, 4, 4),
(96, 20, NULL, 144, 28, NULL, 88, 48, 4, 4, 4),
(97, 20, NULL, 144, 29, NULL, 89, 48, 4, 4, 4),
(98, 20, NULL, 144, 29, NULL, 55, 48, 4, 4, 4),
(99, 20, NULL, 159, 28, NULL, 90, 48, 4, 4, 4),
(100, 42, NULL, 167, NULL, NULL, 72, 48, 4, 4, 6),
(101, 1, NULL, 141, NULL, NULL, 12, 48, 4, 4, 4),
(102, 1, NULL, 139, NULL, NULL, 31, 48, 4, 4, 6),
(103, 2, NULL, 144, NULL, NULL, 91, 48, 2, 4, 6),
(104, 2, NULL, 139, NULL, NULL, 71, 48, 2, 4, 4),
(105, 3, NULL, 139, NULL, NULL, 56, 48, 2, 4, 6),
(106, 68, NULL, 159, NULL, NULL, 57, 48, 4, 4, 6),
(107, 73, NULL, 144, NULL, NULL, 58, 48, 2, 4, 4),
(108, 21, NULL, 164, 11, NULL, 92, 48, 4, 4, 4),
(109, 21, NULL, 168, 10, NULL, 93, 48, 4, 4, 4),
(110, 21, NULL, 169, 2, NULL, 63, 48, 4, 4, 4),
(111, 21, NULL, 159, 13, NULL, 79, 48, 4, 4, 4),
(112, 21, NULL, 159, 13, NULL, 80, 48, 4, 4, 4),
(113, 21, NULL, 159, 9, NULL, 94, 48, 4, 4, 4),
(114, 21, NULL, 169, 9, NULL, 95, 48, 4, 4, 4),
(115, 21, NULL, 169, 9, NULL, 81, 48, 4, 4, 4),
(116, 21, NULL, 169, NULL, NULL, 49, 48, 4, 4, 4),
(137, 22, NULL, 4, NULL, 24, 45, 48, 4, 4, 4),
(138, 22, NULL, NULL, NULL, NULL, 73, 48, 4, 4, 4),
(139, 22, NULL, 159, 9, 24, 96, 48, 4, 4, 4),
(140, 22, NULL, 79, NULL, 24, 46, 48, 4, 4, 4),
(141, 64, NULL, 159, NULL, NULL, 74, 48, 4, 4, 4),
(142, 64, NULL, 159, NULL, NULL, 75, 48, 4, 4, 4),
(143, 64, NULL, 159, NULL, NULL, 76, 48, 4, 4, 4),
(144, 64, NULL, 159, NULL, NULL, 77, 48, 4, 4, 4),
(145, 64, NULL, 159, NULL, NULL, 78, 48, 4, 4, 4),
(146, 21, NULL, 159, 9, NULL, 59, 48, 4, 4, 4),
(149, 8, 1, 152, 96, NULL, 190, 48, 1, 4, 5),
(150, 8, 1, 152, 97, NULL, 191, 48, 1, 4, 5),
(151, 8, 1, 141, 97, NULL, 192, 48, 1, 4, 5),
(152, 8, 1, 145, 97, NULL, 193, 48, 1, 4, 5),
(153, 8, 1, 140, 97, NULL, 194, 48, 1, 4, 5),
(154, 8, 1, 145, 97, NULL, 195, 48, 1, 4, 5),
(155, 8, 1, 152, 97, NULL, 196, 48, 1, 4, 5),
(156, 48, 3, 66, 120, NULL, 97, 48, 2, 4, 6),
(157, 48, 3, 63, 120, NULL, 98, 48, 2, 4, 6),
(158, 48, 3, 63, 117, NULL, 99, 48, 2, 4, 2),
(159, 48, 3, 63, 117, NULL, 101, 48, 2, 4, 2),
(160, 48, 3, 63, NULL, NULL, 100, 48, 2, 4, 2),
(161, 48, 3, 63, NULL, 22, 102, 48, 2, 4, 2),
(162, 48, 3, 168, 116, NULL, 103, 48, 2, 4, 2),
(163, 48, 3, 167, 121, NULL, 104, 48, 2, 4, 2),
(164, 48, 3, 167, 122, NULL, 105, 48, 2, 4, 2),
(165, 49, 3, 69, NULL, NULL, 113, 48, 2, 4, 2),
(166, 49, 3, 62, NULL, NULL, 114, 48, 2, 4, 2),
(167, 49, 3, 62, NULL, NULL, 115, 48, 2, 4, 2),
(168, 49, 3, 62, NULL, NULL, 116, 48, 2, 4, 2),
(169, 49, 3, 63, NULL, NULL, 117, 48, 1, 4, 5),
(170, 49, 3, 69, NULL, NULL, 118, 48, 4, 4, 6),
(171, 50, 3, 80, 113, NULL, 106, 48, 2, 4, 6),
(172, 50, 3, 62, 113, NULL, 107, 48, 2, 4, 6),
(173, 50, 3, 145, 111, NULL, 108, 48, 4, 4, 6),
(174, 50, 3, 145, 111, NULL, 109, 48, 4, 4, 6),
(175, 50, 3, 80, NULL, NULL, 110, 48, 4, 4, 4),
(176, 50, 2, 43, 8, 12, 182, 48, 4, 2, 4),
(177, 50, NULL, 68, NULL, NULL, 111, 48, 4, 4, 4),
(178, 55, 3, 65, NULL, NULL, 112, 48, 4, 4, 4),
(179, 15, 3, 99, 52, NULL, 225, 48, 4, 4, 6),
(180, 15, 3, 99, 48, NULL, 226, 48, 4, 4, 6),
(181, 15, 3, 99, 49, NULL, 227, 48, 4, 4, 6),
(182, 15, 3, 99, 51, NULL, 218, 48, 4, 4, 6),
(183, 40, NULL, 139, NULL, NULL, 205, 48, 4, 4, 6),
(184, 40, NULL, 143, NULL, NULL, 206, 48, 4, 4, 4),
(185, 40, NULL, 167, NULL, NULL, 207, 48, 4, 4, 4),
(186, 40, NULL, 144, NULL, NULL, 208, 48, 4, 4, 4),
(187, 40, NULL, 93, NULL, NULL, 210, 48, 4, 4, 6),
(188, 40, NULL, 93, NULL, NULL, 211, 48, 4, 4, 4),
(304, 41, NULL, 21, NULL, 17, 222, 48, 4, 4, 6),
(305, 41, NULL, 21, NULL, 17, 223, 48, 4, 4, 6),
(306, 43, 2, 140, NULL, NULL, 212, 48, 1, 4, 5),
(307, 43, NULL, 144, NULL, NULL, 213, 48, 4, 4, 6),
(308, 43, NULL, 139, NULL, NULL, 214, 48, 4, 4, 6),
(309, 43, NULL, 43, 102, NULL, 215, 48, 2, 2, 6),
(310, 43, NULL, 21, NULL, NULL, 224, 48, 2, 4, 6),
(311, 44, NULL, 62, NULL, 7, 216, 48, 4, 4, 4),
(312, 44, NULL, 149, NULL, 7, 217, 48, 4, 4, 6),
(313, 44, NULL, 149, NULL, 7, 218, 48, 4, 4, 4),
(314, 44, NULL, 149, NULL, NULL, 219, 48, 4, 4, 4),
(315, 44, NULL, 149, NULL, NULL, 220, 48, 4, 4, 4),
(316, 44, NULL, 62, NULL, NULL, 221, 48, 4, 4, 4),
(317, 44, NULL, 149, NULL, NULL, 209, 48, 4, 4, 6),
(318, 67, NULL, 5, 95, NULL, 119, 48, 4, 4, 6),
(319, 67, NULL, 5, 95, NULL, 120, 48, 1, 4, 6),
(320, 67, NULL, 167, 95, NULL, 121, 48, 2, 4, 4),
(321, 67, NULL, 167, 95, NULL, 122, 48, 4, 4, 6),
(322, 67, NULL, 5, 95, NULL, 123, 48, 4, 4, 6),
(323, 74, NULL, 37, 89, 3, 131, 48, 4, 4, 3),
(324, 74, NULL, 3, 97, 3, 124, 48, 3, 4, 6),
(325, 74, NULL, 5, 97, 3, 144, 48, 4, 4, 6),
(326, 70, NULL, 30, 97, NULL, 197, 48, 1, 4, 5),
(327, 70, NULL, 9, 97, NULL, 138, 48, 1, 4, 5),
(328, 66, NULL, 23, 93, 3, 145, 48, 4, 4, 6),
(329, 66, NULL, 23, 94, 3, 146, 48, 4, 4, 6),
(330, 66, NULL, 23, 97, 3, 147, 48, 4, 4, 6),
(331, 66, NULL, 23, 97, 3, 148, 48, 3, 4, 6),
(332, 66, NULL, 23, 93, 3, 139, 48, 4, 4, 6),
(333, 66, NULL, 23, 92, 3, 149, 48, 4, 4, 6),
(334, 66, NULL, 23, 93, 3, 150, 48, 4, 4, 6),
(335, 72, NULL, 5, 93, NULL, 125, 48, 4, 4, 6),
(336, 71, NULL, 23, 93, NULL, 140, 48, 4, 4, 6),
(337, 71, NULL, 9, 93, NULL, 141, 48, 4, 2, 6),
(338, 71, NULL, 23, 97, NULL, 142, 48, 4, 4, 6),
(339, 71, NULL, 5, 97, NULL, 198, 48, 1, 4, 5),
(340, 71, NULL, 36, 97, NULL, 132, 48, 1, 4, 5),
(341, 69, NULL, 39, 101, NULL, 199, 48, 1, 4, 5),
(342, 69, NULL, 140, 97, NULL, 212, 48, 4, 2, 5),
(343, 69, NULL, 47, 101, NULL, 183, 48, 4, 2, 5),
(344, 69, NULL, 44, 93, NULL, 201, 48, 4, 4, 5),
(345, 69, NULL, 141, NULL, NULL, 202, 48, 4, 4, 6),
(346, 69, NULL, 141, NULL, NULL, 203, 48, 1, 4, 5),
(347, 78, NULL, 20, 92, NULL, 151, 48, 4, 4, 6),
(348, 78, NULL, 20, 93, NULL, 204, 48, 1, 4, 5),
(349, 78, NULL, 20, 93, NULL, 152, 48, 4, 4, 6),
(350, 78, NULL, 20, 93, NULL, 153, 48, 4, 4, 6),
(351, 78, NULL, 20, 93, NULL, 154, 48, 4, 4, 6),
(352, 78, NULL, 20, 93, NULL, 155, 48, 4, 4, 6),
(353, 79, NULL, 32, 106, NULL, 164, 48, 1, 4, 5),
(354, 79, NULL, 32, 105, NULL, 165, 48, 1, 4, 5),
(355, 79, NULL, 32, 106, NULL, 166, 48, 4, 4, 6),
(356, 79, NULL, 22, 105, NULL, 167, 48, 1, 4, 5),
(357, 79, NULL, 66, 105, NULL, 168, 48, 4, 4, 6),
(358, 79, NULL, 32, 106, NULL, 169, 48, 4, 4, 6),
(359, 69, NULL, 141, NULL, NULL, 126, 48, 4, 4, 6),
(360, 57, NULL, 77, 96, NULL, 127, 48, 4, 4, 6),
(361, 57, NULL, 5, NULL, NULL, 128, 48, 4, 4, 6),
(362, 57, NULL, 23, 93, NULL, 143, 48, 4, 4, 6),
(363, 57, NULL, 139, NULL, NULL, 129, 48, 4, 4, 6),
(364, 57, NULL, 139, NULL, NULL, 130, 48, 4, 4, 6),
(365, 58, NULL, 32, 89, NULL, 133, 48, 4, 4, 6),
(366, 58, NULL, 37, 89, NULL, 134, 48, 4, 4, 3),
(367, 58, NULL, 32, 89, NULL, 135, 48, 4, 4, 3),
(368, 58, NULL, 37, 89, NULL, 136, 48, 4, 4, 3),
(369, 58, NULL, 35, 89, NULL, 137, 48, 4, 4, 6),
(370, 76, NULL, 159, 109, NULL, 170, 48, 4, 4, 6),
(371, 76, NULL, 159, 109, NULL, 171, 48, 4, 4, 6),
(372, 76, NULL, 28, 109, NULL, 172, 48, 4, 4, 6),
(373, 76, NULL, 32, 109, NULL, 173, 48, 4, 4, 6),
(374, 76, NULL, 28, 109, NULL, 174, 48, 4, 4, 6),
(375, 76, NULL, 36, 109, NULL, 175, 48, 4, 4, 6),
(376, 76, NULL, 36, 109, NULL, 176, 48, 4, 4, 6),
(377, 76, NULL, NULL, 109, NULL, 177, 48, 4, 4, 6),
(378, 76, NULL, NULL, 109, NULL, 178, 48, 4, 4, 6),
(379, 76, NULL, 37, 109, NULL, 179, 48, 4, 4, 6),
(380, 76, NULL, NULL, 109, NULL, 180, 48, 4, 4, 6),
(381, 76, NULL, NULL, 110, NULL, 181, 48, 4, 4, 6),
(382, 77, NULL, 94, NULL, NULL, 156, 48, 4, 4, 3),
(383, 77, NULL, 35, NULL, NULL, 157, 48, 4, 4, 6),
(384, 77, NULL, 94, NULL, NULL, 158, 48, 4, 4, 6),
(385, 77, NULL, 94, NULL, NULL, 159, 48, 4, 4, 6),
(386, 77, NULL, 94, NULL, NULL, 160, 48, 4, 4, 6),
(387, 77, NULL, 94, NULL, NULL, 161, 48, 4, 4, 6),
(388, 77, NULL, 94, NULL, NULL, 162, 48, 4, 4, 6),
(389, 77, NULL, 159, NULL, NULL, 163, 48, 4, 4, 6),
(390, 62, NULL, 47, 101, 4, 184, 48, 4, 2, 6),
(391, 62, NULL, 45, 101, 4, 185, 48, 2, 2, 1),
(392, 63, NULL, 169, 100, NULL, 186, 48, 4, 4, 6),
(393, 63, NULL, 40, 101, NULL, 187, 48, 4, 4, 6),
(394, 61, NULL, 45, 102, NULL, 188, 48, 4, 4, 6),
(395, 61, NULL, 47, 101, NULL, 189, 48, 4, 4, 4),
(398, 49, 3, 92, NULL, NULL, 252, 48, 4, 4, 6),
(399, 29, NULL, 94, 63, NULL, 275, 48, 4, 4, 6),
(400, 30, NULL, 80, 62, NULL, 264, 48, 4, 4, 4),
(401, 30, NULL, 63, 62, NULL, 255, 48, 4, 4, 6),
(402, 30, NULL, 63, 62, NULL, 265, 48, 4, 4, 6),
(403, 31, NULL, 91, 60, 15, 276, 48, 4, 4, 6),
(404, 31, NULL, 56, 84, 15, 229, 48, 4, 4, 6),
(405, 31, NULL, 143, 60, 15, 277, 48, 4, 4, 6),
(406, 32, NULL, 49, 61, 21, 278, 48, 4, 4, 6),
(407, 32, NULL, 105, 61, 21, 279, 48, 4, 4, 6),
(408, 32, NULL, 97, 77, NULL, 230, 48, 4, 4, 6),
(409, 32, NULL, 143, 64, NULL, 231, 48, 4, 4, 6),
(410, 32, NULL, 97, 64, NULL, 280, 48, 4, 4, 6),
(411, 32, NULL, 91, 62, NULL, 281, 48, 4, 4, 6),
(412, 32, NULL, 3, 62, NULL, 282, 48, 4, 4, 6),
(413, 32, NULL, 76, 64, NULL, 283, 48, 4, 4, 6),
(414, 32, NULL, 145, 64, NULL, 284, 48, 4, 4, 6),
(415, 33, NULL, 99, NULL, NULL, 266, 48, 4, 4, 6),
(416, 33, NULL, 99, NULL, NULL, 285, 48, 4, 4, 6),
(417, 34, NULL, 93, 39, NULL, 267, 48, 4, 4, 6),
(418, 35, NULL, 73, 54, NULL, 268, 48, 4, 4, 6),
(419, 35, NULL, 73, 39, NULL, 269, 48, 4, 4, 4),
(420, 35, NULL, 99, 54, NULL, 256, 48, 4, 4, 4),
(421, 35, NULL, 73, 39, NULL, 270, 48, 4, 4, 4),
(422, 36, NULL, 91, NULL, NULL, 257, 48, 4, 4, 4),
(423, 36, NULL, 91, NULL, NULL, 258, 48, 4, 4, 4),
(424, 37, NULL, 94, 39, NULL, 273, 48, 4, 4, 4),
(425, 37, NULL, 94, 39, NULL, 259, 48, 4, 4, 4),
(426, 37, NULL, 94, 39, NULL, 274, 48, 4, 4, 4),
(427, 38, NULL, 73, 39, NULL, 271, 48, 4, 4, 4),
(428, 38, NULL, 73, NULL, NULL, 272, 48, 4, 4, 4),
(429, 38, NULL, 73, NULL, NULL, 253, 48, 4, 4, 4),
(430, 75, NULL, 93, 48, NULL, 260, 48, 4, 4, 6),
(431, 75, NULL, 77, 40, NULL, 261, 48, 4, 4, 6),
(432, 75, NULL, 93, 40, NULL, 262, 48, 4, 4, 6),
(433, 75, NULL, 93, 40, NULL, 254, 48, 4, 4, 6),
(455, 75, NULL, 93, 40, NULL, 263, 48, 4, 4, 6),
(456, 45, NULL, 113, 79, 10, 232, 48, 4, 4, 6),
(457, 45, NULL, 113, 78, 10, 233, 48, 4, 4, 6),
(458, 45, NULL, 96, 78, 10, 234, 48, 4, 4, 6),
(459, 46, NULL, 98, 77, NULL, 235, 48, 4, 4, 6),
(460, 46, NULL, 97, 78, NULL, 236, 48, 4, 4, 6),
(461, 46, NULL, 113, 78, NULL, 237, 48, 4, 4, 6),
(462, 46, NULL, 97, 78, NULL, 238, 48, 4, 4, 6),
(463, 47, NULL, 113, 64, NULL, 247, 48, 4, 4, 6),
(464, 47, NULL, 113, 64, NULL, 248, 48, 4, 4, 6),
(465, 47, NULL, 133, 64, NULL, 249, 48, 4, 4, 6),
(466, 47, NULL, 113, 64, NULL, 250, 48, 4, 4, 6),
(467, 47, NULL, 113, 64, NULL, 251, 48, 4, 4, 6),
(468, 81, NULL, 11, 78, NULL, 239, 48, 4, 4, 6),
(469, 81, NULL, 35, 78, NULL, 240, 48, 4, 4, 6),
(470, 81, NULL, 35, 78, NULL, 241, 48, 4, 4, 6),
(471, 80, NULL, 131, NULL, NULL, 243, 48, 4, 4, 6),
(472, 80, NULL, 136, NULL, NULL, 244, 48, 4, 4, 6),
(473, 80, NULL, 131, NULL, NULL, 242, 48, 4, 4, 6),
(474, 80, NULL, 159, NULL, NULL, 245, 48, 4, 4, 6),
(475, 80, NULL, 32, NULL, NULL, 246, 48, 4, 4, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catAlineaT`
--

CREATE TABLE `pmd_catAlineaT` (
  `IdAlineaT` int(11) NOT NULL,
  `alineaT` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catAlineaT`
--

INSERT INTO `pmd_catAlineaT` (`IdAlineaT`, `alineaT`) VALUES
(1, 'Desarrollo y Protección de los Derechos de Niñas, Niños y Adolescentes'),
(2, 'Equidad de genero SIPINNA'),
(3, 'Innovación y desarrollo sostenible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catCalidad`
--

CREATE TABLE `pmd_catCalidad` (
  `idCalidad` int(11) NOT NULL,
  `procCalidad` varchar(350) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catCalidad`
--

INSERT INTO `pmd_catCalidad` (`idCalidad`, `procCalidad`) VALUES
(1, 'Adquisición de bienes y servicios'),
(2, 'Atención de quejas, denuncias y financiamiento de responsabilidades administrativas a los servidores públicos municipales'),
(3, 'Atención para el Desarrollo Integral de la Familia'),
(4, 'Atención y apoyo a las mujeres de Pachuca'),
(5, 'Atención y tratamiento a solicitudes de información pública gubernamental y rendición de cuentas'),
(6, 'Avalúo de predios, actualización catastral'),
(7, 'C-2 Centro de comando y comunicaciones'),
(8, 'Constancia, autorización y reconocimiento de actos jurídicos del estado familiar'),
(9, 'Control y revisión a la obtención y aplicación de los recursos públicos municipales'),
(10, 'Dictamen ambiental para regularización de establecimientos para el cuidado del equilibrio ecológico y protección al medio ambiente'),
(11, 'Egresos'),
(12, 'Gestión de los recursos humanos'),
(13, 'Gestión y mantenimiento de servicios generales'),
(14, 'Mantenimiento y reparación del parque vehicular'),
(15, 'Mantenimiento y reparación de alumbrado público'),
(16, 'Mantenimiento y soporte técnico a tecnologías de la información y comunicación (TIC´S)'),
(17, 'Módulo de infracciones, oficina de trámites de vialidad'),
(18, 'Prensa e información de comunicación social'),
(19, 'Regulación para el funcionamiento de abastecimientos mercantiles y celebración de espectáculos públicos'),
(20, 'Regulación para el funcionamiento de establecimientos mercantiles y celebración de espectáculos públicos'),
(21, 'Servicio de recolección de desechos sólidos urbanos'),
(22, 'Sistema de apertura rápida de empresas (SARE)'),
(23, 'Sistema de información para seguimiento de peticiones y atención ciudadana 070'),
(24, 'Soporte a la unidad de información para actualización de información en la rendición de cuentas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catDependencias`
--

CREATE TABLE `pmd_catDependencias` (
  `idDependencia` int(11) NOT NULL,
  `dependenciaNue` int(11) DEFAULT NULL,
  `dependencia` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catDependencias`
--

INSERT INTO `pmd_catDependencias` (`idDependencia`, `dependenciaNue`, `dependencia`) VALUES
(1, 1000, 'H. Ayuntamiento'),
(2, 100, 'Unidades de Apoyo del Presidente Municipal'),
(3, 600, 'Secretaría General Municipal'),
(4, 800, 'Secretaría de la Tesorería'),
(5, 1900, 'Secretaría de Planeación y Evaluación'),
(6, 400, 'Secretaría de Contraloría y Transparencia'),
(7, 500, 'Secretaría de Servicios Públicos Municipales'),
(8, 700, 'Secretaría de Obras Públicas Desarrollo Urbano, Vivienda y Movilidad'),
(9, 900, 'Secretaría de Seguridad Pública, Tránsito y Vialidad'),
(10, 1800, 'Secretaría de Medio Ambiente y Desarrollo Sustentable'),
(11, 200, 'Secretaría de Desarrollo Económico'),
(12, 300, 'Secretaría de Administración'),
(13, 1500, 'Secretaría de Desarrollo Humano y Social'),
(14, 2200, 'Secretaría General de las Mujeres'),
(15, 2300, 'Secretaría de Gestión y Vinculación Internacional '),
(16, 1100, 'Sistema DIF Municipal'),
(17, 1200, 'Instituto Municipal de Investigación y Planeación'),
(18, 1600, 'Instituto Municipal del Deporte'),
(19, 1700, 'Instituto Municipal para la Cultura'),
(21, 1300, 'Instituto Municipal para la Prevención de Adicciones'),
(22, 1400, 'Instituto Municipal para la Juventud'),
(23, 2000, 'Primera Unidad de Rescate, Rehabilitación y Reubicación de Fauna Silvestre, Endémica Y Exótica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catEje`
--

CREATE TABLE `pmd_catEje` (
  `idEje` int(11) NOT NULL,
  `eje` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catEje`
--

INSERT INTO `pmd_catEje` (`idEje`, `eje`) VALUES
(1, 'Pachuca Honesta, Cercana y Moderna'),
(2, 'Pachuca Próspera y con Dinamismo Económico'),
(3, 'Pachuca con Bienestar Social, Humana, Igualitaria y con Valores'),
(4, 'Pachuca Segura y en Paz'),
(5, 'Pachuca con Infraestructura y Servicios de Calidad');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catGDMI`
--

CREATE TABLE `pmd_catGDMI` (
  `pah_GDIM_Id` int(11) NOT NULL,
  `pah_GDMT_Id` int(11) DEFAULT NULL,
  `pah_GDMI_Numero` int(11) DEFAULT NULL,
  `pah_GDMI_Clave` varchar(8) DEFAULT NULL,
  `pah_GDI_Indicador` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catGDMI`
--

INSERT INTO `pmd_catGDMI` (`pah_GDIM_Id`, `pah_GDMT_Id`, `pah_GDMI_Numero`, `pah_GDMI_Clave`, `pah_GDI_Indicador`) VALUES
(1, 1, 1, '1.1.1', 'Bando de Policía y Gobierno'),
(2, 1, 2, '1.1.2 ', 'Manuales de Organización'),
(3, 1, 3, '1.1.3', 'Organigramas'),
(4, 1, 4, '1.1.4', 'Tabulador de sueldos o documentos con la estructura salarial del personal de la administración pública municipal'),
(5, 1, 5, '1.1.5', 'Unidades administrativas existentes en función del número de unidades administrativas'),
(6, 1, 6, '1.1.6', 'Servidores públicos por cada 1,000 habitantes'),
(7, 1, 7, '1.1.7', 'Nivel salarial del Presidente (a) municipal.'),
(8, 1, 8, '1.1.8', 'Participación de las mujeres en puestos de mando medio y superior de la administración municipal.'),
(9, 2, 1, '1.2.1', 'Lineamientos de planeación municipal'),
(10, 2, 2, '1.2.2', 'Comité o cuerpo colegiado de planeación municipal.'),
(11, 2, 3, '1.2.3', 'Plan Municipal de Desarrollo'),
(12, 2, 4, '1.2.4', 'Índice de Planeación Municipal'),
(13, 3, 1, '1.3.1', 'Programa de control interno'),
(14, 3, 2, '1.3.2', 'Lineamientos para la entrega - recepción de la administración pública municipal.'),
(15, 3, 3, '1.3.3', 'Auditorías realizadas'),
(16, 3, 4, '1.3.4', 'Tasa de observaciones documentadas en las auditorías internas'),
(17, 4, 1, '1.4.1', 'Diagnóstico de las necesidades de capacitación'),
(18, 4, 2, '1.4.2', 'Diagnóstico de las necesidades de capacitación'),
(19, 4, 3, '1.4.3', 'Evaluación de la capacitación'),
(20, 4, 4, '1.4.4', 'Servidores públicos capacitados'),
(21, 7, 1, '2.1.1', 'Ley de Ingresos Municipal'),
(22, 7, 2, '2.1.2', 'Reglamento municipal de catastro'),
(23, 7, 3, '2.1.3', 'Sistema de información catastral'),
(24, 7, 4, '2.1.4', 'Capacidad financiera'),
(25, 7, 5, '2.1.5', 'Tasa de crecimiento real anual de la recaudación del impuesto predial'),
(26, 7, 6, '2.1.6', 'Tasa de crecimiento real anual de la recaudación por derecho de agua'),
(27, 7, 7, '2.1.7', 'Tasa de crecimiento real anual de la recaudación de otros ingresos propios'),
(28, 8, 1, '2.2.1', 'Presupuesto de egresos municipal'),
(29, 8, 2, '2.2.2', 'Armonización contable'),
(30, 8, 3, '2.2.3', 'Cuenta Pública'),
(31, 8, 4, '2.2.4', 'Costo de operación'),
(32, 8, 5, '2.2.5', 'Proporción de los Adeudos de Ejercicios Fiscales Anteriores (ADEFAS)'),
(33, 8, 6, '2.2.6', 'Balance presupuestario sostenible'),
(34, 9, 1, '2.3.1', 'Programa para minimizar el peso de la deuda pública en los ingresos municipales'),
(35, 9, 2, '2.3.2', 'Proyecto autorizado por el Congreso Local para la contratación de financiamiento y obligaciones 2.3.3 Nivel de endeudamiento municipal'),
(36, 10, 1, '2.4.1', 'Disposición normativa en materia de patrimonio Municipal.'),
(37, 10, 2, '2.4.2', 'Inventario de Bienes (muebles e inmuebles)'),
(38, 10, 3, '2.4.3', 'Control de bienes muebles e inmuebles'),
(39, 11, 1, '3.1.1', 'Normatividad para la planeación urbana'),
(40, 11, 2, '3.1.2', 'Plan o Programa de Desarrollo Urbano Municipal (PDU).'),
(41, 11, 3, '3.1.3', 'Emisión de licencias de construcción'),
(42, 11, 4, '3.1.4', 'Unidad responsable de la planeación urbana'),
(43, 11, 5, '3.1.5', 'Índice de Planeación Urbana'),
(44, 12, 1, '3.2.1', 'Reglamento o lineamientos municipales del ordenamiento ecológico local.'),
(45, 12, 2, '3.2.2', 'Programa de Ordenamiento Ecológico Local'),
(46, 12, 3, '3.2.3', 'Acciones para la implementación del Ordenamiento Ecológico.'),
(47, 12, 4, '3.2.4', 'Índice de ordenamiento ecológico'),
(48, 13, 1, '3.3.1', 'Reglamento de Protección Civil'),
(49, 13, 2, '3.3.2', 'Unidad de protección civil'),
(50, 13, 3, '3.3.3', 'Consejo Municipal de Protección Civil'),
(51, 13, 4, '3.3.4', 'Atlas municipal de riesgos'),
(52, 13, 5, '3.3.5', 'Programa Municipal de Protección Civil'),
(53, 13, 6, '3.3.6', 'Tasa de crecimiento de asentamientos humanos en zonas de riesgo.'),
(54, 14, 1, '3.4.1', 'Diagnóstico de la zona metropolitana'),
(55, 14, 2, '3.4.2', 'Gobernanza metropolitana'),
(56, 14, 3, '3.4.3', 'Programa de la zona metropolitana'),
(57, 15, 1, '4.1.1', 'Reglamentación municipal para la prestación de los servicios públicos.'),
(58, 15, 1, '4.1.2', 'Estructura administrativa para la prestación de los servicios públicos.'),
(59, 16, 1, '4.2.1', 'Situación del agua potable, drenaje, alcantarillado, tratamiento y disposición de sus aguas residuales.'),
(60, 16, 2, '4.2.2', 'Alumbrado público.'),
(61, 16, 3, '4.2.3', 'Situación de limpia, recolección, traslado, tratamiento y disposición final de residuos.'),
(62, 16, 4, '4.2.4', 'Situación de Mercados (centrales de abasto) y panteones.'),
(63, 17, 1, '4.3.1', 'Programa Operativo Anual para la prestación de los servicios públicos.'),
(64, 17, 2, '4.3.2', 'Cartera de proyectos para mejorar la prestación de los servicios públicos.'),
(65, 18, 1, '4.4.1', 'Tasa de abatimiento de calles sin revestimiento.'),
(66, 18, 2, '4.4.2', 'Tasa de abatimiento de la carencia de servicio de agua potable en las viviendas.'),
(67, 18, 3, '4.4.3', 'Tasa de abatimiento del déficit del servicio de drenaje en viviendas particulares.'),
(68, 18, 4, '4.4.4', 'Tasa de abatimiento del déficit del servicio de alcantarillado en arterias viales.'),
(69, 18, 5, '4.4.5', 'Porcentaje de agua tratada'),
(70, 18, 6, '4.4.6', 'Cobertura de mobiliario del servicio de limpia en espacios públicos.'),
(71, 18, 7, '4.4.7', 'Cobertura del servicio de recolección de residuos sólidos.'),
(72, 18, 8, '4.4.8', 'Tasa de crecimiento anual del índice de áreas verdes y recreativas per cápita.'),
(73, 18, 9, '4.4.9', 'Cobertura en el servicio de alumbrado público.'),
(74, 18, 10, '4.4.10', 'Cobertura en el servicio de mercados públicos per cápita.'),
(75, 18, 11, '4.4.11', 'Cobertura en el servicio de panteones.'),
(76, 19, 1, '5.1.1', 'Instancia municipal responsable del medio ambiente.'),
(77, 19, 2, '5.1.2', 'Reglamento para el cuidado del medio ambiente.'),
(78, 19, 3, '5.1.3', 'Plan o programa Municipal de Protección al Ambiente.'),
(79, 20, 1, '5.2.1', 'Instancia municipal en materia de cambio climático.'),
(80, 20, 2, '5.2.2', 'Plan, programa o documento de adaptación y mitigación al cambio climático'),
(81, 20, 3, '5.2.3', 'Acciones del municipio para disminuir la vulnerabilidad ante el cambio climático'),
(82, 20, 4, '5.2.4', 'Edificaciones'),
(83, 21, 1, '5.3.1', 'Eficiencia en servicio de agua potable.'),
(84, 21, 2, '5.3.2', 'Eficiencia en Alumbrado público'),
(85, 21, 3, '5.3.3', 'Mejora en el uso de la flota vehicular del municipio'),
(86, 21, 4, '5.3.4', 'Abatimiento del costo promedio por luminaria'),
(87, 22, 1, '6.1.1', 'Instancia responsable de promover la educación básica.'),
(88, 22, 2, '6.1.2', 'Diagnóstico de educación básica.'),
(89, 22, 3, '6.1.3', 'Programa municipal de educación básica.'),
(90, 22, 4, '6.1.4', 'Coordinación para promover la educación básica en el municipio.'),
(91, 23, 1, '6.2.1', 'Instancia responsable de promover la salud.'),
(92, 23, 2, '6.2.2', 'Diagnóstico en materia de salud.'),
(93, 23, 3, '6.2.3', 'Programa municipal de salud.'),
(94, 23, 4, '6.2.4', 'Coordinación para garantizar el derecho a la protección de la salud.'),
(95, 24, 1, '6.3.1', 'Diagnóstico de grupos vulnerables.'),
(96, 24, 2, '6.3.2', 'Programa para la atención de grupos vulnerables.'),
(97, 24, 3, '6.3.3', 'Coordinación para la atención de grupos vulnerables.'),
(98, 24, 4, '6.3.4', 'Porcentaje de mujeres jefas de familia apoyadas por programas de atención.'),
(99, 25, 1, '6.4.1', 'Diagnóstico de igualdad de género.'),
(100, 25, 2, '6.4.2', 'Programa para la promoción de la igualdad de género.'),
(101, 25, 3, '6.4.3', 'Coordinación para la atención de igualdad de género.'),
(102, 25, 4, '6.4.4', 'Porcentaje de programas municipales que contribuyen a la igualdad de género.'),
(103, 26, 1, '6.5.1', 'Diagnóstico sobre juventud.'),
(104, 26, 2, '6.5.2', 'Programa municipal de atención a la juventud.'),
(105, 26, 3, '6.5.3', 'Coordinación para la atención de la juventud.'),
(106, 26, 4, '6.5.4', 'Porcentaje de personas jóvenes atendidas por algún programa para su desarrollo.'),
(107, 27, 1, '6.6.1', 'Instancia responsable de la promoción del deporte y la recreación.'),
(108, 27, 2, '6.6.2', 'Diagnóstico sobre deporte y recreación.'),
(109, 27, 3, '6.6.3', 'Programa municipal de promoción del deporte y la recreación.'),
(110, 27, 4, '6.6.4', 'Coordinación para la promoción del deporte y la recreación.'),
(111, 28, 1, '7.1.1', 'Reglamento publicado del Consejo Municipal de Mejora Regulatoria'),
(112, 28, 2, '7.1.2', 'Funcionamiento del Consejo Municipal de Mejora Regulatoria.'),
(113, 28, 3, '7.1.3', 'Inventario municipal de trámites y servicios.'),
(114, 28, 4, '7.1.4', 'Atracción y retención de inversión en el sector comercio y servicios'),
(115, 29, 1, '7.2.1', 'Instancia responsable.'),
(116, 29, 2, '7.2.2', 'Diagnóstico.'),
(117, 29, 3, '7.2.3', 'Programa de fomento.'),
(118, 29, 4, '7.2.4', 'Atracción y retención de inversión en el sector.'),
(119, 30, 1, '7.3.1', 'Reglamento de desarrollo económico.'),
(120, 30, 2, '7.3.2', 'Acciones de capacitación para el empleo.'),
(121, 30, 3, '7.3.3', 'Estrategia de atracción de inversiones.'),
(122, 30, 4, '7.3.4', 'Vinculación para el fomento económico.'),
(123, 31, 1, '8.1.1', 'Reglamento municipal de transparencia y acceso a la información pública'),
(124, 31, 2, '8.1.2', 'Instancia responsable de transparencia y acceso a la información pública'),
(125, 31, 3, '8.1.3', 'Programa de transparencia y acceso a la información pública'),
(126, 31, 4, '8.1.4', 'Eficacia en la atención de solicitudes de acceso a la información'),
(127, 31, 5, '8.1.5', 'Cumplimiento de obligaciones de transparencia'),
(128, 32, 1, '8.2.1', 'Mecanismo para atender las propuestas ciudadanas'),
(129, 32, 2, '8.2.2', 'Seguimiento y atención de las propuestas ciudadanas'),
(130, 33, 1, '8.3.1', 'Código de ética de los servidores públicos municipales'),
(131, 33, 2, '8.3.2', 'Difusión y capacitación sobre el Código de ética '),
(132, 9, 3, '2.3.3', 'Nivel de endeudamiento municipal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catGDMM`
--

CREATE TABLE `pmd_catGDMM` (
  `pah_GDM_Id` int(11) NOT NULL,
  `pah_GDM_Modulo` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catGDMM`
--

INSERT INTO `pmd_catGDMM` (`pah_GDM_Id`, `pah_GDM_Modulo`) VALUES
(1, 'Organización'),
(2, 'Hacienda'),
(3, 'Gestión del territorio'),
(4, 'Servicios públicos'),
(5, 'Medio ambiente'),
(6, 'Desarrollo social'),
(7, 'Desarrollo económico'),
(8, 'Gobierno abierto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catGDMT`
--

CREATE TABLE `pmd_catGDMT` (
  `pah_GDMT_Id` int(11) NOT NULL,
  `pah_GDM_Id` int(11) DEFAULT NULL,
  `pah_GDMT_Clave` varchar(8) DEFAULT NULL,
  `pah_GDMT_Numero` int(11) DEFAULT NULL,
  `pah_GDMT_Tema` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catGDMT`
--

INSERT INTO `pmd_catGDMT` (`pah_GDMT_Id`, `pah_GDM_Id`, `pah_GDMT_Clave`, `pah_GDMT_Numero`, `pah_GDMT_Tema`) VALUES
(1, 1, '1.1', 1, 'Estructura'),
(2, 1, '1.2', 2, 'Planeación'),
(3, 1, '1.3', 3, 'Control interno'),
(4, 1, '1.4', 4, 'Capacitación'),
(5, 1, '0', 0, 'N/D'),
(6, 1, '0', 0, 'N/D'),
(7, 2, '2.1', 1, 'Ingresos'),
(8, 2, '2.2', 2, 'Egresos'),
(9, 2, '2.3', 3, 'Deuda'),
(10, 2, '2.4', 4, 'Patrimonio'),
(11, 3, '3.1', 1, 'Desarrollo urbano'),
(12, 3, '3.2', 2, 'Ordenamiento ecológico'),
(13, 3, '3.3', 3, 'Protección civil'),
(14, 3, '3.4', 4, 'Coordinación urbana'),
(15, 4, '4.1', 1, 'Marco normativo'),
(16, 4, '4.2', 2, 'Diagnóstico'),
(17, 4, '4.3', 3, 'Acciones'),
(18, 4, '4.4', 4, 'Evaluación'),
(19, 5, '5.1', 1, 'Preservación del ambiente'),
(20, 5, '5.2', 2, 'Cambio climático'),
(21, 5, '5.3', 3, 'Servicios públicos sustentables'),
(22, 6, '6.1', 1, 'Educación'),
(23, 6, '6.2', 2, 'Salud'),
(24, 6, '6.3', 3, 'Grupos vulnerables'),
(25, 6, '6.4', 4, 'Igualdad de género'),
(26, 6, '6.5', 5, 'Juventud'),
(27, 6, '6.6', 6, 'Deporte y recreación'),
(28, 7, '7.1', 1, 'Mejora regulatoria'),
(29, 7, '7.2', 2, 'Vocación productiva'),
(30, 7, '7.3', 3, 'Fomento económico'),
(31, 8, '8.1', 1, 'Transparencia'),
(32, 8, '8.2', 2, 'Participación ciudadana'),
(33, 8, '8.3', 3, 'Ética pública');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catGenero`
--

CREATE TABLE `pmd_catGenero` (
  `idGenero` int(11) NOT NULL,
  `genero` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catGenero`
--

INSERT INTO `pmd_catGenero` (`idGenero`, `genero`) VALUES
(1, 'Hombre'),
(2, 'Mujeres'),
(3, 'Personalizados'),
(4, 'Todos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catGrupoEdad`
--

CREATE TABLE `pmd_catGrupoEdad` (
  `idGrupoEdad` int(11) NOT NULL,
  `grupoEdad` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catGrupoEdad`
--

INSERT INTO `pmd_catGrupoEdad` (`idGrupoEdad`, `grupoEdad`) VALUES
(1, '-18'),
(2, '19 - 60'),
(3, '60+'),
(4, 'Todas las edades');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catLineaAccion`
--

CREATE TABLE `pmd_catLineaAccion` (
  `idLineaAccion` int(11) NOT NULL,
  `objGeneralId` int(11) DEFAULT NULL,
  `cveLineaAccion` varchar(11) DEFAULT NULL,
  `lineaAccion` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catLineaAccion`
--

INSERT INTO `pmd_catLineaAccion` (`idLineaAccion`, `objGeneralId`, `cveLineaAccion`, `lineaAccion`) VALUES
(1, 1, '1.1.A.1', 'Implementar mecanismos para la evaluación y selección de personal, para obtener un mejor desempeño del servicio público, eficiente y de calidad.'),
(2, 1, '1.1.A.2', 'Fortalecer los mecanismos de Control Interno para contar con instituciones eficaces.'),
(3, 1, '1.1.A.3', 'Fortalecer el Código de Ética y adoptar la política de cero tolerancia a la corrupción. Objetivo estratégico'),
(4, 1, '1.1.A.4', 'Adecuar la normatividad en materia de Control Interno Estatal al ámbito municipal.'),
(5, 1, '1.1.A.5', 'Evaluar los procesos operativos, contables, presupuestales y programáticos a través de auditorías.'),
(6, 1, '1.1.A.6', 'Participar en los procesos de entrega recepción intermedia a efecto de que los sujetos obligados enteren los recursos humanos, materiales, financieros e información al término de su empleo, cargo o comisión.'),
(7, 1, '1.1.A.7', 'Supervisar, inspeccionar y verificar el avance físico y financiero de las obras y/o proyectos autorizados.'),
(8, 1, '1.1.A.8', 'Verificar que los servidores públicos municipales cumplan con la realización de su declaración patrimonial y de intereses a través de una plataforma tecnológica.'),
(9, 1, '1.1.A.9', 'Atender oportunamente las quejas y denuncias en contra de las y los servidores públicos municipales en apego a la política cero tolerancia a la corrupción.'),
(10, 1, '1.1.A.10', 'Determinar sanciones administrativas derivadas de omisiones en las atribuciones de los servidores y ex servidores públicos municipales.'),
(11, 1, '1.1.A.11', 'Eficientar los sistemas de recaudación respecto a impuestos, productos, derechos y aprovechamientos a fin de incrementar los ingresos obtenidos en ejercicios anteriores.'),
(12, 1, '1.1.A.12', 'Actualizar las atribuciones legislativas que permitan fortalecer los acuerdos y resoluciones de competencia municipal.'),
(13, 2, '1.1.B.1', 'Dar estricto cumplimiento a la normatividad referente a los procedimientos de licitación a fin de evitar prácticas de corrupción.'),
(14, 2, '1.1.B.2', 'Erradicar la corrupción y soborno, endureciendo las sanciones administrativas derivadas del incumplimiento en las responsabilidades de los servidores y ex servidores públicos.'),
(15, 2, '1.1.B.3', 'Vigilar que las actividades de la ciudadanía y los diversos órganos o asociaciones se desarrollen dentro del marco legal establecido.'),
(16, 2, '1.1.B.4', 'Eficientar la inspección y regulación de los establecimientos mercantiles en el municipio.'),
(17, 2, '1.1.B.5', 'Modernizar los sistemas de información de catastro y avalúos para fomentar los trámites en línea generando certidumbre en la ciudadanía.'),
(18, 3, '1.2.A.1', 'Planear, coordinar y dirigir la logística de los eventos del Presidente Municipal, en estricto apego a las medidas de seguridad y sanidad correspondientes.'),
(19, 3, '1.2.A.2', 'Garantizar la inclusión y participación de los diferentes sectores de la sociedad en los eventos promovidos por la Presidencia Municipal, a fin de fortalecer el impacto de las acciones de gobierno.'),
(20, 3, '1.2.A.3', 'Desarrollar e implementar sistemas de información que faciliten la comunicación con la ciudadanía para la atención de peticiones a través del programa Servitel 070 y WhatsApp Center.'),
(21, 3, '1.2.A.4', 'Implementar una plataforma web para la gestión de atención ciudadana, a fin de brindar un seguimiento eficiente a las solicitudes recibidas.'),
(22, 3, '1.2.A.5', 'Mejorar los procedimientos de atención y seguimiento de las solicitudes ciudadanas.'),
(23, 3, '1.2.A.6', 'Garantizar la atención cercana y de calidad hacia la ciudadanía, siendo un gobierno de puertas abiertas en todo momento.'),
(24, 3, '1.2.A.7', 'Fortalecer los vínculos de cooperación estratégica del Presidente Municipal con los sectores privado y público en sus diferentes órdenes de gobierno.'),
(25, 3, '1.2.A.8', 'Generar un canal de comunicación efectivo y asertivo del gobierno con la ciudadanía.'),
(26, 3, '1.2.A.9', 'Promover la inclusión social y política de los ciudadanos sin discriminación de ninguna índole, con la finalidad de garantizar la igualdad de oportunidades.'),
(27, 3, '1.2.A.10', 'Fomentar la participación ciudadana en los asuntos públicos.'),
(28, 3, '1.2.A.11', 'Establecer líneas de trabajo con las cámaras de comercio para el adecuado funcionamiento de los establecimientos mercantiles, así como supervisar el correcto desarrollo de los espectáculos.'),
(29, 3, '1.2.A.12', 'Informar de manera efectiva y eficiente a la población las acciones que realiza el gobierno municipal a través de los diversos medios de comunicación.'),
(30, 3, '1.2.A.13', 'Instrumentar una estrategia de difusión del uso y consolidación de la Gaceta Municipal Digital como medio de comunicación entre el gobierno municipal y la ciudadanía.'),
(31, 3, '1.2.A.14', 'Vincular al H. Ayuntamiento como un canal efectivo de comunicación entre la ciudadanía y el gobierno municipal.'),
(32, 4, '1.2.B.1', 'Crear un expediente electrónico ciudadano para tender a la automatización de trámites y servicios.'),
(33, 4, '1.2.B.2', 'Integrar un padrón electrónico de inspectores y visitadores para su incorporación al portal web de la presidencia.'),
(34, 4, '1.2.B.3', 'Integrar el catálogo municipal de trámites, servicios y regulaciones, para impulsar la interoperabilidad con la plataforma web nacional de trámites.'),
(35, 4, '1.2.B.4', 'Integrar un sistema de información para la gestión y mantenimiento de servicios generales en oficinas de la presidencia municipal.'),
(36, 4, '1.2.B.5', 'Gestionar la modernización de los recursos tecnológicos de la presidencia municipal.'),
(37, 4, '1.2.B.6', 'Fomentar la aplicación de herramientas tecnológicas que permitan eficientar los procesos internos de operatividad de la presidencia municipal.'),
(38, 4, '1.2.B.7', 'Conservar la certificación en los procesos de calidad para el mantenimiento y soporte técnico de las tecnologías de la información y la comunicación.'),
(39, 4, '1.2.B.8', 'Incrementar la calidad y eficiencia en los trámites y servicios que en materia de inscripción se efectúan en relación con los registros del estado civil de las personas.'),
(40, 4, '1.2.B.9', 'Eficientar los procesos registrales en favor de los grupos vulnerables.'),
(41, 4, '1.2.B.10', 'Integrar trámites y servicios en línea del Registro del Estado Familiar.'),
(42, 4, '1.2.B.11', 'Conservar y resguardar el acervo histórico documental a través de la digitalización de registros de actas.'),
(43, 4, '1.2.B.12', 'Integrar un sistema de información que agilice y promueva los trámites y servicios en materia de desarrollo urbano en línea, optimizando los tiempos de respuesta.'),
(44, 4, '1.2.B.13', 'Fortalecer los procesos que permitan un seguimiento oportuno a las infracciones en materia de construcción, uso de suelo y acciones urbanas, a fin de vigilar estrictamente el cumplimiento de la normativa municipal.'),
(45, 4, '1.2.B.14', 'Innovar las plataformas existentes en las unidades administrativas a través del uso de las tecnologías de la información y comunicación.'),
(46, 4, '1.2.B.15', 'Reestructurar el portal web del municipio generando valor público a través del modelo de gobierno electrónico.'),
(47, 5, '1.2.C.1', 'Coadyuvar a la estandarización de procesos conforme a la norma ISO 9001 contribuyendo a la mejora continua, en la conservación y ampliación del sistema de Gestión de Calidad.'),
(48, 5, '1.2.C.2', 'Actualizar y fortalecer los procesos que permitan eficientar los mecanismos de pago al municipio.'),
(49, 5, '1.2.C.3', 'Obtener la certificación de los procedimientos de integración de los Presupuestos basados en Resultados y de Evaluación.'),
(50, 6, '1.2.D.1', 'Modernizar el parque vehicular e implementar una plataforma digital cuyas características permitan la generación de ahorros en el consumo de combustibles y refacciones.'),
(51, 6, '1.2.D.2', 'Implementar el uso de energías renovables y asequibles en las oficinas del municipio con el objetivo de generar ahorros y disminuir el impacto ambiental.'),
(52, 6, '1.2.D.3', 'Desarrollar un programa permanente de capacitación y evaluación de los servidores públicos municipales.'),
(53, 6, '1.2.D.4', 'Promover la capacitación, actualización y profesionalización del servicio registral.'),
(54, 6, '1.2.D.5', 'Administrar los recursos humanos, materiales y financieros que permitan operar eficientemente los programas y proyectos en materia de obra pública.'),
(55, 6, '1.2.D.6', 'Fomentar en todas y cada una de las áreas del municipio mejores prácticas administrativas.'),
(56, 6, '1.2.D.7', 'Coordinar el trabajo legislativo de la H. Asamblea.'),
(57, 6, '1.2.D.8', 'Actualizar el marco normativo para eficientar los procesos administrativos en busca de mejores resultados en beneficio de las familias pachuqueñas.'),
(58, 6, '1.2.D.9', 'Contribuir al cumplimiento en materia de transparencia, control interno y calidad en busca de mejores resultados en favor de las familias pachuqueñas.'),
(59, 6, '1.2.D.10', 'Coordinar eficientemente todas y cada una de las acciones que desarrollan las unidades administrativas con el fin de alcanzar el cumplimiento de los objetivos plasmados en el PMD 2020-2024.'),
(60, 7, '1.2.E.1', 'Actualizar el Reglamento Interior de la Administración Pública Municipal.'),
(61, 7, '1.2.E.2', 'Impulsar iniciativas para reformar, adicionar y homologar el marco jurídico en materia del registro del estado civil de las personas.'),
(62, 7, '1.2.E.3', 'Eficientar los tiempos de atención en el trámite de traslado de dominio y avalúos catastrales.'),
(63, 7, '1.2.E.4', 'Actualizar la normativa municipal en el tema de Presupuesto basado en Resultados y el Sistema de Evaluación del Desempeño.'),
(64, 8, '1.2.F.1', 'Dar cumplimiento a las obligaciones de transparencia y acceso a la información pública, como lo estipula la normatividad vigente.'),
(65, 8, '1.2.F.2', 'Efectuar sesiones del Comité de Transparencia para la clasificación de información y declaración de inexistencia o incompetencia.'),
(66, 8, '1.2.F.3', 'Atender con eficacia las solicitudes de acceso a la información pública.'),
(67, 9, '1.2.G.1', 'Emitir lineamientos, criterios y mecanismos para la atención de asuntos de carácter legal en el municipio.'),
(68, 9, '1.2.G.2', 'Defender los intereses y derechos de las diferentes dependencias de la administración pública municipal.'),
(69, 9, '1.2.G.3', 'Coordinar eficientemente los procesos para llevar a cabo el Servicio Militar Nacional que establece la Junta de Reclutamiento.'),
(70, 9, '1.2.G.4', 'Asesorar jurídicamente mediante campañas de registro del estado civil con respeto a la diversidad sexual.'),
(71, 9, '1.2.G.5', 'Vigilar y atender los intereses municipales, representar jurídicamente al Ayuntamiento, procurar la justicia y legalidad en la administración pública municipal.'),
(72, 10, '1.2.H.1', 'Gestionar recursos de la iniciativa privada y del sector público a nivel nacional e internacional que permitan incrementar las capacidades en materia de seguridad pública.'),
(73, 10, '1.2.H.2', 'Crear mecanismos de colaboración y/o vinculación con entidades gubernamentales internacionales, nacionales, estatales y municipales para fortalecer las acciones del gobierno municipal.'),
(74, 10, '1.2.H.3', 'Coordinar las acciones mediante las cuales el Presidente Municipal establezca relaciones institucionales con los distintos sectores, organismos y otros niveles de gobierno, así como con las diferentes organizaciones de la sociedad civil, para el desarrollo y ejecución de proyectos estratégicos.'),
(75, 10, '1.2.H.4', 'Promover la vinculación del municipio ante el sector privado, así como con las diferentes instituciones de los tres órdenes de gobierno y distintas organizaciones civiles, nacionales e internacionales, en la gestión de recursos y generación de vínculos de intercambio económico, educativo, cultural, tecnológico, político y de buenas prácticas de Administración Pública.'),
(76, 10, '1.2.H.5', 'Coordinar la política internacional de la administración pública municipal en el ámbito de su competencia.'),
(77, 10, '1.2.H.6', 'Impulsar la participación del municipio en programas de cooperación con organismos nacionales e internacionales de carácter público y privado.'),
(78, 10, '1.2.H.7', 'Promover relaciones de amistad y colaboración con ciudades de otros países, con el fin de celebrar acuerdos de hermanamiento.'),
(79, 11, '1.2.I.1', 'Aplicar evaluaciones internas y externas para determinar el diseño eficacia, eficiencia, cumplimiento de metas y objetivos, impactos, resultados, generación de valor público y pertinencia de los programas y proyectos.'),
(80, 11, '1.2.I.2', 'Implementar un sistema de información y monitoreo de los indicadores de gestión y desempeño para la oportuna toma de decisiones.'),
(81, 11, '1.2.I.3', 'Coordinar los trabajos en la integración de los Informes de Gobierno.'),
(82, 12, '1.3.A.1', 'Implementar políticas que incentiven la recaudación de recursos propios en el marco de la retribución en mejores obras y servicios.'),
(83, 12, '1.3.A.2', 'Implementar mecanismos de cobro a través de plataformas digitales, evitando el desplazamiento de los contribuyentes.'),
(84, 12, '1.3.A.3', 'Celebrar el convenio de colaboración administrativa en materia fiscal con el Gobierno del Estado.'),
(85, 12, '1.3.A.4', 'Incrementar la recuperación de los créditos fiscales a favor del municipio, agotando los procedimientos administrativos de ejecución.'),
(86, 12, '1.3.A.5', 'Dar seguimiento puntual a la Ley de Contabilidad Gubernamental y a los criterios de armonización contable.'),
(87, 12, '1.3.A.6', 'Actualizar el Manual de Gasto Público del Municipio.'),
(88, 12, '1.3.A.7', 'Formular un presupuesto de egresos integral.'),
(89, 12, '1.3.A.8', 'Integrar conforme a la Ley General de Contabilidad Gubernamental los resultados de la gestión financiera.'),
(90, 12, '1.3.A.9', 'Vincular el Presupuesto basado en Resultados con la designación de recursos.'),
(91, 12, '1.3.A.10', 'Vigilar el manejo y correcta gestión de la hacienda municipal.'),
(92, 13, '1.4.A.1', 'Coordinar la participación democrática en la integración y actualización del Plan Municipal de Desarrollo 2020-2024 en alineación con los planes nacional y estatal de desarrollo.'),
(93, 13, '1.4.A.2', 'Crear y dar seguimiento puntual al Comité de Planeación para el Desarrollo Municipal fomentando la participación ciudadana.'),
(94, 13, '1.4.A.3', 'Impulsar la alineación de los programas y proyectos municipales con los Objetivos de Desarrollo Sostenible (ODS), los indicadores de gestión que integran la Guía Consultiva de Desempeño Municipal (GDM) y la implementación del Presupuesto basado en Resultados y el Sistema de Evaluación del Desempeño (PbR-SED).'),
(95, 13, '1.4.A.4', 'Fortalecer el acompañamiento técnico especializado a las unidades administrativas en la correcta construcción de sus programas y proyectos.'),
(96, 13, '1.4.A.5', 'Integrar un repositorio de proyectos que permita monitorear avances y fortalezca el proceso de toma de decisiones.'),
(97, 14, '2.1.A.1', 'Impulsar el desarrollo de capacidades productivas de las personas y empresas para elevar su competitividad.'),
(98, 14, '2.1.A.2', 'Coadyuvar en las aptitudes y habilidades de los ciudadanos con el fin de mejorar el desempeño en sus competencias laborales.'),
(99, 14, '2.1.A.3', 'Fomentar en el sector productivo la inclusión al comercio electrónico.'),
(100, 14, '2.1.A.4', 'Generar programas de incentivos para impulsar el desarrollo de las Micro, Pequeñas y Medianas Empresas (MiPyMEs).'),
(101, 15, '2.1.B.1', 'Concretar convenios de colaboración con diversos sectores para fomentar el comercio electrónico en apoyo a las actividades productivas.'),
(102, 15, '2.1.B.2', 'Eficientar el trámite de renovación de la licencia de funcionamiento para establecimientos mercantiles.'),
(103, 15, '2.1.B.3', 'Actualizar el diagnóstico del sector productivo en el municipio.'),
(104, 15, '2.1.B.4', 'Generar estrategias para atraer inversiones al municipio.'),
(105, 15, '2.1.B.5', 'Generar convenios de colaboración con cámaras empresariales, instituciones de educación superior, gobiernos municipales y estatales en materia de desarrollo económico.'),
(106, 15, '2.1.B.6', 'Integrar trámites y servicios en línea para agilizar y simplificar los procesos actuales.'),
(107, 15, '2.1.B.7', 'Facilitar la apertura de empresas con la resolución expedita de trámites de nuevas licencias de funcionamiento.'),
(108, 15, '2.1.B.8', 'Identificar áreas de oportunidad en el desarrollo de la mejora regulatoria.'),
(109, 15, '2.1.B.9', 'Construir un marco regulatorio que fortalezca la adopción de políticas públicas, resolutivas, coherentes e innovadoras que promuevan la facilidad en el acceso a trámites y servicios.'),
(110, 15, '2.1.B.10', 'Certificar a las áreas que generan trámites y servicios en el municipio.'),
(111, 16, '2.2.A.1', 'Proteger los derechos laborales para las y los trabajadores y promover entre ellos un trabajo seguro basado en la eficiencia y resultados.'),
(112, 16, '2.2.A.2', 'Generar mecanismos eficientes para el pago de percepciones y prestaciones al personal jubilado y sindicalizado del municipio, con base en las condiciones generales de trabajo.'),
(113, 17, '2.3.A.1', 'Implementar políticas y acciones directas que impulsen el desarrollo turístico sostenible en el municipio.'),
(114, 17, '2.3.A.2', 'Establecer alianzas estratégicas con prestadores de servicios turísticos locales, artesanos y artistas para impulsar el turismo local.'),
(115, 17, '2.3.A.3', 'Incorporar diferentes medios electrónicos de difusión turística para impulsar la promoción y oferta de los productos turísticos del municipio.'),
(116, 17, '2.3.A.4', 'Incrementar la atracción de inversión en el sector turístico, impulsando el crecimiento económico y la oferta laboral en el municipio.'),
(117, 17, '2.3.A.5', 'Diseñar y crear talleres dirigidos a niñas, niños y adolescentes que promuevan la identidad turística-cultural del municipio.'),
(118, 17, '2.3.A.6', 'Crear contenidos digitales para difundir atractivos turísticos y culturales, así como artistas plásticos y visuales del municipio.'),
(119, 18, '3.1.A.1', 'Diseñar e implementar estrategias para la integración en grupos de trabajo a las personas voluntarias, en favor de la población vulnerable.'),
(120, 18, '3.1.A.2', 'Coordinar la participación del voluntariado en los eventos especiales como Día de Reyes, Día del Niño, Día de las Madres, Día del Adulto Mayor, colectas o algún acopio por contingencia ambiental.'),
(121, 18, '3.1.A.3', 'Generar alianzas estratégicas con organizaciones públicas o privadas que permitan obtener recursos económicos o en especie, en beneficio de familias en condiciones de vulnerabilidad.'),
(122, 18, '3.1.A.4', 'Promover a través de las Organizaciones de la Sociedad Civil y Empresas Socialmente Responsables, acciones de recaudación de donativos económicos y/o en especie para los centros asistenciales y población vulnerable.'),
(123, 18, '3.1.A.5', 'Vincular al Sistema DIF Pachuca con distintas asociaciones y organizaciones civiles, a fin de concretar proyectos en beneficio de las familias pachuqueñas.'),
(124, 18, '3.1.A.6', 'Mejorar la calidad de vida de los adultos mayores aumentando el número de apoyos y programas a este sector de la población.'),
(125, 18, '3.1.A.7', 'Difundir de forma efectiva los programas del Sistema DIF Pachuca con el fin de incrementar su cobertura en beneficio de las familias.'),
(126, 18, '3.1.A.8', 'Promover sociedades pacíficas e inclusivas para el desarrollo sostenible, así como facilitar el acceso a la justicia para todos, con la finalidad de construir los niveles institucionales eficaces e inclusivos que rindan cuentas.'),
(127, 18, '3.1.A.9', 'Elaborar un diagnóstico que permita conocer la situación de la población prioritaria del municipio.'),
(128, 18, '3.1.A.10', 'Fortalecer el tejido social a través de programas de participación entre el gobierno y la ciudadanía pachuqueña.'),
(129, 18, '3.1.A.11', 'Promover el respeto a los derechos humanos desde la administración pública municipal, para garantizar un trato digno a toda la ciudadanía de Pachuca.'),
(130, 18, '3.1.A.12', 'Desarrollar el concepto de ciudad de derecho, donde se garantice la inclusión, equidad de género, participación, accesibilidad, asequibilidad y seguridad social en beneficio de la población.'),
(131, 19, '3.2.A.1', 'Disminuir la deserción escolar ampliando el número de becas y escuelas beneficiadas, con programas de educación.'),
(132, 19, '3.2.A.2', 'Difundir y ampliar el servicio de la ludoteca municipal con la finalidad de brindar acceso y espacios dignos para niñas, niños y adolescentes.'),
(133, 19, '3.2.A.3', 'Promover programas y acciones para erradicar el analfabetismo en el municipio.'),
(134, 19, '3.2.A.4', 'Establecer alianzas estratégicas con el sector educativo, productivo y científico; a fin de ampliar las oportunidades de convertir a Pachuca en una ciudad del conocimiento.'),
(135, 19, '3.2.A.5', 'Incluir a Pachuca en la red mundial de “Ciudades del Aprendizaje” de la UNESCO.'),
(136, 19, '3.2.A.6', 'Gestionar recursos externos destinados a brindar becas promoviendo el pleno ejercicio del derecho a la educación y erradicar la deserción escolar.'),
(137, 19, '3.2.A.7', 'Promover los principios y valores humanos en la sociedad, aspirando a lograr una convivencia armónica dentro de nuestro municipio.'),
(138, 20, '3.3.A.1', 'Ampliar las cédulas de focalización de los programas alimentarios para reducir las formas de malnutrición.'),
(139, 20, '3.3.A.2', 'Implementar campañas de prevención y promoción a la salud que permitan fortalecer el bienestar de las familias pachuqueñas.'),
(140, 20, '3.3.A.3', 'Promover un estilo de vida saludable en el que sea primordial el bienestar emocional de las familias.'),
(141, 20, '3.3.A.4', 'Adaptar espacios, de acuerdo a los estándares, que puedan ser usados como lactarios por parte de las madres trabajadoras.\r\n\r\n'),
(142, 20, '3.3.A.5', 'Brindar a las familias atención psicológica a fin de coadyuvar en mejorar la salud mental afectada por problemas familiares, emocionales, conductuales, educativos y de lenguaje.'),
(143, 20, '3.3.A.6', 'Desarrollar programas de prevención y promoción de la salud que permitan reducir el índice de obesidad y enfermedades crónico degenerativas en la población vulnerable de Pachuca.'),
(144, 21, '3.3.B.1', 'Fortalecer los programas que permitan incrementar la calidad de vida, generando bienestar social entre la población.'),
(145, 21, '3.3.B.2', 'Ampliar el acceso a servicios básicos de salud de calidad.'),
(146, 21, '3.3.B.3', 'Establecer convenios de colaboración con el sector privado e instituciones públicas para brindar servicios de atención médica.'),
(147, 21, '3.3.B.4', 'Acercar a las colonias del municipio las unidades médicas móviles para ofrecer servicios de salud con un enfoque preventivo y de promoción a la salud.'),
(148, 21, '3.3.B.5', 'Ofrecer traslados a la unidad básica de rehabilitación a personas con discapacidad y/o adultos mayores de manera gratuita.'),
(149, 21, '3.3.B.6', 'Fortalecer la atención a la salud a través del Centro de Atención Médica y Diagnóstico favoreciendo el acceso oportuno de la población.'),
(150, 21, '3.3.B.7', 'Fortalecer los servicios en materia de rehabilitación a personas con alguna discapacidad temporal o permanente, en la Unidad Básica de Rehabilitación.'),
(151, 22, '3.3.C.1', 'Realizar el diagnóstico sobre adicciones en la población del municipio de Pachuca.'),
(152, 22, '3.3.C.2', 'Implementar protocolos para la prevención de adicciones de la población en situación de riesgo.'),
(153, 22, '3.3.C.3', 'Impulsar acciones en materia de prevención de adicciones en coordinación con los tres órdenes de gobierno y organizaciones de la sociedad civil.'),
(154, 22, '3.3.C.4', 'Fortalecer la cultura de la prevención de adicciones y promoción de la salud con la población en general.'),
(155, 22, '3.3.C.5', 'Intervenir espacios públicos en zonas de alto riesgo para inhibir el consumo de drogas.'),
(156, 23, '3.4.A.1', 'Desarrollar programas que permitan difundir de manera permanente el patrimonio tangible e intangible de Pachuca.'),
(157, 23, '3.4.A.2', 'Vincular al sector educativo, artístico y empresarial para fomentar actividades culturales.'),
(158, 23, '3.4.A.3', 'Integrar el diagnóstico sobre la situación actual del desarrollo cultural en el municipio.'),
(159, 23, '3.4.A.4', 'Implementar actividades culturales frecuentes que propicien el desarrollo e identidad cultural en los pachuqueños.'),
(160, 23, '3.4.A.5', 'Activar espacios públicos con propuestas culturales, buscando la participación activa de la ciudadanía para fortalecer la apropiación pacífica del espacio público.'),
(161, 23, '3.4.A.6', 'Brindar a la ciudadanía conciertos de música clásica, tradicional y contemporánea con la participación de la Orquesta Filarmónica de Pachuca.'),
(162, 23, '3.4.A.7', 'Realizar convenios con organizaciones artístico-culturales para incrementar el desarrollo de actividades en el municipio.'),
(163, 23, '3.4.A.8', 'Establecer hermanamientos culturales a nivel internacional.'),
(164, 24, '3.5.A.1', 'Reconocer e incentivar a las y los jóvenes en categorías de logros académicos, actividades empresariales, artísticas, culturales, tecnológicas y de inclusión.'),
(165, 24, '3.5.A.2', 'Garantizar espacios de participación de las y los jóvenes que permita detectar problemas comunes y brindar soluciones.'),
(166, 24, '3.5.A.3', 'Generar convenios con organizaciones de la sociedad civil, centros de asistencia o instancias privadas y del gobierno federal, cuyo propósito sea implementar acciones orientadas a la juventud.'),
(167, 24, '3.5.A.4', 'Implementar programas de prevención del embarazo y enfermedades de transmisión sexual en jóvenes y adolescentes.'),
(168, 24, '3.5.A.5', 'Brindar ofertas educativas, capacitación para el empleo y bolsas de trabajo para las y los adolescentes y jóvenes, que les permita incrementar su nivel de productividad, así como sus habilidades para incorporarse al mercado laboral.'),
(169, 24, '3.5.A.6', 'Generar contenido de radio y televisión digital que impulse a las juventudes a expresarse, con el fin de formar líderes de opinión.'),
(170, 25, '3.5.B.1', 'Conformar escuelas deportivas municipales fortaleciendo la cultura deportiva y desempeño de sus estudiantes bajo un método de entrenamiento y de intercambio constante.'),
(171, 25, '3.5.B.2', 'Impulsar el talento deportivo en diversas disciplinas a nivel selección estatal, nacional y al deporte profesional.'),
(172, 25, '3.5.B.3', 'Desarrollar programas que fomenten la actividad física en busca de reducir altos índices de sobrepeso y obesidad entre la población.'),
(173, 25, '3.5.B.4', 'Impulsar la profesionalización de los entrenadores locales y del talento deportivo.'),
(174, 25, '3.5.B.5', 'Reconocer e impulsar a los ciudadanos que promueven, gestionan e invierten recursos en los barrios o colonias a través del programa “El Rostro del Deporte”.'),
(175, 25, '3.5.B.6', 'Apoyar a deportistas locales de alto rendimiento en la proyección hacia el profesionalismo o su internacionalización.'),
(176, 25, '3.5.B.7', 'Gestionar proyectos para la conservación, rehabilitación y mejora permanente de la infraestructura deportiva municipal.'),
(177, 25, '3.5.B.8', 'Gestionar la realización de eventos deportivos estatales, nacionales e internacionales en el municipio.'),
(178, 25, '3.5.B.9', 'Institucionalizar el premio municipal del deporte “El Reloj de Plata” destacando la trayectoria de los deportistas locales.'),
(179, 25, '3.5.B.10', 'Impulsar el deporte local generando la “Alianza Metropolitana del Deporte”.'),
(180, 25, '3.5.B.11', 'Generar el evento institucional “Amigos del Viento” para fomentar actividades deportivas en barrios y colonias.'),
(181, 25, '3.5.B.12', 'Desarrollar convenios con organizaciones de la sociedad civil, centros de asistencia e instancias privadas para promover el desarrollo del deporte, la recreación e infraestructura municipal.1'),
(182, 26, '3.6.A.1', 'Incrementar la participación de las mujeres para ocupar cargos de mandos medios y superiores en la administración pública municipal.'),
(183, 26, '3.6.A.2', 'Fortalecer políticas para promover la igualdad de género de todas las mujeres y niñas.'),
(184, 26, '3.6.A.3', 'Diseñar e implementar programas integrales para la atención y cuidado de las mujeres y familiares en situación de violencia.'),
(185, 26, '3.6.A.4', 'Fortalecer las acciones de emprendimiento y empoderamiento de las mujeres a través de los comités de mujeres en los barrios y colonias.'),
(186, 26, '3.6.A.5', 'Actualizar el diagnóstico de igualdad de género.'),
(187, 26, '3.6.A.6', 'Fortalecer campañas de difusión para prevenir y erradicar todo tipo de violencia de género.'),
(188, 26, '3.6.A.7', 'Instrumentar convenios de colaboración con organizaciones de la sociedad civil, centros de asistencia e instancias privadas para promover la igualdad de género.'),
(189, 26, '3.6.A.8', 'Capacitar de forma permanente en perspectiva y equidad de género a las y los servidores públicos de la Presidencia Municipal de Pachuca de Soto.'),
(190, 27, '3.7.A.1', 'Desarrollar un diagnóstico sobre la situación actual de niñas, niños y adolescentes en el municipio.'),
(191, 27, '3.7.A.2', 'Actualizar el Programa Municipal de Protección Integral de Niñas, Niños y Adolescentes.'),
(192, 27, '3.7.A.3', 'Poner en operación la Unidad de Primer Contacto en el Sistema Municipal de Protección Integral de Niñas, Niños y Adolescentes.'),
(193, 27, '3.7.A.4', 'Impulsar la firma de convenios con organizaciones de la sociedad civil, centros de asistencia e instancias privadas para promover la atención de niñas y niños y adolescentes.'),
(194, 27, '3.7.A.5', 'Promover campañas de sensibilización y difusión de los derechos de los niños, niñas y adolescentes.'),
(195, 27, '3.7.A.6', 'Implementar mesas multidisciplinarias e interinstitucionales que coadyuven a fortalecer las políticas públicas municipales en materia de los derechos de los niños, niñas y adolescentes.'),
(196, 27, '3.7.A.7', 'Garantizar una línea de comunicación eficiente para los reportes de violencia de niñas, niños y adolescentes, además de brindar una atención de calidad.'),
(197, 27, '3.7.A.8', 'Promover que las niñas y los niños tengan acceso a servicios de atención y desarrollo en la primera infancia y educación preescolar.'),
(198, 27, '3.7.A.9', 'Brindar atención a niñas, niños y adolescentes que se encuentren en una situación de vulnerabilidad.'),
(199, 27, '3.7.A.10', 'Disminuir todas las formas de discriminación a niñas, niños y adolescentes.'),
(200, 27, '3.7.A.11', 'Contribuir en la disminución de las practicas de maltrato, explotación, trata y todas las formas de violencia y tortura contra niñas, niños y adolescentes.'),
(201, 27, '3.7.A.12', 'Promover el acceso universal a la salud sexual y reproductiva, así como a los métodos de prevención del embarazo a niñas y adolescentes.'),
(202, 27, '3.7.A.13', 'Otorgar servicios de orientación, protección, asistencia y representación jurídica a niñas, niños y adolescentes con discapacidad.'),
(203, 27, '3.7.A.14', 'Fortalecer los derechos de niñas, niños y adolescentes en situación de vulnerabilidad que comprometa su seguridad, salud, educación o moralidad.'),
(204, 27, '3.7.A.15', 'Implementar programas de prevención de adicciones para niñas, niños y adolescentes a fin de disminuir factores de riesgo.'),
(205, 28, '4.1.A.1', 'Implementar un modelo de proximidad confiable a la ciudadanía, disminuyendo los índices delictivos, logrando una convivencia armónica y paz social.'),
(206, 28, '4.1.A.2', 'Reducir considerablemente la corrupción y el soborno en todas sus formas, al realizar el ejercicio de funciones de los elementos policiacos.'),
(207, 28, '4.1.A.3', 'Fortalecer canales de comunicación con instancias de seguridad federal y estatal para el intercambio y fortalecimiento de estrategias de seguridad.'),
(208, 28, '4.1.A.4', 'Integrar el Consejo de Seguridad Pública Municipal.'),
(209, 28, '4.1.A.5', 'Crear la Comisión de Honor y Justicia.'),
(210, 29, '4.2.A.1', 'Incrementar el número de cámaras de videovigilancia que permitan inhibir los actos delictivos.'),
(211, 29, '4.2.A.2', 'Implementar nuevas tecnologías que permitan favorecer la eficiencia de los protocolos de actuación de los elementos policíacos.'),
(212, 29, '4.2.A.3', 'Reducir mediante acciones preventivas del sistema de seguridad el maltrato, explotación y todas las formas de violencia contra las niñas, niños y adolescentes.'),
(213, 29, '4.2.A.4', 'Aumentar el número de elementos de la unidad ciclista, ampliando la cobertura a zonas de difícil acceso.'),
(214, 29, '4.2.A.5', 'Generar canales de comunicación e interacción con la ciudadanía que permitan reducir significativamente los actos de violencia y delincuencia.'),
(215, 29, '4.2.A.6', 'Incrementar el personal femenino y fortalecer los protocolos de actuación policial en materia de violencia de género'),
(216, 29, '4.2.A.7', 'Capacitar permanentemente al personal operativo, en la implementación y uso de nuevas tecnologías de videovigilancia y radio comunicación.'),
(217, 29, '4.2.A.8', 'Crear la Unidad de Policía Cibernética Municipal.'),
(218, 29, '4.2.A.9', 'Adquirir tecnologías que nos ayuden a la identificación de zonas de mayor incidencia de grupos y personas que realicen conductas antisociales.'),
(219, 29, '4.2.A.10', 'Dotar de equipo táctico y de respuesta inmediata a todos los elementos policiales.'),
(220, 29, '4.2.A.11', 'Contar con el certificado único profesional en el 100% de los elementos operativos en activo.'),
(221, 29, '4.2.A.12', 'Mejorar las condiciones laborales para el fortalecimiento del desarrollo policial.'),
(222, 30, '4.3.A.1', 'Identificar las principales zonas de conflicto vial, que permitan desarrollar estrategias de solución efectiva en la prevención y mejoramiento en tiempos de traslado.'),
(223, 30, '4.3.A.2', 'Fomentar una cultura vial donde se respete la pirámide de jerarquía de la movilidad urbana.'),
(224, 30, '4.3.A.3', 'Fortalecer el programa de alcoholímetro para disminuir considerablemente los hechos de tránsito.'),
(225, 31, '4.4.A.1', 'Incorporar la gestión integral del riesgo y la emergencia como una política prioritaria en todos los sectores y niveles de gobierno.'),
(226, 31, '4.4.A.2', 'Desarrollar una campaña que promueva una cultura de protección civil para fortalecer las medidas de seguridad y evitar riesgos.'),
(227, 31, '4.4.A.3', 'Fortalecer la coordinación entre los niveles estatal y municipal de la zona metropolitana en materia de protección civil, buscando la resiliencia ante emergencias y desastres.'),
(228, 31, '4.4.A.4', 'Actualizar y publicar conforme a la normatividad estatal y municipal el Atlas de Riesgos.'),
(229, 32, '5.1.A.1', 'Reducir costos e impacto ambiental mediante el uso de tecnología LED en todo el alumbrado público.'),
(230, 32, '5.1.A.2', 'Mejorar la estética escénica, calidad del suelo y aire de los diversos espacios públicos y rurales con vocación forestal, así como el rescate de áreas naturales protegidas a través de la forestación y reforestación con vegetación adecuada a fin de restaurar y aumentar el inventario forestal.'),
(231, 32, '5.1.A.3', 'Actualizar y fortalecer el Reglamento de Parques y Jardines del Municipio de Pachuca de Soto.'),
(232, 32, '5.1.A.4', 'Impulsar la creación de una instancia municipal para la atención del cambio climático.'),
(233, 32, '5.1.A.5', 'Concretar el proceso de publicación del Programa de Ordenamiento Ecológico Local del Municipio de Pachuca de Soto.'),
(234, 32, '5.1.A.6', 'Reducir el impacto ambiental negativo de la ciudad en estricto apego a la normatividad vigente en materia de protección al medio ambiente.'),
(235, 32, '5.1.A.7', 'Impulsar la creación del Plan Municipal de Protección al Ambiente.'),
(236, 32, '5.1.A.8', 'Realizar reforestaciones dentro del municipio con especies establecidas dentro de la paleta vegetal.'),
(237, 32, '5.1.A.9', 'Impulsar la creación del Decreto de Áreas Naturales Protegidas de Competencia Municipal.'),
(238, 32, '5.1.A.10', 'Establecer un vivero forestal para la producción de especies de la región y reforestación de áreas urbanas.'),
(239, 32, '5.1.A.11', 'Impulsar el desarrollo de huertos que permitan la adopción de estilos de vida sustentable.'),
(240, 32, '5.1.A.12', 'Impulsar la creación de lineamientos y disposiciones de educación ambiental.'),
(241, 32, '5.1.A.13', 'Introducir estrategias innovadoras de aprendizaje para fomentar en la población, conocimiento y motivaciones que desarrollen capacidades y compromisos que permitan afrontar los problemas socioambientales.'),
(242, 32, '5.1.A.14', 'Adecuar y fortalecer los espacios para brindar mejores condiciones a los ejemplares, y así dar cumplimiento a los lineamientos internacionales de bienestar animal.'),
(243, 33, '5.1.B.1', 'Implementar acciones de sensibilización y concientización a la población sobre la importancia de la conservación de la fauna silvestre, para evitar la caza y el tráfico ilegal de especies.'),
(244, 33, '5.1.B.2', 'Gestionar e incrementar los recursos provenientes de fuentes públicas y privadas, para la conservación y protección de la fauna silvestre.'),
(245, 33, '5.1.B.3', 'Certificar los procesos esenciales para el funcionamiento de la unidad de rehabilitación.'),
(246, 33, '5.1.B.4', 'Fortalecer la capacidad técnica y operativa para brindar mejores servicios médicos veterinarios, de alta especialidad a un bajo costo.'),
(247, 34, '5.1.C.1', 'Mantener actualizado el padrón municipal de animales.'),
(248, 34, '5.1.C.2', 'Vigilar el cumplimiento del Reglamento para la Protección, Control y Bienestar de los Animales del Municipio de Pachuca de Soto.'),
(249, 34, '5.1.C.3', 'Fomentar el respeto y trato digno hacia los animales, a través de campañas de concientización y difusión de la normatividad aplicable.'),
(250, 34, '5.1.C.4', 'Gestionar recursos públicos y/o privados, donaciones, herencias y legados a fin de crear un fondo para la protección de perros y gatos.'),
(251, 34, '5.1.C.5', 'Implementar campañas de vacunación antirrábica y esterilización de perros y gatos en el municipio.'),
(252, 35, '5.2.A.1', 'Incentivar el uso de la bicicleta como medio de transporte alternativo, con el objetivo de reducir la congestión vial y la emisión de gases efecto invernadero, así como apoyar el desarrollo sostenible de la ciudad y mejorar la salud y el bienestar de los ciudadanos.'),
(253, 35, '5.2.A.2', 'Diseñar espacios que permitan lograr la conectividad eficiente de los diferentes medios de transporte, priorizando los no motorizados y no contaminantes.'),
(254, 35, '5.2.A.3', 'Elaborar el Plan de Movilidad Municipal.'),
(255, 36, '5.3.A.1', 'Implementar acciones que conlleven a estrategias de desarrollo comercial, que promuevan la homogeneización en la generación de lineamientos normativos y permitan el desarrollo de infraestructura resiliente de comercio y abasto en el municipio.'),
(256, 36, '5.3.A.2', 'Coordinar los trabajos para elaborar un Plan de Desarrollo Metropolitano.'),
(257, 36, '5.3.A.3', 'Gestionar obras y programas para el mantenimiento de viviendas que contribuyan al mejoramiento de la imagen urbana.'),
(258, 36, '5.3.A.4', 'Promover los programas del ámbito federal, estatal y sector privado para detectar y atender las necesidades de vivienda en áreas marginales.'),
(259, 36, '5.3.A.5', 'Fortalecer las normativas existentes en materia de protección y conservación del Centro Histórico.'),
(260, 36, '5.3.A.6', 'Fortalecer los instrumentos de planeación urbana que permitan el crecimiento de la ciudad de una manera ordenada.'),
(261, 36, '5.3.A.7', 'Integrar y homologar la base de datos geoestadísticos del municipio.'),
(262, 36, '5.3.A.8', 'Concluir el proceso jurídico hasta la publicación del Plan Municipal de Desarrollo Urbano y Plan Municipal de Ordenamiento Territorial.'),
(263, 36, '5.3.A.9', 'Elaborar el diagnóstico sobre vulnerabilidad urbana.'),
(264, 37, '5.4.A.1', 'Crear herramientas digitales vinculadas con códigos QR para eficientar la gestión del padrón de concesionarios de cada área que regula el municipio.'),
(265, 37, '5.4.A.2', 'Implementar un programa de mejora a la imagen y seguridad de los mercados, tianguis y comercio en la vía pública con enfoque medioambiental.'),
(266, 37, '5.4.A.3', 'Fortalecer la urbanización inclusiva y sostenible para una adecuada planificación de los asentamientos humanos en todo el municipio.'),
(267, 37, '5.4.A.4', 'Actualizar los lineamientos normativos en materia de desarrollo urbano y sustentabilidad en alineación a los formulados por el estado y la federación.'),
(268, 37, '5.4.A.5', 'Implementar proyectos de obra pública sustentables con visión y proyección a una zona metropolitana, mediante el uso de tecnologías que permitan la realización de levantamientos territoriales con modismos.'),
(269, 37, '5.4.A.6', 'Implementar y promover en la ejecución de obra pública el uso de materiales que brinden mayor durabilidad, permitan una vida útil, un mantenimiento a bajo costo y sean amigables con el medio ambiente.'),
(270, 37, '5.4.A.7', 'Mejorar las condiciones de infraestructura y equipamiento de la ciudad, a fin de que sea inclusiva y sostenible, proporcionando acceso universal y especial atención a las necesidades de las personas en situación de vulnerabilidad.'),
(271, 37, '5.4.A.8', 'Implementar programas de rescate y construcción de espacios públicos.'),
(272, 37, '5.4.A.9', 'Eficientar los programas de bacheo y pavimentación en calles y avenidas del municipio.'),
(273, 38, '5.4.B.1', 'Implementar y desarrollar un programa de conservación y mantenimiento del patrimonio histórico, cultural y plazas cívicas existentes en el primer cuadro del Centro Histórico.'),
(274, 38, '5.4.B.2', 'Desarrollar proyectos en espacios públicos e inmuebles históricos para actividades culturales, turísticas y deportivas a fin de conservar el patrimonio.'),
(275, 39, '5.5.A.1', 'Favorecer la estética escénica optimizando los servicios de mantenimiento en los espacios públicos que deriven en una identidad cultural urbana y se estimule la participación social.'),
(276, 39, '5.5.A.2', 'Incrementar el servicio de alumbrado público en las calles del municipio, agilizando las inspecciones e instalaciones requeridas, así como la optimización de los recursos humanos y materiales del municipio.'),
(277, 39, '5.5.A.3', 'Elaborar un Reglamento de Alumbrado Público dirigido a nuevos desarrollos habitacionales.'),
(278, 39, '5.5.A.4', 'Optimizar los servicios de recolección de residuos sólidos urbanos, así como la adecuada gestión desde su generación hasta su disposición final en apego a la Ley para la Protección del Medio Ambiente del Estado de Hidalgo.'),
(279, 39, '5.5.A.5', 'Implementar un programa integral que permita optimizar los servicios de limpieza de calles y avenidas en el municipio.'),
(280, 39, '5.5.A.6', 'Implementar un programa integral de mantenimiento de áreas verdes, parques y jardines que permita recuperar su apreciación medioambiental.'),
(281, 39, '5.5.A.7', 'Implementar un programa de reordenamiento y generación de espacios para la inhumación en el panteón municipal.'),
(282, 39, '5.5.A.8', 'Brindar servicios funerarios de calidad a menor costo en beneficio de la ciudadanía que así lo requiera.'),
(283, 39, '5.5.A.9', 'Continuar con la certificación de los procesos para la obtención de materia prima de origen animal, brindando productos de calidad.'),
(284, 39, '5.5.A.10', 'Actualizar y fortalecer el Reglamento del Rastro Municipal que conlleve a la implementación de un cerco sanitario en el proceso de comercialización de productos cárnicos y el manejo responsable de los residuos orgánicos.'),
(285, 39, '5.5.A.11', 'Asegurar el acceso de todas las personas a servicios básicos apropiados, seguros y asequibles, elevando la calidad de vida de los barrios y colonias marginales.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catObjEstrategicos`
--

CREATE TABLE `pmd_catObjEstrategicos` (
  `idObjEstrategico` int(11) NOT NULL,
  `ejeId` int(11) DEFAULT NULL,
  `cveObjEstrategico` varchar(11) DEFAULT NULL,
  `ObjEstrategico` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catObjEstrategicos`
--

INSERT INTO `pmd_catObjEstrategicos` (`idObjEstrategico`, `ejeId`, `cveObjEstrategico`, `ObjEstrategico`) VALUES
(1, 1, '1.1', 'Combate a la corrupción'),
(2, 1, '1.2', 'Mejora de la gestión'),
(3, 1, '1.3', 'Finanzas públicas sanas'),
(4, 1, '1.4', 'Gobierno cercano con planeación democrática'),
(5, 2, '2.1', 'Entorno económico, dinámico e innovador'),
(6, 2, '2.2', 'Trabajo y previsión social'),
(7, 2, '2.3', 'Desarrollo e impulso turístico'),
(8, 3, '3.1', 'Desarrollo social e integral'),
(9, 3, '3.2', 'Aprendizaje y conocimiento'),
(10, 3, '3.3', 'Salud preventiva'),
(11, 3, '3.4', 'Arte y cultura'),
(12, 3, '3.5', 'Juventud y deporte'),
(13, 3, '3.6', 'Equidad de género'),
(14, 3, '3.7', 'Desarrollo y protección de niñas, niños y adolescentes'),
(15, 4, '4.1', 'Gobernabilidad'),
(16, 4, '4.2', 'Prevención del delito'),
(17, 4, '4.3', 'Tránsito y vialidad'),
(18, 4, '4.4', 'Protección civil'),
(19, 5, '5.1', 'Protección del medio ambiente, flora y fauna'),
(20, 5, '5.2', 'Movilidad sostenible'),
(21, 5, '5.3', 'Planeación y ordenamiento'),
(22, 5, '5.4', 'Infraestructura sostenible'),
(23, 5, '5.5', 'Servicios de calidad');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catObjGeneral`
--

CREATE TABLE `pmd_catObjGeneral` (
  `idObjGeneral` int(11) NOT NULL,
  `objEstrategicoId` int(11) DEFAULT NULL,
  `cveObjGeneral` varchar(11) DEFAULT NULL,
  `ObjGeneral` varchar(400) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catObjGeneral`
--

INSERT INTO `pmd_catObjGeneral` (`idObjGeneral`, `objEstrategicoId`, `cveObjGeneral`, `ObjGeneral`) VALUES
(1, 1, '1.1.A', 'Fortalecer la normatividad regulatoria que conduzca con rectitud los procesos\nadministrativos, el desempeño de los servidores públicos municipales y la\natención oportuna de quejas y denuncias que permitan transparentar el desempeño de\nla Administración Pública Municipal'),
(2, 1, '1.1.B', 'Combatir frontalmente los actos de corrupción y soborno mediante la implementación\nde mecanismos de control que permitan eficientar y transparentar los procesos donde\nse apliquen recursos públicos o se vean beneficiados intereses personales o de grupo.'),
(3, 2, '1.2.A', 'Contribuir a fortalecer los canales de comunicación entre el gobierno y la\nciudadanía mediante ejercicios coordinados de participación democrática en los asuntos de interés público.'),
(4, 2, '1.2.B', 'Incentivar las políticas en el uso de tecnologías de la información y comunicación\nque permitan modernizar y eficientar los procesos, trámites y servicios en busca de\nproyectar al municipio como referente nacional de innovación.'),
(5, 2, '1.2.C', 'Mantener y fortalecer los procedimientos bajo la norma ISO 9001 mediante el\nmantenimiento y actualización continua del Sistema de Gestión de Calidad.'),
(6, 2, '1.2.D', 'Eficientar la administración de los recursos humanos materiales y financieros\nmediante el control y fortalecimiento de los procesos operativos internos en busca\nde disminuir considerablemente el gasto operativo.'),
(7, 2, '1.2.E', 'Actualizar el marco normativo municipal mediante la continua reingeniería\noperacional que permita cumplir con los objetivos institucionales desde una estructura\ncompacta y eficiente.'),
(8, 2, '1.2.F', 'Brindar cumplimiento oportuno a los articulados de la Ley General de Transparencia\ny Acceso a la Información Pública, mediante el fomento a la cultura de la transparencia\nen el ejercicio de la función pública, acceso a la información, participación ciudadana\ny la rendición de cuentas.'),
(9, 2, '1.2.G', 'Brindar asesoría jurídica eficaz, eficiente y oportuna a las diferentes dependencias\nde la administración pública municipal, dentro de un marco de defensa de los intereses\ndel municipio y de respeto a los derechos de los ciudadanos.'),
(10, 2, '1.2.H', 'Instrumentar mecanismos de cooperación en los tres niveles de gobierno,\norganismos privados y asociaciones nacionales e internacionales para vincular\nprogramas y proyectos en busca de fortalecer el desarrollo municipal.'),
(11, 2, '1.2.I', 'Dar seguimiento oportuno al cumplimiento de indicadores del Plan Municipal\nde Desarrollo 2020-2024, de los Presupuestos basados en Resultados, así como de\nla efectividad de los programas, proyectos y políticas públicas a través del Sistema\nde Evaluación del Desempeño para la oportuna toma de decisiones en la generación\nde valor público.'),
(12, 3, '1.3.A', 'Fortalecer la hacienda pública municipal mediante la adopción de políticas\nfinancieras, presupuestales y contables apegadas a la Ley General de Contabilidad\nGubernamental y a las políticas de racionalidad del gasto con el fin de brindar una\nadecuada distribución del recurso público.'),
(13, 4, '1.4.A', 'Coordinar los procesos de planeación en apego a todas las herramientas\nde innovación que permitan fortalecer el andamiaje estructural de los planes y\nprogramas que desarrollarán todas y cada una de las unidades administrativas\npara el cumplimiento del Plan Municipal de Desarrollo 2020-2024.'),
(14, 5, '2.1.A', 'Impulsar el desarrollo de capacidades productivas de las personas y empresas\npara elevar su competitividad.'),
(15, 5, '2.1.B', 'Fomentar las inversiones internas y externas a través de políticas de simplificación\nadministrativa, incentivos fiscales y apoyos directos que atraigan un desarrollo\neconómico permanente.'),
(16, 6, '2.2.A', 'Impulsar políticas que promuevan ambientes laborales estables, seguros y\nbien remunerados en busca de fortalecer el empleo pleno y productivo dentro del\nmunicipio.'),
(17, 7, '2.3.A', 'Implementar políticas y acciones directas que impulsen el desarrollo turístico\nsostenible en el municipio'),
(18, 8, '3.1.A', 'Impulsar el desarrollo integral de las familias mediante esquemas asistenciales\nque les permitan desarrollar sus propias habilidades para construir una sociedad\nmás igualitaria, que brinde estabilidad y paz social.'),
(19, 9, '3.2.A', 'Impulsar el aprendizaje y el conocimiento como el objetivo principal del desarrollo\nsocial a través de la generación de programas tendientes a evitar la deserción en los\nniveles primarios y secundarios de educación escolar.'),
(20, 10, '3.3.A', 'Fortalecer hábitos y estilos de vida saludable en la ciudadanía, con especial\nénfasis en aquella que es vulnerable, mediante programas que fortalezcan la salud\npropia y la del entorno.'),
(21, 10, '3.3.B', 'Ampliar la cobertura de servicios de salud, fortalecer las campañas de prevención\ny control de enfermedades, así como servicios funerarios en la población del municipio.'),
(22, 10, '3.3.C', 'Fortalecer las campañas que conduzcan al abandono definitivo de las conductas\nadictivas de sustancias tóxicas o comportamientos psicopatológicos, a fin de recuperar\nla salud tanto psíquica como somática.'),
(23, 11, '3.4.A', 'Propiciar espacios y ambientes favorables para la formación de actividades\nartísticas y culturales que permitan regenerar el tejido social en el municipio.'),
(24, 12, '3.5.A', 'Desarrollar e impulsar políticas públicas a favor de los jóvenes para otorgarles\nlas herramientas necesarias en educación, salud, empleo y participación social.'),
(25, 12, '3.5.B', 'Acondicionar los espacios, así como difundir las políticas y lineamientos para\nlas prácticas deportivas que permitan el desarrollo de los fundamentos técnicos,\ntácticos y psicológicos para cada deporte, así como involucrar a la población en la\npráctica de la actividad física para lograr la detección de talentos deportivos.'),
(26, 13, '3.6.A', 'Contribuir a los esfuerzo para erradicar todas las formas de discriminación y\nviolencia contra todas las mujeres y las niñas en los ámbitos público y privado,\nincluidas la trata y la explotación sexual y otros tipos de explotación, así como\nproporcionar herramientas de prevención y promoción plena de los derechos de las\nmujeres en el municipio.'),
(27, 14, '3.7.A', 'Fortalecer y difundir políticas a fin de asegurar que los derechos de las niñas,\nniños y adolescentes les brinden la seguridad de estar protegidos en su desarrollo\ndentro del municipio.'),
(28, 15, '4.1.A', 'Implementar mecanismos que contribuyan a brindar seguridad y paz a la\nciudadanía garantizando el ejercicio pleno de los derechos humanos y un desarrollo\nsocial armónico.'),
(29, 16, '4.2.A', 'Fortalecer las políticas de prevención social de la violencia y la delincuencia\ncon participación ciudadana a fin de incrementar los niveles de seguridad en el\nmunicipio.'),
(30, 17, '4.3.A', 'Implementar operativos que permitan cumplir con la normatividad en materia de\nseguridad vial y tránsito, así como salvaguardar la integridad física de los peatones.'),
(31, 18, '4.4.A', 'Fortalecer los mecanismos de protección de las personas y su entorno ante la\neventualidad de los riesgos naturales o antropogénicos, a través de estrategias de\ngestión de riesgos de desastres y el fomento de la resiliencia, auxilio y restablecimiento\nen la población.'),
(32, 19, '5.1.A', 'Fomentar políticas de preservación del medio ambiente y la biodiversidad,\nmediante estrictos controles de los nuevos asentamientos y a las actividades destructivas\ny contaminantes, así como desarrollar acciones efectivas para la preservación de\nnuestros ecosistemas y hábitats dentro del municipio.'),
(33, 19, '5.1.B', 'Contribuir en la preservación, conservación y protección de la fauna silvestre\nfortaleciendo los procesos de rescate, rehabilitación, liberación y/o entrega de\nanimales a zonas protegidas o santuarios.'),
(34, 19, '5.1.C', 'Fortalecer mediante campañas de difusión y acciones la cultura al buen trato\na los animales, así como prevenir el abandono, maltrato y tenencia indebida de los\nmismos. Haciendo difusión a la idea proteccionista que mueva e incluya a toda la\nciudadanía.'),
(35, 20, '5.2.A', 'Integrar el Plan de Movilidad Urbana Sostenible que priorice la jerarquía de la\npirámide de movilidad, disminuir de forma considerable la congestión, ruido,\ncontaminación atmosférica, accidentes, así como la disminución del consumo de\nenergías no renovables, promoviendo el uso de vehículos no motorizados y de energías\nlimpias para reducir los tiempos de traslado.'),
(36, 21, '5.3.A', 'Establecer objetivos, directrices, políticas, estrategias, metas, programas,\nactuaciones y normas para orientar y administrar el desarrollo físico del territorio y la\nutilización del suelo de forma ordenada y sostenible en el tiempo.'),
(37, 22, '5.4.A', 'Desarrollar proyectos de infraestructura de manera que garanticen la sostenibilidad\nurbana, económica y financiera, social, ambiental, incluida la resiliencia climática\ndurante todo el ciclo de vida del proyecto para generar una ciudad ordenada, considerando\nel crecimiento acelerado de la población.'),
(38, 22, '5.4.B', 'Instrumentar políticas y acciones tendientes a proteger, restaurar, conservar y\ncatalogar los sitios y monumentos históricos de la ciudad.'),
(39, 23, '5.5.A', 'Brindar servicios municipales económicos, eficientes y equitativos mediante la\nadecuada planeación, organización y seguimiento a la prestación oportuna y con\nresponsabilidad, mostrando una evolución paulatina de la administración pública\nhacia la mejora continua, con el objetivo de optimizar las condiciones en que se\nentregan los servicios a los ciudadanos.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catOdsMetas`
--

CREATE TABLE `pmd_catOdsMetas` (
  `idOdsMetas` int(11) NOT NULL,
  `objetivoOdsId` int(11) DEFAULT NULL,
  `cveOdsMetas` varchar(8) DEFAULT NULL,
  `ordenOdsMetas` varchar(8) DEFAULT NULL,
  `OdsMeta` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catOdsMetas`
--

INSERT INTO `pmd_catOdsMetas` (`idOdsMetas`, `objetivoOdsId`, `cveOdsMetas`, `ordenOdsMetas`, `OdsMeta`) VALUES
(1, 1, '1.1', '1', 'Para 2030, erradicar la pobreza extrema para todas las personas en el mundo, actualmente medida por un ingreso por persona inferior a 1,25 dólares al día.'),
(2, 1, '1.2', '2', 'Para 2030, reducir al menos a la mitad la proporción de hombres, mujeres y niños y niñas de todas las edades que viven en la pobreza en todas sus dimensiones con arreglo a las definiciones nacionales.'),
(3, 1, '1.3', '3', 'Poner en práctica a nivel nacional sistemas y medidas apropiadas de protección social para todos y, para 2030, lograr una amplia cobertura de los pobres y los más vulnerables.'),
(4, 1, '1.4', '4', 'Para 2030, garantizar que todos los hombres y mujeres, en particular los pobres y los más vulnerables, tengan los mismos derechos a los recursos económicos, así como acceso a los servicios básicos, la propiedad y el control de las tierras y otros bienes, la herencia, los recursos naturales, las nuevas tecnologías y los servicios económicos, incluida la microfinanciación.'),
(5, 1, '1.5', '5', 'Para 2030, fomentar la resiliencia de los pobres y las personas que se encuentran en situaciones vulnerables y reducir su exposición y vulnerabilidad a los fenómenos extremos relacionados con el clima y a otros desastres económicos, sociales y ambientales.'),
(6, 1, '1.a', 'a', 'Garantizar una movilización importante de recursos procedentes de diversas fuentes, incluso mediante la mejora de la cooperación para el desarrollo, a fin de proporcionar medios suficientes y previsibles para los países en desarrollo, en particular los países menos adelantados, para poner en práctica programas y políticas encaminados a poner fin a la pobreza en todas sus dimensiones.'),
(7, 1, '1.b', 'b', 'Crear marcos normativos sólidos en el ámbito nacional, regional e internacional, sobre la base de estrategias de desarrollo en favor de los pobres que tengan en cuenta las cuestiones de género, a fin de apoyar la inversión acelerada en medidas para erradicar la pobreza.'),
(8, 2, '2.1', '1', 'Para 2030, poner fin al hambre y asegurar el acceso de todas las personas, en particular los pobres y las personas en situaciones vulnerables, incluidos los lactantes, a una alimentación sana, nutritiva y suficiente durante todo el año'),
(9, 2, '2.2', '2', 'Para 2030, poner fin a todas las formas de malnutrición, incluso logrando, a más tardar en 2025, las metas convenidas internacionalmente sobre el retraso del crecimiento y la emaciación de los niños menores de 5 años, y abordar las necesidades de nutrición de las adolescentes, las mujeres embarazadas y lactantes y las personas de edad'),
(10, 2, '2.3', '3', 'Para 2030, duplicar la productividad agrícola y los ingresos de los productores de alimentos en pequeña escala, en particular las mujeres, los pueblos indígenas, los agricultores familiares, los pastores y los pescadores, entre otras cosas mediante un acceso seguro y equitativo a las tierras, a otros recursos de producción e insumos, conocimientos, servicios financieros, mercados y oportunidades para la generación de valor añadido y empleos no agrícolas'),
(11, 2, '2.4', '4', 'Para 2030, asegurar la sostenibilidad de los sistemas de producción de alimentos y aplicar prácticas agrícolas resilientes que aumenten la productividad y la producción, contribuyan al mantenimiento de los ecosistemas, fortalezcan la capacidad de adaptación al cambio climático, los fenómenos meteorológicos extremos, las sequías, las inundaciones y otros desastres, y mejoren progresivamente la calidad del suelo y la tierra'),
(12, 2, '2.5', '5', 'Para 2020, mantener la diversidad genética de las semillas, las plantas cultivadas y los animales de granja y domesticados y sus especies silvestres conexas, entre otras cosas mediante una buena gestión y diversificación de los bancos de semillas y plantas a nivel nacional, regional e internacional, y promover el acceso a los beneficios que se deriven de la utilización de los recursos genéticos y los conocimientos tradicionales y su distribución justa y equitativa, como se ha convenido internacionalmente'),
(13, 2, '2.a', 'a', 'Aumentar las inversiones, incluso mediante una mayor cooperación internacional, en la infraestructura rural, la investigación agrícola y los servicios de extensión, el desarrollo tecnológico y los bancos de genes de plantas y ganado a fin de mejorar la capacidad de producción agrícola en los países en desarrollo, en particular en los países menos adelantados'),
(14, 2, '2.b', 'b', 'Corregir y prevenir las restricciones y distorsiones comerciales en los mercados agropecuarios mundiales, entre otras cosas mediante la eliminación paralela de todas las formas de subvenciones a las exportaciones agrícolas y todas las medidas de exportación con efectos equivalentes, de conformidad con el mandato de la Ronda de Doha para el Desarrollo'),
(15, 2, '2.c', 'c', 'Adoptar medidas para asegurar el buen funcionamiento de los mercados de productos básicos alimentarios y sus derivados y facilitar el acceso oportuno a información sobre los mercados, en particular sobre las reservas de alimentos, a fin de ayudar a limitar la extrema volatilidad de los precios de los alimentos'),
(16, 3, '3.1', '1', 'Para 2030, reducir la tasa mundial de mortalidad materna a menos de 70 por cada 100.000 nacidos vivos'),
(17, 3, '3.2', '2', 'Para 2030, poner fin a las muertes evitables de recién nacidos y de niños menores de 5 años, logrando que todos los países intenten reducir la mortalidad neonatal al menos hasta 12 por cada 1.000 nacidos vivos, y la mortalidad de niños menores de 5 años al menos hasta 25 por cada 1.000 nacidos vivos'),
(18, 3, '3.3', '3', 'Para 2030, poner fin a las epidemias del SIDA, la tuberculosis, la malaria y las enfermedades tropicales desatendidas y combatir la hepatitis, las enfermedades transmitidas por el agua y otras enfermedades transmisibles'),
(19, 3, '3.4', '4', 'Para 2030, reducir en un tercio la mortalidad prematura por enfermedades no transmisibles mediante la prevención y el tratamiento y promover la salud mental y el bienestar'),
(20, 3, '3.5', '5', 'Fortalecer la prevención y el tratamiento del abuso de sustancias adictivas, incluido el uso indebido de estupefacientes y el consumo nocivo de alcohol'),
(21, 3, '3.6', '6', 'Para 2020, reducir a la mitad el número de muertes y lesiones causadas por accidentes de tráfico en el mundo'),
(22, 3, '3.7', '7', 'Para 2030, garantizar el acceso universal a los servicios de salud sexual y reproductiva, incluidos los de planificación de la familia, información y educación, y la integración de la salud reproductiva en las estrategias y los programas nacionales'),
(23, 3, '3.8', '8', 'Lograr la cobertura sanitaria universal, en particular la protección contra los riesgos financieros, el acceso a servicios de salud esenciales de calidad y el acceso a medicamentos y vacunas seguros, eficaces, asequibles y de calidad para todos'),
(24, 3, '3.9', '9', 'Para 2030, reducir sustancialmente el número de muertes y enfermedades producidas por productos químicos peligrosos y la contaminación del aire, el agua y el suelo'),
(25, 3, '3.a', 'a', 'Fortalecer la aplicación del Convenio Marco de la Organización Mundial de la Salud para el Control del Tabaco en todos los países, según proceda'),
(26, 3, '3.b', 'b', 'Apoyar las actividades de investigación y desarrollo de vacunas y medicamentos para las enfermedades transmisibles y no transmisibles que afectan primordialmente a los países en desarrollo y facilitar el acceso a medicamentos y vacunas esenciales asequibles de conformidad con la Declaración de Doha relativa al Acuerdo sobre los ADPIC y la Salud Pública, en la que se afirma el derecho de los países en desarrollo a utilizar al máximo las disposiciones del Acuerdo sobre los Aspectos de los Derechos de Propiedad Intelectual Relacionados con el Comercio en lo relativo a la flexibilidad para proteger la salud pública y, en particular, proporcionar acceso a los medicamentos para todos'),
(27, 3, '3.c', 'c', 'Aumentar sustancialmente la financiación de la salud y la contratación, el desarrollo, la capacitación y la retención del personal sanitario en los países en desarrollo, especialmente en los países menos adelantados y los pequeños Estados insulares en desarrollo'),
(28, 3, '3.d', 'd', 'Reforzar la capacidad de todos los países, en particular los países en desarrollo, en materia de alerta temprana, reducción de riesgos y gestión de los riesgos para la salud nacional y mundial'),
(29, 4, '4.1', '1', 'De aquí a 2030, asegurar que todas las niñas y todos los niños terminen la enseñanza primaria y secundaria, que ha de ser gratuita, equitativa y de calidad y producir resultados de aprendizaje pertinentes y efectivos'),
(30, 4, '4.2', '2', 'De aquí a 2030, asegurar que todas las niñas y todos los niños tengan acceso a servicios de atención y desarrollo en la primera infancia y educación preescolar de calidad, a fin de que estén preparados para la enseñanza primaria'),
(31, 4, '4.3', '3', 'De aquí a 2030, asegurar el acceso igualitario de todos los hombres y las mujeres a una formación técnica, profesional y superior de calidad, incluida la enseñanza universitaria'),
(32, 4, '4.4', '4', 'De aquí a 2030, aumentar considerablemente el número de jóvenes y adultos que tienen las competencias necesarias, en particular técnicas y profesionales, para acceder al empleo, el trabajo decente y el emprendimiento'),
(33, 4, '4.5', '5', 'De aquí a 2030, eliminar las disparidades de género en la educación y asegurar el acceso igualitario a todos los niveles de la enseñanza y la formación profesional para las personas vulnerables, incluidas las personas con discapacidad, los pueblos indígenas y los niños en situaciones de vulnerabilidad'),
(34, 4, '4.6', '6', 'De aquí a 2030, asegurar que todos los jóvenes y una proporción considerable de los adultos, tanto hombres como mujeres, estén alfabetizados y tengan nociones elementales de aritmética'),
(35, 4, '4.7', '7', 'De aquí a 2030, asegurar que todos los alumnos adquieran los conocimientos teóricos y prácticos necesarios para promover el desarrollo sostenible, entre otras cosas mediante la educación para el desarrollo sostenible y los estilos de vida sostenibles, los derechos humanos, la igualdad de género, la promoción de una cultura de paz y no violencia, la ciudadanía mundial y la valoración de la diversidad cultural y la contribución de la cultura al desarrollo sostenible'),
(36, 4, '4.a', 'a', 'Construir y adecuar instalaciones educativas que tengan en cuenta las necesidades de los niños y las personas con discapacidad y las diferencias de género, y que ofrezcan entornos de aprendizaje seguros, no violentos, inclusivos y eficaces para todos'),
(37, 4, '4.b', 'b', 'De aquí a 2020, aumentar considerablemente a nivel mundial el número de becas disponibles para los países en desarrollo, en particular los países menos adelantados, los pequeños Estados insulares en desarrollo y los países africanos, a fin de que sus estudiantes puedan matricularse en programas de enseñanza superior, incluidos programas de formación profesional y programas técnicos, científicos, de ingeniería y de tecnología de la información y las comunicaciones, de países desarrollados y otros países en desarrollo'),
(38, 4, '4.c', 'c', 'De aquí a 2030, aumentar considerablemente la oferta de docentes calificados, incluso mediante la cooperación internacional para la formación de docentes en los países en desarrollo, especialmente los países menos adelantados y los pequeños Estados insulares en desarrollo'),
(39, 5, '5.1', '1', 'Poner fin a todas las formas de discriminación contra todas las mujeres y las niñas en todo el mundo'),
(40, 5, '5.2', '2', 'Eliminar todas las formas de violencia contra todas las mujeres y las niñas en los ámbitos público y privado, incluidas la trata y la explotación sexual y otros tipos de explotación'),
(41, 5, '5.3', '3', 'Eliminar todas las prácticas nocivas, como el matrimonio infantil, precoz y forzado y la mutilación genital femenina'),
(42, 5, '5.4', '4', 'Reconocer y valorar los cuidados y el trabajo doméstico no remunerados mediante servicios públicos, infraestructuras y políticas de protección social, y promoviendo la responsabilidad compartida en el hogar y la familia, según proceda en cada país'),
(43, 5, '5.5', '5', 'Asegurar la participación plena y efectiva de las mujeres y la igualdad de oportunidades de liderazgo a todos los niveles decisorios en la vida política, económica y pública'),
(44, 5, '5.6', '6', 'Asegurar el acceso universal a la salud sexual y reproductiva y los derechos reproductivos según lo acordado de conformidad con el Programa de Acción de la Conferencia Internacional sobre la Población y el Desarrollo, la Plataforma de Acción de Beijing y los documentos finales de sus conferencias de examen'),
(45, 5, '5.a', 'a', 'Emprender reformas que otorguen a las mujeres igualdad de derechos a los recursos económicos, así como acceso a la propiedad y al control de la tierra y otros tipos de bienes, los servicios financieros, la herencia y los recursos naturales, de conformidad con las leyes nacionales'),
(46, 5, '5.b', 'b', 'Mejorar el uso de la tecnología instrumental, en particular la tecnología de la información y las comunicaciones, para promover el empoderamiento de las mujeres'),
(47, 5, '5.c', 'c', 'Aprobar y fortalecer políticas acertadas y leyes aplicables para promover la igualdad de género y el empoderamiento de todas las mujeres y las niñas a todos los niveles'),
(48, 6, '6.1', '1', 'De aquí a 2030, lograr el acceso universal y equitativo al agua potable a un precio asequible para todos'),
(49, 6, '6.2', '2', 'De aquí a 2030, lograr el acceso a servicios de saneamiento e higiene adecuados y equitativos para todos y poner fin a la defecación al aire libre, prestando especial atención a las necesidades de las mujeres y las niñas y las personas en situaciones de vulnerabilidad'),
(50, 6, '6.3', '3', 'De aquí a 2030, mejorar la calidad del agua reduciendo la contaminación, eliminando el vertimiento y minimizando la emisión de productos químicos y materiales peligrosos, reduciendo a la mitad el porcentaje de aguas residuales sin tratar y aumentando considerablemente el reciclado y la reutilización sin riesgos a nivel mundial'),
(51, 6, '6.4', '4', 'De aquí a 2030, aumentar considerablemente el uso eficiente de los recursos hídricos en todos los sectores y asegurar la sostenibilidad de la extracción y el abastecimiento de agua dulce para hacer frente a la escasez de agua y reducir considerablemente el número de personas que sufren falta de agua'),
(52, 6, '6.5', '5', 'De aquí a 2030, implementar la gestión integrada de los recursos hídricos a todos los niveles, incluso mediante la cooperación transfronteriza, según proceda'),
(53, 6, '6.6', '6', 'De aquí a 2020, proteger y restablecer los ecosistemas relacionados con el agua, incluidos los bosques, las montañas, los humedales, los ríos, los acuíferos y los lagos'),
(54, 6, '6.a', 'a', 'De aquí a 2030, ampliar la cooperación internacional y el apoyo prestado a los países en desarrollo para la creación de capacidad en actividades y programas relativos al agua y el saneamiento, como los de captación de agua, desalinización, uso eficiente de los recursos hídricos, tratamiento de aguas residuales, reciclado y tecnologías de reutilización'),
(55, 6, '6.b', 'b', 'Apoyar y fortalecer la participación de las comunidades locales en la mejora de la gestión del agua y el saneamiento'),
(56, 7, '7.1', '1', 'De aquí a 2030, garantizar el acceso universal a servicios energéticos asequibles, fiables y modernos'),
(57, 7, '7.2', '2', 'De aquí a 2030, aumentar considerablemente la proporción de energía renovable en el conjunto de fuentes energéticas'),
(58, 7, '7.3', '3', 'De aquí a 2030, duplicar la tasa mundial de mejora de la eficiencia energética'),
(59, 7, '7.a', 'a', 'De aquí a 2030, aumentar la cooperación internacional para facilitar el acceso a la investigación y la tecnología relativas a la energía limpia, incluidas las fuentes renovables, la eficiencia energética y las tecnologías avanzadas y menos contaminantes de combustibles fósiles, y promover la inversión en infraestructura energética y tecnologías limpias'),
(60, 7, '7.b', 'b', 'De aquí a 2030, ampliar la infraestructura y mejorar la tecnología para prestar servicios energéticos modernos y sostenibles para todos en los países en desarrollo, en particular los países menos adelantados, los pequeños Estados insulares en desarrollo y los países en desarrollo sin litoral, en consonancia con sus respectivos programas de apoyo'),
(61, 8, '8.1', '1', 'Mantener el crecimiento económico per capita de conformidad con las circunstancias nacionales y, en particular, un crecimiento del producto interno bruto de al menos el 7% anual en los países menos adelantados'),
(62, 8, '8.2', '2', 'Lograr niveles más elevados de productividad económica mediante la diversificación, la modernización tecnológica y la innovación, entre otras cosas centrándose en los sectores con gran valor añadido y un uso intensivo de la mano de obra'),
(63, 8, '8.3', '3', 'Promover políticas orientadas al desarrollo que apoyen las actividades productivas, la creación de puestos de trabajo decentes, el emprendimiento, la creatividad y la innovación, y fomentar la formalización y el crecimiento de las microempresas y las pequeñas y medianas empresas, incluso mediante el acceso a servicios financieros'),
(64, 8, '8.4', '4', 'Mejorar progresivamente, de aquí a 2030, la producción y el consumo eficientes de los recursos mundiales y procurar desvincular el crecimiento económico de la degradación del medio ambiente, conforme al Marco Decenal de Programas sobre modalidades de Consumo y Producción Sostenibles, empezando por los países desarrollados'),
(65, 8, '8.5', '5', 'De aquí a 2030, lograr el empleo pleno y productivo y el trabajo decente para todas las mujeres y los hombres, incluidos los jóvenes y las personas con discapacidad, así como la igualdad de remuneración por trabajo de igual valor'),
(66, 8, '8.6', '6', 'De aquí a 2020, reducir considerablemente la proporción de jóvenes que no están empleados y no cursan estudios ni reciben capacitación'),
(67, 8, '8.7', '7', 'Adoptar medidas inmediatas y eficaces para erradicar el trabajo forzoso, poner fin a las formas contemporáneas de esclavitud y la trata de personas y asegurar la prohibición y eliminación de las peores formas de trabajo infantil, incluidos el reclutamiento y la utilización de niños soldados, y, de aquí a 2025, poner fin al trabajo infantil en todas sus formas'),
(68, 8, '8.8', '8', 'Proteger los derechos laborales y promover un entorno de trabajo seguro y sin riesgos para todos los trabajadores, incluidos los trabajadores migrantes, en particular las mujeres migrantes y las personas con empleos precarios'),
(69, 8, '8.9', '9', 'De aquí a 2030, elaborar y poner en práctica políticas encaminadas a promover un turismo sostenible que cree puestos de trabajo y promueva la cultura y los productos locales'),
(70, 8, '8.1', '10', 'Fortalecer la capacidad de las instituciones financieras nacionales para fomentar y ampliar el acceso a los servicios bancarios, financieros y de seguros para todos'),
(71, 8, '8.a', 'a', 'Aumentar el apoyo a la iniciativa de ayuda para el comercio en los países en desarrollo, en particular los países menos adelantados, incluso mediante el Marco Integrado Mejorado para la Asistencia Técnica a los Países Menos Adelantados en Materia de Comercio'),
(72, 8, '8.b', 'b', 'De aquí a 2020, desarrollar y poner en marcha una estrategia mundial para el empleo de los jóvenes y aplicar el Pacto Mundial para el Empleo de la Organización Internacional del Trabajo'),
(73, 9, '9.1', '1', 'Desarrollar infraestructuras fiables, sostenibles, resilientes y de calidad, incluidas infraestructuras regionales y transfronterizas, para apoyar el desarrollo económico y el bienestar humano, haciendo especial hincapié en el acceso asequible y equitativo para todos'),
(74, 9, '9.2', '2', 'Promover una industrialización inclusiva y sostenible y, de aquí a 2030, aumentar significativamente la contribución de la industria al empleo y al producto interno bruto, de acuerdo con las circunstancias nacionales, y duplicar esa contribución en los países menos adelantados'),
(75, 9, '9.3', '3', 'Aumentar el acceso de las pequeñas industrias y otras empresas, particularmente en los países en desarrollo, a los servicios financieros, incluidos créditos asequibles, y su integración en las cadenas de valor y los mercados'),
(76, 9, '9.4', '4', 'De aquí a 2030, modernizar la infraestructura y reconvertir las industrias para que sean sostenibles, utilizando los recursos con mayor eficacia y promoviendo la adopción de tecnologías y procesos industriales limpios y ambientalmente racionales, y logrando que todos los países tomen medidas de acuerdo con sus capacidades respectivas'),
(77, 9, '9.5', '5', 'Aumentar la investigación científica y mejorar la capacidad tecnológica de los sectores industriales de todos los países, en particular los países en desarrollo, entre otras cosas fomentando la innovación y aumentando considerablemente, de aquí a 2030, el número de personas que trabajan en investigación y desarrollo por millón de habitantes y los gastos de los sectores público y privado en investigación y desarrollo'),
(78, 9, '9.a', 'a', 'Facilitar el desarrollo de infraestructuras sostenibles y resilientes en los países en desarrollo mediante un mayor apoyo financiero, tecnológico y técnico a los países africanos, los países menos adelantados, los países en desarrollo sin litoral y los pequeños Estados insulares en desarrollo'),
(79, 9, '9.b', 'b', 'Apoyar el desarrollo de tecnologías, la investigación y la innovación nacionales en los países en desarrollo, incluso garantizando un entorno normativo propicio a la diversificación industrial y la adición de valor a los productos básicos, entre otras cosas'),
(80, 9, '9.c', 'c', 'Aumentar significativamente el acceso a la tecnología de la información y las comunicaciones y esforzarse por proporcionar acceso universal y asequible a Internet en los países menos adelantados de aquí a 2020'),
(81, 10, '10.1', '1', 'De aquí a 2030, lograr progresivamente y mantener el crecimiento de los ingresos del 40% más pobre de la población a una tasa superior a la media nacional'),
(82, 10, '10.2', '2', 'De aquí a 2030, potenciar y promover la inclusión social, económica y política de todas las personas, independientemente de su edad, sexo, discapacidad, raza, etnia, origen, religión o situación económica u otra condición'),
(83, 10, '10.3', '3', 'Garantizar la igualdad de oportunidades y reducir la desigualdad de resultados, incluso eliminando las leyes, políticas y prácticas discriminatorias y promoviendo legislaciones, políticas y medidas adecuadas a ese respecto'),
(84, 10, '10.4', '4', 'Adoptar políticas, especialmente fiscales, salariales y de protección social, y lograr progresivamente una mayor igualdad'),
(85, 10, '10.5', '5', 'Mejorar la reglamentación y vigilancia de las instituciones y los mercados financieros mundiales y fortalecer la aplicación de esos reglamentos'),
(86, 10, '10.6', '6', 'Asegurar una mayor representación e intervención de los países en desarrollo en las decisiones adoptadas por las instituciones económicas y financieras internacionales para aumentar la eficacia, fiabilidad, rendición de cuentas y legitimidad de esas instituciones'),
(87, 10, '10.7', '7', 'Facilitar la migración y la movilidad ordenadas, seguras, regulares y responsables de las personas, incluso mediante la aplicación de políticas migratorias planificadas y bien gestionadas'),
(88, 10, '10.a', 'a', 'Aplicar el principio del trato especial y diferenciado para los países en desarrollo, en particular los países menos adelantados, de conformidad con los acuerdos de la Organización Mundial del Comercio'),
(89, 10, '10.b', 'b', 'Fomentar la asistencia oficial para el desarrollo y las corrientes financieras, incluida la inversión extranjera directa, para los Estados con mayores necesidades, en particular los países menos adelantados, los países africanos, los pequeños Estados insulares en desarrollo y los países en desarrollo sin litoral, en consonancia con sus planes y programas nacionales'),
(90, 10, '10.c', 'c', 'De aquí a 2030, reducir a menos del 3% los costos de transacción de las remesas de los migrantes y eliminar los corredores de remesas con un costo superior al 5%'),
(91, 11, '11.1', '1', 'De aquí a 2030, asegurar el acceso de todas las personas a viviendas y servicios básicos adecuados, seguros y asequibles y mejorar los barrios marginales'),
(92, 11, '11.2', '2', 'De aquí a 2030, proporcionar acceso a sistemas de transporte seguros, asequibles, accesibles y sostenibles para todos y mejorar la seguridad vial, en particular mediante la ampliación del transporte público, prestando especial atención a las necesidades de las personas en situación de vulnerabilidad, las mujeres, los niños, las personas con discapacidad y las personas de edad'),
(93, 11, '11.3', '3', 'De aquí a 2030, aumentar la urbanización inclusiva y sostenible y la capacidad para la planificación y la gestión participativas, integradas y sostenibles de los asentamientos humanos en todos los países'),
(94, 11, '11.4', '4', 'Redoblar los esfuerzos para proteger y salvaguardar el patrimonio cultural y natural del mundo'),
(95, 11, '11.5', '5', 'De aquí a 2030, reducir significativamente el número de muertes causadas por los desastres, incluidos los relacionados con el agua, y de personas afectadas por ellos, y reducir considerablemente las pérdidas económicas directas provocadas por los desastres en comparación con el producto interno bruto mundial, haciendo especial hincapié en la protección de los pobres y las personas en situaciones de vulnerabilidad'),
(96, 11, '11.6', '6', 'De aquí a 2030, reducir el impacto ambiental negativo per capita de las ciudades, incluso prestando especial atención a la calidad del aire y la gestión de los desechos municipales y de otro tipo'),
(97, 11, '11.7', '7', 'De aquí a 2030, proporcionar acceso universal a zonas verdes y espacios públicos seguros, inclusivos y accesibles, en particular para las mujeres y los niños, las personas de edad y las personas con discapacidad'),
(98, 11, '11.a', 'a', 'Apoyar los vínculos económicos, sociales y ambientales positivos entre las zonas urbanas, periurbanas y rurales fortaleciendo la planificación del desarrollo nacional y regional'),
(99, 11, '11.b', 'b', 'De aquí a 2020, aumentar considerablemente el número de ciudades y asentamientos humanos que adoptan e implementan políticas y planes integrados para promover la inclusión, el uso eficiente de los recursos, la mitigación del cambio climático y la adaptación a él y la resiliencia ante los desastres, y desarrollar y poner en práctica, en consonancia con el Marco de Sendai para la Reducción del Riesgo de Desastres 2015-2030, la gestión integral de los riesgos de desastre a todos los niveles'),
(100, 11, '11.c', 'c', 'Proporcionar apoyo a los países menos adelantados, incluso mediante asistencia financiera y técnica, para que puedan construir edificios sostenibles y resilientes utilizando materiales locales'),
(101, 12, '12.1', '1', 'Aplicar el Marco Decenal de Programas sobre Modalidades de Consumo y Producción Sostenibles, con la participación de todos los países y bajo el liderazgo de los países desarrollados, teniendo en cuenta el grado de desarrollo y las capacidades de los países en desarrollo'),
(102, 12, '12.2', '2', 'De aquí a 2030, lograr la gestión sostenible y el uso eficiente de los recursos naturales'),
(103, 12, '12.3', '3', 'De aquí a 2030, reducir a la mitad el desperdicio de alimentos per capita mundial en la venta al por menor y a nivel de los consumidores y reducir las pérdidas de alimentos en las cadenas de producción y suministro, incluidas las pérdidas posteriores a la cosecha'),
(104, 12, '12.4', '4', 'De aquí a 2020, lograr la gestión ecológicamente racional de los productos químicos y de todos los desechos a lo largo de su ciclo de vida, de conformidad con los marcos internacionales convenidos, y reducir significativamente su liberación a la atmósfera, el agua y el suelo a fin de minimizar sus efectos adversos en la salud humana y el medio ambiente'),
(105, 12, '12.5', '5', 'De aquí a 2030, reducir considerablemente la generación de desechos mediante actividades de prevención, reducción, reciclado y reutilización'),
(106, 12, '12.6', '6', 'Alentar a las empresas, en especial las grandes empresas y las empresas transnacionales, a que adopten prácticas sostenibles e incorporen información sobre la sostenibilidad en su ciclo de presentación de informes'),
(107, 12, '12.7', '7', 'Promover prácticas de adquisición pública que sean sostenibles, de conformidad con las políticas y prioridades nacionales'),
(108, 12, '12.8', '8', 'De aquí a 2030, asegurar que las personas de todo el mundo tengan la información y los conocimientos pertinentes para el desarrollo sostenible y los estilos de vida en armonía con la naturaleza'),
(109, 12, '12.a', 'a', 'Ayudar a los países en desarrollo a fortalecer su capacidad científica y tecnológica para avanzar hacia modalidades de consumo y producción más sostenibles'),
(110, 12, '12.b', 'b', 'Elaborar y aplicar instrumentos para vigilar los efectos en el desarrollo sostenible, a fin de lograr un turismo sostenible que cree puestos de trabajo y promueva la cultura y los productos locales'),
(111, 12, '12.c', 'c', 'Racionalizar los subsidios ineficientes a los combustibles fósiles que fomentan el consumo antieconómico eliminando las distorsiones del mercado, de acuerdo con las circunstancias nacionales, incluso mediante la reestructuración de los sistemas tributarios y la eliminación gradual de los subsidios perjudiciales, cuando existan, para reflejar su impacto ambiental, teniendo plenamente en cuenta las necesidades y condiciones específicas de los países en desarrollo y minimizando los posibles efectos adversos en su desarrollo, de manera que se proteja a los pobres y a las comunidades afectadas'),
(112, 13, '13.1', '1', 'Fortalecer la resiliencia y la capacidad de adaptación a los riesgos relacionados con el clima y los desastres naturales en todos los países'),
(113, 13, '13.2', '2', 'Incorporar medidas relativas al cambio climático en las políticas, estrategias y planes nacionales'),
(114, 13, '13.3', '3', 'Mejorar la educación, la sensibilización y la capacidad humana e institucional respecto de la mitigación del cambio climático, la adaptación a él, la reducción de sus efectos y la alerta temprana'),
(115, 13, '13.a', 'a', 'Cumplir el compromiso de los países desarrollados que son partes en la Convención Marco de las Naciones Unidas sobre el Cambio Climático de lograr para el año 2020 el objetivo de movilizar conjuntamente 100.000 millones de dólares anuales procedentes de todas las fuentes a fin de atender las necesidades de los países en desarrollo respecto de la adopción de medidas concretas de mitigación y la transparencia de su aplicación, y poner en pleno funcionamiento el Fondo Verde para el Clima capitalizándolo lo antes posible'),
(116, 13, '13.b', 'b', 'Promover mecanismos para aumentar la capacidad para la planificación y gestión eficaces en relación con el cambio climático en los países menos adelantados y los pequeños Estados insulares en desarrollo, haciendo particular hincapié en las mujeres, los jóvenes y las comunidades locales y marginadas'),
(117, 14, '14.1', '1', 'De aquí a 2025, prevenir y reducir significativamente la contaminación marina de todo tipo, en particular la producida por actividades realizadas en tierra, incluidos los detritos marinos y la polución por nutrientes'),
(118, 14, '14.2', '2', 'De aquí a 2020, gestionar y proteger sosteniblemente los ecosistemas marinos y costeros para evitar efectos adversos importantes, incluso fortaleciendo su resiliencia, y adoptar medidas para restaurarlos a fin de restablecer la salud y la productividad de los océanos'),
(119, 14, '14.3', '3', 'Minimizar y abordar los efectos de la acidificación de los océanos, incluso mediante una mayor cooperación científica a todos los niveles'),
(120, 14, '14.4', '4', 'De aquí a 2020, reglamentar eficazmente la explotación pesquera y poner fin a la pesca excesiva, la pesca ilegal, no declarada y no reglamentada y las prácticas pesqueras destructivas, y aplicar planes de gestión con fundamento científico a fin de restablecer las poblaciones de peces en el plazo más breve posible, al menos alcanzando niveles que puedan producir el máximo rendimiento sostenible de acuerdo con sus características biológicas'),
(121, 14, '14.5', '5', 'De aquí a 2020, conservar al menos el 10% de las zonas costeras y marinas, de conformidad con las leyes nacionales y el derecho internacional y sobre la base de la mejor información científica disponible'),
(122, 14, '14.6', '6', 'De aquí a 2020, prohibir ciertas formas de subvenciones a la pesca que contribuyen a la sobrecapacidad y la pesca excesiva, eliminar las subvenciones que contribuyen a la pesca ilegal, no declarada y no reglamentada y abstenerse de introducir nuevas subvenciones de esa índole, reconociendo que la negociación sobre las subvenciones a la pesca en el marco de la Organización Mundial del Comercio debe incluir un trato especial y diferenciado, apropiado y efectivo para los países en desarrollo y los países menos adelantados ¹'),
(123, 14, '14.7', '7', 'De aquí a 2030, aumentar los beneficios económicos que los pequeños Estados insulares en desarrollo y los países menos adelantados obtienen del uso sostenible de los recursos marinos, en particular mediante la gestión sostenible de la pesca, la acuicultura y el turismo'),
(124, 14, '14.a', 'a', 'Aumentar los conocimientos científicos, desarrollar la capacidad de investigación y transferir tecnología marina, teniendo en cuenta los Criterios y Directrices para la Transferencia de Tecnología Marina de la Comisión Oceanográfica Intergubernamental, a fin de mejorar la salud de los océanos y potenciar la contribución de la biodiversidad marina al desarrollo de los países en desarrollo, en particular los pequeños Estados insulares en desarrollo y los países menos adelantados'),
(125, 14, '14.b', 'b', 'Facilitar el acceso de los pescadores artesanales a los recursos marinos y los mercados'),
(126, 14, '14.c', 'c', 'Mejorar la conservación y el uso sostenible de los océanos y sus recursos aplicando el derecho internacional reflejado en la Convención de las Naciones Unidas sobre el Derecho del Mar, que constituye el marco jurídico para la conservación y la utilización sostenible de los océanos y sus recursos, como se recuerda en el párrafo 158 del documento El futuro que queremos\"\"'),
(127, 15, '15.1', '1', 'Para 2020, velar por la conservación, el restablecimiento y el uso sostenible de los ecosistemas terrestres y los ecosistemas interiores de agua dulce y los servicios que proporcionan, en particular los bosques, los humedales, las montañas y las zonas áridas, en consonancia con las obligaciones contraídas en virtud de acuerdos internacionales'),
(128, 15, '15.2', '2', 'Para 2020, promover la gestión sostenible de todos los tipos de bosques, poner fin a la deforestación, recuperar los bosques degradados e incrementar la forestación y la reforestación a nivel mundial'),
(129, 15, '15.3', '3', 'Para 2030, luchar contra la desertificación, rehabilitar las tierras y los suelos degradados, incluidas las tierras afectadas por la desertificación, la sequía y las inundaciones, y procurar lograr un mundo con una degradación neutra del suelo'),
(130, 15, '15.4', '4', 'Para 2030, velar por la conservación de los ecosistemas montañosos, incluida su diversidad biológica, a fin de mejorar su capacidad de proporcionar beneficios esenciales para el desarrollo sostenible'),
(131, 15, '15.5', '5', 'Adoptar medidas urgentes y significativas para reducir la degradación de los hábitats naturales, detener la pérdida de la diversidad biológica y, para 2020, proteger las especies amenazadas y evitar su extinción'),
(132, 15, '15.6', '6', 'Promover la participación justa y equitativa en los beneficios que se deriven de la utilización de los recursos genéticos y promover el acceso adecuado a esos recursos, como se ha convenido internacionalmente'),
(133, 15, '15.7', '7', 'Adoptar medidas urgentes para poner fin a la caza furtiva y el tráfico de especies protegidas de flora y fauna y abordar la demanda y la oferta ilegales de productos silvestres'),
(134, 15, '15.8', '8', 'Para 2020, adoptar medidas para prevenir la introducción de especies exóticas invasoras y reducir de forma significativa sus efectos en los ecosistemas terrestres y acuáticos y controlar o erradicar las especies prioritarias'),
(135, 15, '15.9', '9', 'Para 2020, integrar los valores de los ecosistemas y la diversidad biológica en la planificación nacional y local, los procesos de desarrollo, las estrategias de reducción de la pobreza y la contabilidad'),
(136, 15, '15.a', 'a', 'Movilizar y aumentar de manera significativa los recursos financieros procedentes de todas las fuentes para conservar y utilizar de forma sostenible la diversidad biológica y los ecosistemas'),
(137, 15, '15.b', 'b', 'Movilizar un volumen apreciable de recursos procedentes de todas las fuentes y a todos los niveles para financiar la gestión forestal sostenible y proporcionar incentivos adecuados a los países en desarrollo para que promuevan dicha gestión, en particular con miras a la conservación y la reforestación'),
(138, 15, '15.c', 'c', 'Aumentar el apoyo mundial a la lucha contra la caza furtiva y el tráfico de especies protegidas, en particular aumentando la capacidad de las comunidades locales para promover oportunidades de subsistencia sostenibles'),
(139, 16, '16.1', '1', 'Reducir significativamente todas las formas de violencia y las correspondientes tasas de mortalidad en todo el mundo'),
(140, 16, '16.2', '2', 'Poner fin al maltrato, la explotación, la trata y todas las formas de violencia y tortura contra los niños'),
(141, 16, '16.3', '3', 'Promover el estado de derecho en los planos nacional e internacional y garantizar la igualdad de acceso a la justicia para todos'),
(142, 16, '16.4', '4', 'De aquí a 2030, reducir significativamente las corrientes financieras y de armas ilícitas, fortalecer la recuperación y devolución de los activos robados y luchar contra todas las formas de delincuencia organizada'),
(143, 16, '16.5', '5', 'Reducir considerablemente la corrupción y el soborno en todas sus formas'),
(144, 16, '16.6', '6', 'Crear a todos los niveles instituciones eficaces y transparentes que rindan cuentas'),
(145, 16, '16.7', '7', 'Garantizar la adopción en todos los niveles de decisiones inclusivas, participativas y representativas que respondan a las necesidades'),
(146, 16, '16.8', '8', 'Ampliar y fortalecer la participación de los países en desarrollo en las instituciones de gobernanza mundial'),
(147, 16, '16.9', '9', 'De aquí a 2030, proporcionar acceso a una identidad jurídica para todos, en particular mediante el registro de nacimientos'),
(148, 16, '16.1', '10', 'Garantizar el acceso público a la información y proteger las libertades fundamentales, de conformidad con las leyes nacionales y los acuerdos internacionales'),
(149, 16, '16.a', 'a', 'Fortalecer las instituciones nacionales pertinentes, incluso mediante la cooperación internacional, para crear a todos los niveles, particularmente en los países en desarrollo, la capacidad de prevenir la violencia y combatir el terrorismo y la delincuencia'),
(150, 16, '16.b', 'b', 'Promover y aplicar leyes y políticas no discriminatorias en favor del desarrollo sostenible'),
(151, 17, '17.1', '1', 'Fortalecer la movilización de recursos internos, incluso mediante la prestación de apoyo internacional a los países en desarrollo, con el fin de mejorar la capacidad nacional para recaudar ingresos fiscales y de otra índole'),
(152, 17, '17.2', '2', 'Velar por que los países desarrollados cumplan plenamente sus compromisos en relación con la asistencia oficial para el desarrollo, incluido el compromiso de numerosos países desarrollados de alcanzar el objetivo de destinar el 0,7% del ingreso nacional bruto a la asistencia oficial para el desarrollo de los países en desarrollo y entre el 0,15% y el 0,20% del ingreso nacional bruto a la asistencia oficial para el desarrollo de los países menos adelantados; se alienta a los proveedores de asistencia oficial para el desarrollo a que consideren la posibilidad de fijar una meta para destinar al menos el 0,20% del ingreso nacional bruto a la asistencia oficial para el desarrollo de los países menos adelantados'),
(153, 17, '17.3', '3', 'Movilizar recursos financieros adicionales de múltiples fuentes para los países en desarrollo'),
(154, 17, '17.4', '4', 'Ayudar a los países en desarrollo a lograr la sostenibilidad de la deuda a largo plazo con políticas coordinadas orientadas a fomentar la financiación, el alivio y la reestructuración de la deuda, según proceda, y hacer frente a la deuda externa de los países pobres muy endeudados a fin de reducir el endeudamiento excesivo'),
(155, 17, '17.5', '5', 'Adoptar y aplicar sistemas de promoción de las inversiones en favor de los países menos adelantados'),
(156, 17, '17.6', '6', 'Mejorar la cooperación regional e internacional Norte-Sur, Sur-Sur y triangular en materia de ciencia, tecnología e innovación y el acceso a estas, y aumentar el intercambio de conocimientos en condiciones mutuamente convenidas, incluso mejorando la coordinación entre los mecanismos existentes, en particular a nivel de las Naciones Unidas, y mediante un mecanismo mundial de facilitación de la tecnología'),
(157, 17, '17.7', '7', 'Promover el desarrollo de tecnologías ecológicamente racionales y su transferencia, divulgación y difusión a los países en desarrollo en condiciones favorables, incluso en condiciones concesionarias y preferenciales, según lo convenido de mutuo acuerdo'),
(158, 17, '17.8', '8', 'Poner en pleno funcionamiento, a más tardar en 2017, el banco de tecnología y el mecanismo de apoyo a la creación de capacidad en materia de ciencia, tecnología e innovación para los países menos adelantados y aumentar la utilización de tecnologías instrumentales, en particular la tecnología de la información y las comunicaciones'),
(159, 17, '17.9', '9', 'Aumentar el apoyo internacional para realizar actividades de creación de capacidad eficaces y específicas en los países en desarrollo a fin de respaldar los planes nacionales de implementación de todos los Objetivos de Desarrollo Sostenible, incluso mediante la cooperación Norte-Sur, Sur-Sur y triangular'),
(160, 17, '17.1', '10', 'Promover un sistema de comercio multilateral universal, basado en normas, abierto, no discriminatorio y equitativo en el marco de la Organización Mundial del Comercio, incluso mediante la conclusión de las negociaciones en el marco del Programa de Doha para el Desarrollo'),
(161, 17, '17.11', '11', 'Aumentar significativamente las exportaciones de los países en desarrollo, en particular con miras a duplicar la participación de los países menos adelantados en las exportaciones mundiales de aquí a 2020'),
(162, 17, '17.12', '12', 'Lograr la consecución oportuna del acceso a los mercados libre de derechos y contingentes de manera duradera para todos los países menos adelantados, conforme a las decisiones de la Organización Mundial del Comercio, incluso velando por que las normas de origen preferenciales aplicables a las importaciones de los países menos adelantados sean transparentes y sencillas y contribuyan a facilitar el acceso a los mercados'),
(163, 17, '17.13', '13', 'Aumentar la estabilidad macroeconómica mundial, incluso mediante la coordinación y coherencia de las políticas'),
(164, 17, '17.14', '14', 'Mejorar la coherencia de las políticas para el desarrollo sostenible'),
(165, 17, '17.15', '15', 'Respetar el margen normativo y el liderazgo de cada país para establecer y aplicar políticas de erradicación de la pobreza y desarrollo sostenible'),
(166, 17, '17.16', '16', 'Mejorar la Alianza Mundial para el Desarrollo Sostenible, complementada por alianzas entre múltiples interesados que movilicen e intercambien conocimientos, especialización, tecnología y recursos financieros, a fin de apoyar el logro de los Objetivos de Desarrollo Sostenible en todos los países, particularmente los países en desarrollo'),
(167, 17, '17.17', '17', 'Fomentar y promover la constitución de alianzas eficaces en las esferas pública, público-privada y de la sociedad civil, aprovechando la experiencia y las estrategias de obtención de recursos de las alianzas'),
(168, 17, '17.18', '18', 'De aquí a 2020, mejorar el apoyo a la creación de capacidad prestado a los países en desarrollo, incluidos los países menos adelantados y los pequeños Estados insulares en desarrollo, para aumentar significativamente la disponibilidad de datos oportunos, fiables y de gran calidad desglosados por ingresos, sexo, edad, raza, origen étnico, estatus migratorio, discapacidad, ubicación geográfica y otras características pertinentes en los contextos nacionales'),
(169, 17, '17.19', '19', 'De aquí a 2030, aprovechar las iniciativas existentes para elaborar indicadores que permitan medir los progresos en materia de desarrollo sostenible y complementen el producto interno bruto, y apoyar la creación de capacidad estadística en los países en desarrollo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catOdsObjetivos`
--

CREATE TABLE `pmd_catOdsObjetivos` (
  `idOdsObjetivo` int(11) NOT NULL,
  `OdsObjetivo` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catOdsObjetivos`
--

INSERT INTO `pmd_catOdsObjetivos` (`idOdsObjetivo`, `OdsObjetivo`) VALUES
(1, 'Fin de la pobreza'),
(2, 'Hambre cero'),
(3, 'Salud y bienestar'),
(4, 'Educación de calidad'),
(5, 'Igualdad de género'),
(6, 'Agua limpia y saneamiento'),
(7, 'Energía asequible y no contaminante'),
(8, 'Trabajo decente y crecimiento económico'),
(9, 'Industria, innovación e infraestructura'),
(10, 'Reducción de las desigualdades'),
(11, 'Ciudades y comunidades sostenibles'),
(12, 'Producción y consumo responsable'),
(13, 'Acción por el clima'),
(14, 'Vida submarina'),
(15, 'Vida de ecosistemas terrestres'),
(16, 'Paz, justicia e instituciones sólidas'),
(17, 'Alianzas para lograr los objetivos'),
(18, 'Vida submarina'),
(19, 'Vida de ecosistemas terrestres');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catSectorP`
--

CREATE TABLE `pmd_catSectorP` (
  `idSectorP` int(11) NOT NULL,
  `sector` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catSectorP`
--

INSERT INTO `pmd_catSectorP` (`idSectorP`, `sector`) VALUES
(1, 'Ama de Casa'),
(2, 'Empresarios y/o Comerciante'),
(3, 'Estudiante'),
(4, 'Funcionario Público'),
(5, 'Niñas, Niños y Adolescentes'),
(6, 'Población Abierta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_catUnidadAdmva`
--

CREATE TABLE `pmd_catUnidadAdmva` (
  `idUnidadAdm` int(11) NOT NULL,
  `id_dependencia` int(11) DEFAULT NULL,
  `unidadAdministrativaNue` varchar(11) DEFAULT NULL,
  `unidadAdministrativa` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_catUnidadAdmva`
--

INSERT INTO `pmd_catUnidadAdmva` (`idUnidadAdm`, `id_dependencia`, `unidadAdministrativaNue`, `unidadAdministrativa`) VALUES
(1, 1, '1000', 'Asamblea Municipal'),
(2, 1, '1010', 'Sindicaturas'),
(3, 1, '1020', 'Oficialía Mayor'),
(4, 2, '110', 'Dirección de Giras y\n \n Logística'),
(5, 2, '120', 'Dirección de Atención Telefónica SERVITEL'),
(6, 2, '130', 'Particular'),
(7, 2, '140', 'Secretaria Particular'),
(8, 2, '150', 'SIPPINA'),
(9, 3, '610', 'Dirección General Jurídica'),
(10, 3, '620', 'Dirección de lo Contencioso'),
(11, 3, '630', 'Dirección de la Oficialía del Registro del Estado Familiar'),
(12, 3, '640', 'Dirección de Desarrollo Político'),
(13, 3, '650', 'Dirección de Vinculación Ciudadana'),
(14, 3, '660', 'Dirección de Reglamentos y Espectáculos'),
(15, 3, '670', 'Dirección de Protección Civil, Bomberos y Gestión Integral de Riesgos'),
(16, 3, '680', 'Dirección de Comunicación Social'),
(17, 4, '810', 'Dirección de Catastro'),
(18, 4, '820', 'Dirección de Ingresos'),
(19, 4, '830', 'Dirección de Egresos'),
(20, 4, '840', 'Dirección de Presupuesto y Contabilidad'),
(21, 5, '1910', 'Dirección de Planeación, Evaluación y Proyectos Estratégicos'),
(22, 5, '1920', 'Dirección de Vinculación e Innovación Institucional'),
(23, 6, '410', 'Dirección de Control'),
(24, 6, '420', 'Dirección de Auditoría'),
(25, 6, '430', 'Dirección de Denuncias y Situación Patrimonial'),
(26, 6, '440', 'Dirección de Gestión de la Calidad'),
(27, 6, '450', 'Dirección de Transparencia e Información Pública Gubernamental'),
(28, 6, '460', 'Dirección de Responsabilidades'),
(29, 7, '500', 'Servicios Públicos Municipales'),
(30, 7, '510', 'Dirección de Mercados, Comercio y Abasto'),
(31, 7, '520', 'Dirección de Alumbrado Público'),
(32, 7, '530', 'Dirección de Sanidad Municipal'),
(33, 8, '710', 'Dirección de Obras Públicas'),
(34, 8, '720', 'Dirección de Desarrollo Urbano'),
(35, 8, '730', 'Dirección de Estudios y Proyectos'),
(36, 8, '740', 'Dirección de Vivienda'),
(37, 8, '750', 'Dirección de Centro Histórico'),
(38, 8, '760', 'Dirección de Movilidad'),
(39, 8, '700', 'Dirección Administrativa'),
(40, 9, '910', 'Dirección de Policía Preventiva'),
(41, 9, '920', 'Dirección de Vialidad y Tránsito'),
(42, 9, '930', 'Dirección Administrativo'),
(43, 9, '940', 'Dirección de Prevención del Delito'),
(44, 9, '950', 'Dirección de Planeación y Estadística'),
(45, 10, '1810', 'Dirección de Inspección y Vigilancia Ambiental'),
(46, 10, '1820', 'Dirección de Sustentabilidad de los Recursos Naturales'),
(47, 10, '1830', 'Dirección del Área Técnica de Protección, Sanidad Animal y Control de Especies Animales'),
(48, 11, '210', 'Dirección de Desarrollo Económico'),
(49, 11, '220', 'Dirección de Desarrollo Turístico'),
(50, 11, '230', 'Dirección de Mejora Regulatoria'),
(51, 12, '310', 'Dirección de Servicios Generales'),
(52, 12, '320', 'Dirección de Informática'),
(53, 12, '330', 'Dirección de Compras y Suministros'),
(54, 12, '340', 'Dirección de Recursos Humanos'),
(55, 12, '360', 'Sindicato'),
(56, 12, '370', 'Jubilados'),
(57, 13, '1510', 'Dirección de Desarrollo Social'),
(58, 13, '1520', 'Dirección de Educación'),
(59, 13, '1530', 'Dirección de Salud Municipal'),
(60, 13, '1540', 'Dirección de Personas Adultas Mayores'),
(61, 14, '2210', 'Dirección de Transversalidad de la Perspectiva de Género'),
(62, 14, '2220', 'Dirección de Empoderamiento'),
(63, 14, '2230', 'Dirección de Planeación Estratégica'),
(64, 15, '2300', 'Secretaría de Gestión y Vinculación Internacional'),
(65, 16, '1100', 'Dirección Ejecutiva'),
(66, 16, '1100', 'Coordinación de Servicios Médicos'),
(67, 16, '1100', 'Coordinación de Gestión y Vinculación'),
(68, 16, '1100', 'Coordinación Administrativa'),
(69, 16, '1100', 'Coordinación Jurídica y Procuradora Municipal de Protección de Niñas, Niños, Adolescentes y las Familias'),
(70, 16, '1100', 'Coordinación de Protección a la Infancia y Desarrollo Comunitario'),
(71, 16, '1100', 'Coordinación de Desarrollo Emocional y Familiar'),
(72, 16, '1100', 'Coordinación de Comunicación Social'),
(73, 16, '1100', 'Coordinación Técnica'),
(74, 16, '1100', 'Coordinación de Asistencia Social'),
(75, 17, '1200', 'Dirección General'),
(76, 18, '1600', 'Dirección Ejecutiva'),
(77, 19, '1700', 'Dirección General'),
(78, 21, '1300', 'Dirección del Instituto'),
(79, 22, '1400', 'Dirección General'),
(80, 23, '2000', 'Dirección Ejecutiva'),
(81, 10, '1800', 'Educación ambiental');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_entidad`
--

CREATE TABLE `pmd_entidad` (
  `idEntidad` int(11) NOT NULL,
  `entidad` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_entidad`
--

INSERT INTO `pmd_entidad` (`idEntidad`, `entidad`) VALUES
(1, 'Aguascalientes'),
(2, 'Baja California'),
(3, 'Baja California Sur'),
(4, 'Campeche'),
(5, 'Coahuila de Zaragoza'),
(6, 'Colima'),
(7, 'Chiapas'),
(8, 'Chihuahua'),
(9, 'Ciudad de México'),
(10, 'Durango'),
(11, 'Guanajuato'),
(12, 'Guerrero'),
(13, 'Hidalgo'),
(14, 'Jalisco'),
(15, 'México'),
(16, 'Michoacán de Ocampo'),
(17, 'Morelos'),
(18, 'Nayarit'),
(19, 'Nuevo León'),
(20, 'Oaxaca'),
(21, 'Puebla'),
(22, 'Querétaro'),
(23, 'Quintana Roo'),
(24, 'San Luis Potosí'),
(25, 'Sinaloa'),
(26, 'Sonora'),
(27, 'Tabasco'),
(28, 'Tamaulipas'),
(29, 'Tlaxcala'),
(30, 'Veracruz de Ignacio de la Llave'),
(31, 'Yucatán'),
(32, 'Zacatecas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pmd_municipio`
--

CREATE TABLE `pmd_municipio` (
  `idMunicipio` int(11) NOT NULL,
  `idEntidad` int(11) DEFAULT NULL,
  `municipio` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pmd_municipio`
--

INSERT INTO `pmd_municipio` (`idMunicipio`, `idEntidad`, `municipio`) VALUES
(1, 13, 'Acatlán'),
(2, 13, 'Acaxochitlán'),
(3, 13, 'Actopan'),
(4, 13, 'Agua Blanca de Iturbide'),
(5, 13, 'Ajacuba'),
(6, 13, 'Alfajayucan'),
(7, 13, 'Almoloya'),
(8, 13, 'Apan'),
(9, 13, 'El Arenal'),
(10, 13, 'Atitalaquia'),
(11, 13, 'Atlapexco'),
(12, 13, 'Atotonilco el Grande'),
(13, 13, 'Atotonilco de Tula'),
(14, 13, 'Calnali'),
(15, 13, 'Cardonal'),
(16, 13, 'Cuautepec de Hinojosa'),
(17, 13, 'Chapantongo'),
(18, 13, 'Chapulhuacán'),
(19, 13, 'Chilcuautla'),
(20, 13, 'Eloxochitlán'),
(21, 13, 'Emiliano Zapata'),
(22, 13, 'Epazoyucan'),
(23, 13, 'Francisco I. Madero'),
(24, 13, 'Huasca de Ocampo'),
(25, 13, 'Huautla'),
(26, 13, 'Huazalingo'),
(27, 13, 'Huehuetla'),
(28, 13, 'Huejutla de Reyes'),
(29, 13, 'Huichapan'),
(30, 13, 'Ixmiquilpan'),
(31, 13, 'Jacala de Ledezma'),
(32, 13, 'Jaltocán'),
(33, 13, 'Juárez Hidalgo'),
(34, 13, 'Lolotla'),
(35, 13, 'Metepec'),
(36, 13, 'San Agustín Metzquititlán'),
(37, 13, 'Metztitlán'),
(38, 13, 'Mineral del Chico'),
(39, 13, 'Mineral del Monte'),
(40, 13, 'La Misión'),
(41, 13, 'Mixquiahuala de Juárez'),
(42, 13, 'Molango de Escamilla'),
(43, 13, 'Nicolás Flores'),
(44, 13, 'Nopala de Villagrán'),
(45, 13, 'Omitlán de Juárez'),
(46, 13, 'San Felipe Orizatlán'),
(47, 13, 'Pacula'),
(48, 13, 'Pachuca de Soto'),
(49, 13, 'Pisaflores'),
(50, 13, 'Progreso de Obregón'),
(51, 13, 'Mineral de la Reforma'),
(52, 13, 'San Agustín Tlaxiaca'),
(53, 13, 'San Bartolo Tutotepec'),
(54, 13, 'San Salvador'),
(55, 13, 'Santiago de Anaya'),
(56, 13, 'Santiago Tulantepec de Lugo Guerrero'),
(57, 13, 'Singuilucan'),
(58, 13, 'Tasquillo'),
(59, 13, 'Tecozautla'),
(60, 13, 'Tenango de Doria'),
(61, 13, 'Tepeapulco'),
(62, 13, 'Tepehuacán de Guerrero'),
(63, 13, 'Tepeji del Río de Ocampo'),
(64, 13, 'Tepetitlán'),
(65, 13, 'Tetepango'),
(66, 13, 'Villa de Tezontepec'),
(67, 13, 'Tezontepec de Aldama'),
(68, 13, 'Tianguistengo'),
(69, 13, 'Tizayuca'),
(70, 13, 'Tlahuelilpan'),
(71, 13, 'Tlahuiltepa'),
(72, 13, 'Tlanalapa'),
(73, 13, 'Tlanchinol'),
(74, 13, 'Tlaxcoapan'),
(75, 13, 'Tolcayuca'),
(76, 13, 'Tula de Allende'),
(77, 13, 'Tulancingo de Bravo'),
(78, 13, 'Xochiatipan'),
(79, 13, 'Xochicoatlán'),
(80, 13, 'Yahualica'),
(81, 13, 'Zacualtipán de Ángeles'),
(82, 13, 'Zapotlán de Juárez'),
(83, 13, 'Zempoala'),
(84, 13, 'Zimapán');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `verPmd`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `verPmd` (
`idPmd` int(11)
,`idEje` int(11)
,`eje` varchar(80)
,`cveObjEstrategico` varchar(11)
,`ObjEstrategico` varchar(80)
,`cveObjGeneral` varchar(11)
,`ObjGeneral` varchar(400)
,`cveLineaAccion` varchar(11)
,`lineaAccion` varchar(500)
,`unidadAdministrativaNue` varchar(11)
,`unidadAdministrativa` varchar(254)
,`dependenciaNue` int(11)
,`dependencia` varchar(254)
,`municipio` varchar(254)
,`entidad` varchar(254)
,`pah_GDMI_Clave` varchar(8)
,`pah_GDI_Indicador` varchar(254)
,`pah_GDMT_Clave` varchar(8)
,`pah_GDMT_Numero` int(11)
,`pah_GDMT_Tema` varchar(254)
,`pah_GDM_Modulo` varchar(80)
,`objetivoOdsId` int(11)
,`cveOdsMetas` varchar(8)
,`OdsMeta` mediumtext
,`OdsObjetivo` varchar(254)
,`procCalidad` varchar(350)
,`alineaT` varchar(254)
,`grupoEdad` varchar(254)
,`genero` varchar(254)
,`sector` varchar(254)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `dependenciasPmd`
--
DROP TABLE IF EXISTS `dependenciasPmd`;

CREATE ALGORITHM=UNDEFINED DEFINER=`pachucaw`@`localhost` SQL SECURITY DEFINER VIEW `dependenciasPmd`  AS SELECT `a`.`idPmd` AS `idPmd`, `b`.`unidadAdministrativaNue` AS `unidadAdministrativaNue`, `b`.`unidadAdministrativa` AS `unidadAdministrativa`, `c`.`dependenciaNue` AS `dependenciaNue`, `c`.`dependencia` AS `dependencia` FROM ((`pmd` `a` join `pmd_catUnidadAdmva` `b` on((`a`.`pmd_IdUnidadAdm` = `b`.`idUnidadAdm`))) join `pmd_catDependencias` `c` on((`b`.`id_dependencia` = `c`.`idDependencia`))) ORDER BY `a`.`idPmd` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `ejesPmd`
--
DROP TABLE IF EXISTS `ejesPmd`;

CREATE ALGORITHM=UNDEFINED DEFINER=`pachucaw`@`localhost` SQL SECURITY DEFINER VIEW `ejesPmd`  AS SELECT `a`.`idPmd` AS `idPmd`, `e`.`idEje` AS `idEje`, `e`.`eje` AS `eje`, `d`.`cveObjEstrategico` AS `cveObjEstrategico`, `d`.`ObjEstrategico` AS `ObjEstrategico`, `c`.`cveObjGeneral` AS `cveObjGeneral`, `c`.`ObjGeneral` AS `ObjGeneral`, `b`.`cveLineaAccion` AS `cveLineaAccion`, `b`.`lineaAccion` AS `lineaAccion` FROM ((((`pmd` `a` join `pmd_catLineaAccion` `b` on((`a`.`pmd_idLineaAccion` = `b`.`idLineaAccion`))) join `pmd_catObjGeneral` `c` on((`b`.`objGeneralId` = `c`.`idObjGeneral`))) join `pmd_catObjEstrategicos` `d` on((`c`.`objEstrategicoId` = `d`.`idObjEstrategico`))) join `pmd_catEje` `e` on((`d`.`ejeId` = `e`.`idEje`))) ORDER BY `a`.`idPmd` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `guiaPmd`
--
DROP TABLE IF EXISTS `guiaPmd`;

CREATE ALGORITHM=UNDEFINED DEFINER=`pachucaw`@`localhost` SQL SECURITY DEFINER VIEW `guiaPmd`  AS SELECT `a`.`idPmd` AS `idPmd`, `b`.`pah_GDMI_Clave` AS `pah_GDMI_Clave`, `b`.`pah_GDI_Indicador` AS `pah_GDI_Indicador`, `c`.`pah_GDMT_Clave` AS `pah_GDMT_Clave`, `c`.`pah_GDMT_Numero` AS `pah_GDMT_Numero`, `c`.`pah_GDMT_Tema` AS `pah_GDMT_Tema`, `d`.`pah_GDM_Modulo` AS `pah_GDM_Modulo` FROM (((`pmd` `a` left join `pmd_catGDMI` `b` on((`a`.`pmd_GDMI_Id` = `b`.`pah_GDIM_Id`))) left join `pmd_catGDMT` `c` on((`b`.`pah_GDMT_Id` = `c`.`pah_GDMT_Id`))) left join `pmd_catGDMM` `d` on((`c`.`pah_GDM_Id` = `d`.`pah_GDM_Id`))) ORDER BY `a`.`idPmd` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `municipioPmd`
--
DROP TABLE IF EXISTS `municipioPmd`;

CREATE ALGORITHM=UNDEFINED DEFINER=`pachucaw`@`localhost` SQL SECURITY DEFINER VIEW `municipioPmd`  AS SELECT `a`.`idPmd` AS `idPmd`, `b`.`municipio` AS `municipio`, `c`.`entidad` AS `entidad` FROM ((`pmd` `a` join `pmd_municipio` `b` on((`a`.`pmd_idMunicipio` = `b`.`idMunicipio`))) join `pmd_entidad` `c` on((`b`.`idEntidad` = `c`.`idEntidad`))) ORDER BY `a`.`idPmd` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `odsPmd`
--
DROP TABLE IF EXISTS `odsPmd`;

CREATE ALGORITHM=UNDEFINED DEFINER=`pachucaw`@`localhost` SQL SECURITY DEFINER VIEW `odsPmd`  AS SELECT `a`.`idPmd` AS `idPmd`, `b`.`objetivoOdsId` AS `objetivoOdsId`, `b`.`cveOdsMetas` AS `cveOdsMetas`, `b`.`OdsMeta` AS `OdsMeta`, `c`.`OdsObjetivo` AS `OdsObjetivo` FROM ((`pmd` `a` left join `pmd_catOdsMetas` `b` on((`a`.`pmd_idOdsMetas` = `b`.`idOdsMetas`))) left join `pmd_catOdsObjetivos` `c` on((`b`.`objetivoOdsId` = `c`.`idOdsObjetivo`))) ORDER BY `a`.`idPmd` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `otrosPmd`
--
DROP TABLE IF EXISTS `otrosPmd`;

CREATE ALGORITHM=UNDEFINED DEFINER=`pachucaw`@`localhost` SQL SECURITY DEFINER VIEW `otrosPmd`  AS SELECT `a`.`idPmd` AS `idPmd`, `b`.`procCalidad` AS `procCalidad`, `c`.`alineaT` AS `alineaT`, `d`.`grupoEdad` AS `grupoEdad`, `e`.`genero` AS `genero`, `f`.`sector` AS `sector` FROM (((((`pmd` `a` left join `pmd_catCalidad` `b` on((`a`.`pmd_idCalidad` = `b`.`idCalidad`))) left join `pmd_catAlineaT` `c` on((`a`.`pmd_idAlineaT` = `c`.`IdAlineaT`))) join `pmd_catGrupoEdad` `d` on((`a`.`pmd_idGrupoEdad` = `d`.`idGrupoEdad`))) join `pmd_catGenero` `e` on((`a`.`pmd_idGenero` = `e`.`idGenero`))) join `pmd_catSectorP` `f` on((`a`.`pmd_idSectorP` = `f`.`idSectorP`))) ORDER BY `a`.`idPmd` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `verPmd`
--
DROP TABLE IF EXISTS `verPmd`;

CREATE ALGORITHM=UNDEFINED DEFINER=`pachucaw`@`localhost` SQL SECURITY DEFINER VIEW `verPmd`  AS SELECT `a`.`idPmd` AS `idPmd`, `e`.`idEje` AS `idEje`, `e`.`eje` AS `eje`, `d`.`cveObjEstrategico` AS `cveObjEstrategico`, `d`.`ObjEstrategico` AS `ObjEstrategico`, `c`.`cveObjGeneral` AS `cveObjGeneral`, `c`.`ObjGeneral` AS `ObjGeneral`, `b`.`cveLineaAccion` AS `cveLineaAccion`, `b`.`lineaAccion` AS `lineaAccion`, `b2`.`unidadAdministrativaNue` AS `unidadAdministrativaNue`, `b2`.`unidadAdministrativa` AS `unidadAdministrativa`, `c2`.`dependenciaNue` AS `dependenciaNue`, `c2`.`dependencia` AS `dependencia`, `b3`.`municipio` AS `municipio`, `c3`.`entidad` AS `entidad`, `b4`.`pah_GDMI_Clave` AS `pah_GDMI_Clave`, `b4`.`pah_GDI_Indicador` AS `pah_GDI_Indicador`, `c4`.`pah_GDMT_Clave` AS `pah_GDMT_Clave`, `c4`.`pah_GDMT_Numero` AS `pah_GDMT_Numero`, `c4`.`pah_GDMT_Tema` AS `pah_GDMT_Tema`, `d4`.`pah_GDM_Modulo` AS `pah_GDM_Modulo`, `b5`.`objetivoOdsId` AS `objetivoOdsId`, `b5`.`cveOdsMetas` AS `cveOdsMetas`, `b5`.`OdsMeta` AS `OdsMeta`, `c5`.`OdsObjetivo` AS `OdsObjetivo`, `b6`.`procCalidad` AS `procCalidad`, `c6`.`alineaT` AS `alineaT`, `d6`.`grupoEdad` AS `grupoEdad`, `e6`.`genero` AS `genero`, `f6`.`sector` AS `sector` FROM ((((((((((((((((((`pmd` `a` join `pmd_catLineaAccion` `b` on((`a`.`pmd_idLineaAccion` = `b`.`idLineaAccion`))) join `pmd_catObjGeneral` `c` on((`b`.`objGeneralId` = `c`.`idObjGeneral`))) join `pmd_catObjEstrategicos` `d` on((`c`.`objEstrategicoId` = `d`.`idObjEstrategico`))) join `pmd_catEje` `e` on((`d`.`ejeId` = `e`.`idEje`))) join `pmd_catUnidadAdmva` `b2` on((`a`.`pmd_IdUnidadAdm` = `b2`.`idUnidadAdm`))) join `pmd_catDependencias` `c2` on((`b2`.`id_dependencia` = `c2`.`idDependencia`))) join `pmd_municipio` `b3` on((`a`.`pmd_idMunicipio` = `b3`.`idMunicipio`))) join `pmd_entidad` `c3` on((`b3`.`idEntidad` = `c3`.`idEntidad`))) left join `pmd_catGDMI` `b4` on((`a`.`pmd_GDMI_Id` = `b4`.`pah_GDIM_Id`))) left join `pmd_catGDMT` `c4` on((`b4`.`pah_GDMT_Id` = `c4`.`pah_GDMT_Id`))) left join `pmd_catGDMM` `d4` on((`c4`.`pah_GDM_Id` = `d4`.`pah_GDM_Id`))) left join `pmd_catOdsMetas` `b5` on((`a`.`pmd_idOdsMetas` = `b5`.`idOdsMetas`))) left join `pmd_catOdsObjetivos` `c5` on((`b5`.`objetivoOdsId` = `c5`.`idOdsObjetivo`))) left join `pmd_catCalidad` `b6` on((`a`.`pmd_idCalidad` = `b6`.`idCalidad`))) left join `pmd_catAlineaT` `c6` on((`a`.`pmd_idAlineaT` = `c6`.`IdAlineaT`))) join `pmd_catGrupoEdad` `d6` on((`a`.`pmd_idGrupoEdad` = `d6`.`idGrupoEdad`))) join `pmd_catGenero` `e6` on((`a`.`pmd_idGenero` = `e6`.`idGenero`))) join `pmd_catSectorP` `f6` on((`a`.`pmd_idSectorP` = `f6`.`idSectorP`))) ORDER BY `a`.`idPmd` ASC ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pmd`
--
ALTER TABLE `pmd`
  ADD PRIMARY KEY (`idPmd`),
  ADD KEY `pmd_IdUnidadAdm` (`pmd_IdUnidadAdm`),
  ADD KEY `pmd_idAlineaT` (`pmd_idAlineaT`),
  ADD KEY `pmd_idOdsMetas` (`pmd_idOdsMetas`),
  ADD KEY `pmd_GDMI_Id` (`pmd_GDMI_Id`),
  ADD KEY `pmd_idCalidad` (`pmd_idCalidad`),
  ADD KEY `pmd_idLineaAccion` (`pmd_idLineaAccion`),
  ADD KEY `pmd_idMunicipio` (`pmd_idMunicipio`),
  ADD KEY `pmd_idGrupoEdad` (`pmd_idGrupoEdad`),
  ADD KEY `pmd_idGenero` (`pmd_idGenero`),
  ADD KEY `pmd_idSectorP` (`pmd_idSectorP`);

--
-- Indices de la tabla `pmd_catAlineaT`
--
ALTER TABLE `pmd_catAlineaT`
  ADD PRIMARY KEY (`IdAlineaT`);

--
-- Indices de la tabla `pmd_catCalidad`
--
ALTER TABLE `pmd_catCalidad`
  ADD PRIMARY KEY (`idCalidad`);

--
-- Indices de la tabla `pmd_catDependencias`
--
ALTER TABLE `pmd_catDependencias`
  ADD PRIMARY KEY (`idDependencia`);

--
-- Indices de la tabla `pmd_catEje`
--
ALTER TABLE `pmd_catEje`
  ADD PRIMARY KEY (`idEje`);

--
-- Indices de la tabla `pmd_catGDMI`
--
ALTER TABLE `pmd_catGDMI`
  ADD PRIMARY KEY (`pah_GDIM_Id`),
  ADD KEY `pah_GDMT_Id` (`pah_GDMT_Id`);

--
-- Indices de la tabla `pmd_catGDMM`
--
ALTER TABLE `pmd_catGDMM`
  ADD PRIMARY KEY (`pah_GDM_Id`);

--
-- Indices de la tabla `pmd_catGDMT`
--
ALTER TABLE `pmd_catGDMT`
  ADD PRIMARY KEY (`pah_GDMT_Id`),
  ADD KEY `pah_GDM_Id` (`pah_GDM_Id`);

--
-- Indices de la tabla `pmd_catGenero`
--
ALTER TABLE `pmd_catGenero`
  ADD PRIMARY KEY (`idGenero`);

--
-- Indices de la tabla `pmd_catGrupoEdad`
--
ALTER TABLE `pmd_catGrupoEdad`
  ADD PRIMARY KEY (`idGrupoEdad`);

--
-- Indices de la tabla `pmd_catLineaAccion`
--
ALTER TABLE `pmd_catLineaAccion`
  ADD PRIMARY KEY (`idLineaAccion`),
  ADD KEY `objGeneralId` (`objGeneralId`);

--
-- Indices de la tabla `pmd_catObjEstrategicos`
--
ALTER TABLE `pmd_catObjEstrategicos`
  ADD PRIMARY KEY (`idObjEstrategico`),
  ADD KEY `ejeId` (`ejeId`);

--
-- Indices de la tabla `pmd_catObjGeneral`
--
ALTER TABLE `pmd_catObjGeneral`
  ADD PRIMARY KEY (`idObjGeneral`),
  ADD KEY `objEstrategicoId` (`objEstrategicoId`);

--
-- Indices de la tabla `pmd_catOdsMetas`
--
ALTER TABLE `pmd_catOdsMetas`
  ADD PRIMARY KEY (`idOdsMetas`),
  ADD KEY `objetivoOdsId` (`objetivoOdsId`);

--
-- Indices de la tabla `pmd_catOdsObjetivos`
--
ALTER TABLE `pmd_catOdsObjetivos`
  ADD PRIMARY KEY (`idOdsObjetivo`);

--
-- Indices de la tabla `pmd_catSectorP`
--
ALTER TABLE `pmd_catSectorP`
  ADD PRIMARY KEY (`idSectorP`);

--
-- Indices de la tabla `pmd_catUnidadAdmva`
--
ALTER TABLE `pmd_catUnidadAdmva`
  ADD PRIMARY KEY (`idUnidadAdm`),
  ADD KEY `id_dependencia` (`id_dependencia`);

--
-- Indices de la tabla `pmd_entidad`
--
ALTER TABLE `pmd_entidad`
  ADD PRIMARY KEY (`idEntidad`);

--
-- Indices de la tabla `pmd_municipio`
--
ALTER TABLE `pmd_municipio`
  ADD PRIMARY KEY (`idMunicipio`),
  ADD KEY `idEntidad` (`idEntidad`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pmd`
--
ALTER TABLE `pmd`
  MODIFY `idPmd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=476;

--
-- AUTO_INCREMENT de la tabla `pmd_catAlineaT`
--
ALTER TABLE `pmd_catAlineaT`
  MODIFY `IdAlineaT` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `pmd_catCalidad`
--
ALTER TABLE `pmd_catCalidad`
  MODIFY `idCalidad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `pmd_catDependencias`
--
ALTER TABLE `pmd_catDependencias`
  MODIFY `idDependencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `pmd_catEje`
--
ALTER TABLE `pmd_catEje`
  MODIFY `idEje` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `pmd_catGDMI`
--
ALTER TABLE `pmd_catGDMI`
  MODIFY `pah_GDIM_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT de la tabla `pmd_catGDMM`
--
ALTER TABLE `pmd_catGDMM`
  MODIFY `pah_GDM_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `pmd_catGDMT`
--
ALTER TABLE `pmd_catGDMT`
  MODIFY `pah_GDMT_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `pmd_catGenero`
--
ALTER TABLE `pmd_catGenero`
  MODIFY `idGenero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `pmd_catGrupoEdad`
--
ALTER TABLE `pmd_catGrupoEdad`
  MODIFY `idGrupoEdad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `pmd_catLineaAccion`
--
ALTER TABLE `pmd_catLineaAccion`
  MODIFY `idLineaAccion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=286;

--
-- AUTO_INCREMENT de la tabla `pmd_catObjEstrategicos`
--
ALTER TABLE `pmd_catObjEstrategicos`
  MODIFY `idObjEstrategico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `pmd_catObjGeneral`
--
ALTER TABLE `pmd_catObjGeneral`
  MODIFY `idObjGeneral` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de la tabla `pmd_catOdsMetas`
--
ALTER TABLE `pmd_catOdsMetas`
  MODIFY `idOdsMetas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=170;

--
-- AUTO_INCREMENT de la tabla `pmd_catOdsObjetivos`
--
ALTER TABLE `pmd_catOdsObjetivos`
  MODIFY `idOdsObjetivo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `pmd_catSectorP`
--
ALTER TABLE `pmd_catSectorP`
  MODIFY `idSectorP` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `pmd_catUnidadAdmva`
--
ALTER TABLE `pmd_catUnidadAdmva`
  MODIFY `idUnidadAdm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT de la tabla `pmd_entidad`
--
ALTER TABLE `pmd_entidad`
  MODIFY `idEntidad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `pmd_municipio`
--
ALTER TABLE `pmd_municipio`
  MODIFY `idMunicipio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pmd`
--
ALTER TABLE `pmd`
  ADD CONSTRAINT `pmd_ibfk_1` FOREIGN KEY (`pmd_IdUnidadAdm`) REFERENCES `pmd_catUnidadAdmva` (`idUnidadAdm`),
  ADD CONSTRAINT `pmd_ibfk_10` FOREIGN KEY (`pmd_idSectorP`) REFERENCES `pmd_catSectorP` (`idSectorP`),
  ADD CONSTRAINT `pmd_ibfk_2` FOREIGN KEY (`pmd_idAlineaT`) REFERENCES `pmd_catAlineaT` (`IdAlineaT`),
  ADD CONSTRAINT `pmd_ibfk_3` FOREIGN KEY (`pmd_idOdsMetas`) REFERENCES `pmd_catOdsMetas` (`idOdsMetas`),
  ADD CONSTRAINT `pmd_ibfk_4` FOREIGN KEY (`pmd_GDMI_Id`) REFERENCES `pmd_catGDMI` (`pah_GDIM_Id`),
  ADD CONSTRAINT `pmd_ibfk_5` FOREIGN KEY (`pmd_idCalidad`) REFERENCES `pmd_catCalidad` (`idCalidad`),
  ADD CONSTRAINT `pmd_ibfk_6` FOREIGN KEY (`pmd_idLineaAccion`) REFERENCES `pmd_catLineaAccion` (`idLineaAccion`),
  ADD CONSTRAINT `pmd_ibfk_7` FOREIGN KEY (`pmd_idMunicipio`) REFERENCES `pmd_municipio` (`idMunicipio`),
  ADD CONSTRAINT `pmd_ibfk_8` FOREIGN KEY (`pmd_idGrupoEdad`) REFERENCES `pmd_catGrupoEdad` (`idGrupoEdad`),
  ADD CONSTRAINT `pmd_ibfk_9` FOREIGN KEY (`pmd_idGenero`) REFERENCES `pmd_catGenero` (`idGenero`);

--
-- Filtros para la tabla `pmd_catGDMI`
--
ALTER TABLE `pmd_catGDMI`
  ADD CONSTRAINT `pmd_catGDMI_ibfk_1` FOREIGN KEY (`pah_GDMT_Id`) REFERENCES `pmd_catGDMT` (`pah_GDMT_Id`);

--
-- Filtros para la tabla `pmd_catGDMT`
--
ALTER TABLE `pmd_catGDMT`
  ADD CONSTRAINT `pmd_catGDMT_ibfk_1` FOREIGN KEY (`pah_GDM_Id`) REFERENCES `pmd_catGDMM` (`pah_GDM_Id`);

--
-- Filtros para la tabla `pmd_catLineaAccion`
--
ALTER TABLE `pmd_catLineaAccion`
  ADD CONSTRAINT `pmd_catLineaAccion_ibfk_1` FOREIGN KEY (`objGeneralId`) REFERENCES `pmd_catObjGeneral` (`idObjGeneral`);

--
-- Filtros para la tabla `pmd_catObjEstrategicos`
--
ALTER TABLE `pmd_catObjEstrategicos`
  ADD CONSTRAINT `pmd_catObjEstrategicos_ibfk_1` FOREIGN KEY (`ejeId`) REFERENCES `pmd_catEje` (`idEje`);

--
-- Filtros para la tabla `pmd_catObjGeneral`
--
ALTER TABLE `pmd_catObjGeneral`
  ADD CONSTRAINT `pmd_catObjGeneral_ibfk_1` FOREIGN KEY (`objEstrategicoId`) REFERENCES `pmd_catObjEstrategicos` (`idObjEstrategico`);

--
-- Filtros para la tabla `pmd_catOdsMetas`
--
ALTER TABLE `pmd_catOdsMetas`
  ADD CONSTRAINT `pmd_catOdsMetas_ibfk_1` FOREIGN KEY (`objetivoOdsId`) REFERENCES `pmd_catOdsObjetivos` (`idOdsObjetivo`);

--
-- Filtros para la tabla `pmd_catUnidadAdmva`
--
ALTER TABLE `pmd_catUnidadAdmva`
  ADD CONSTRAINT `pmd_catUnidadAdmva_ibfk_1` FOREIGN KEY (`id_dependencia`) REFERENCES `pmd_catDependencias` (`idDependencia`);

--
-- Filtros para la tabla `pmd_municipio`
--
ALTER TABLE `pmd_municipio`
  ADD CONSTRAINT `pmd_municipio_ibfk_1` FOREIGN KEY (`idEntidad`) REFERENCES `pmd_entidad` (`idEntidad`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

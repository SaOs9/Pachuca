<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catunidadadmva';
$error = '';

$stmt_dep = $conn->prepare("SELECT * FROM pmd_catdependencias");
$stmt_dep->execute();

if($_POST){
	$id_dependencia = trim($_POST['id_dependencia']);
	$unidadAdministrativaNue = trim($_POST['unidadAdministrativaNue']);
	$unidadAdministrativa = trim($_POST['unidadAdministrativa']);

	if(empty($unidadAdministrativaNue) || empty($unidadAdministrativa)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("INSERT INTO pmd_catunidadadmva (id_dependencia,unidadAdministrativaNue,unidadAdministrativa) VALUES (:id_dependencia,:unidadAdministrativaNue,:unidadAdministrativa)");
		$stmt->execute([
			':id_dependencia' => $id_dependencia,
			':unidadAdministrativaNue' => $unidadAdministrativaNue,
			':unidadAdministrativa' => $unidadAdministrativa,
		]);
		header('Location: l_catunidadadmva?msg='.urlencode('Registro creado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">Unidad Administrativa</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Crear Nueva Unidad Administrativa</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="id_dependencia" name="id_dependencia">
								<option value="">Seleccionar</option>
								<?php while($row_dep = $stmt_dep->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_dep->idDependencia ?>">
										<?php echo $row_dep->dependencia ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="id_dependencia">Dependencia</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="unidadAdministrativaNue" name="unidadAdministrativaNue" placeholder="Nue">
							<label for="unidadAdministrativaNue">Nue</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="unidadAdministrativa" name="unidadAdministrativa" placeholder="Unidad administrativa">
							<label for="unidadAdministrativa">Unidad administrativa</label>
						</div>
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catgdmt';
$error = '';

if(isset($_GET['pah_GDMT_Id'])){
	$pah_GDMT_Id = $_GET['pah_GDMT_Id'];

	$stmt = $conn->prepare("SELECT * FROM pmd_catgdmt WHERE pah_GDMT_Id = :pah_GDMT_Id");
	$stmt->execute([
		':pah_GDMT_Id' => $pah_GDMT_Id
	]);
	
	if($stmt->rowCount() > 0){
		$row = $stmt->fetch(PDO::FETCH_OBJ);

		$stmt_gdmm = $conn->prepare("SELECT * FROM pmd_catgdmm");
		$stmt_gdmm->execute();
	}else{
		header('Location: l_catgdmt');
	}
}else{
	header('Location: l_catgdmt');
}

if($_POST){
	$pah_GDM_Id = trim($_POST['pah_GDM_Id']);
	$pah_GDMT_Clave = trim($_POST['pah_GDMT_Clave']);
	$pah_GDMT_Numero = trim($_POST['pah_GDMT_Numero']);
	$pah_GDMT_Tema = trim($_POST['pah_GDMT_Tema']);

	if(empty($pah_GDM_Id) || empty($pah_GDMT_Clave) || empty($pah_GDMT_Numero) || empty($pah_GDMT_Tema)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("UPDATE pmd_catgdmt SET pah_GDM_Id = :pah_GDM_Id,pah_GDMT_Clave = :pah_GDMT_Clave,pah_GDMT_Numero = :pah_GDMT_Numero,pah_GDMT_Tema = :pah_GDMT_Tema WHERE pah_GDMT_Id = :pah_GDMT_Id");
		$stmt->execute([
			':pah_GDM_Id' => $pah_GDM_Id,
			':pah_GDMT_Clave' => $pah_GDMT_Clave,
			':pah_GDMT_Numero' => $pah_GDMT_Numero,
			':pah_GDMT_Tema' => $pah_GDMT_Tema,
			':pah_GDMT_Id' => $pah_GDMT_Id
		]);
		header('Location: l_catgdmt?msg='.urlencode('Registro creado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">GDMT</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Editar GDMT</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pah_GDM_Id" name="pah_GDM_Id">
								<option value="">Seleccionar</option>
								<?php while($row_gdmm = $stmt_gdmm->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_gdmm->pah_GDM_Id ?>" <?php echo $row_gdmm->pah_GDM_Id == $row->pah_GDM_Id ? 'selected' : '' ?>>
										<?php echo $row_gdmm->pah_GDM_Modulo ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pah_GDM_Id">Módulo</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="pah_GDMT_Clave" name="pah_GDMT_Clave" placeholder="Clave" value="<?php echo $row->pah_GDMT_Clave ?>">
							<label for="pah_GDMT_Clave">Clave</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="pah_GDMT_Numero" name="pah_GDMT_Numero" placeholder="Número" value="<?php echo $row->pah_GDMT_Numero ?>">
							<label for="pah_GDMT_Numero">Número</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="pah_GDMT_Tema" name="pah_GDMT_Tema" placeholder="Nombre" value="<?php echo $row->pah_GDMT_Tema ?>">
							<label for="pah_GDMT_Tema">Tema</label>
						</div>
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse overflow-auto">
	<div class="position-sticky pt-3">
		<ul class="nav flex-column">
			<li class="nav-item">
				<a class="nav-link <?php echo ($menu == 'index') ? 'active' : '' ?>" href="index">
					<i class="fa fa-home"></i>
					Inicio
				</a>
			</li>

			<hr>
			<li class="nav-item">
				<a class="nav-link <?php echo ($menu == 'pmd') ? 'active' : '' ?>" href="l_pmd">
					<i class="fa fa-arrow-left"></i>
					PMD
				</a>
			</li>
			<hr>
			<li class="nav-item">
				<a class="nav-link" href="#">
					<i class="fa fa-arrow-right"></i>
					<i class="fa fa-arrow-right"></i>
					Catalogo de Dependencias y unidades administrativas
				</a>
			</li>
			
			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catdependencias') ? 'active' : '' ?>" href="l_catdependencias">
					<i class="fa fa-check"></i>
					Dependencias
				</a>
			</li>
			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catunidadadmva') ? 'active' : '' ?>" href="l_catunidadadmva">
					<i class="fa fa-check"></i>
					Unidad administrativa
				</a>
			</li>
			
			<hr>
			<li class="nav-item">
				<a class="nav-link" href="#">
					<i class="fa fa-arrow-right"></i>
					<i class="fa fa-arrow-right"></i>
					Catalogo de PMD (Plan municipal de desarrollo)
				</a>
			
			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'cateje') ? 'active' : '' ?>" href="l_cateje">
					<i class="fa fa-check"></i>
					Ejes
				</a>
			</li>		
			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catobjestrategicos') ? 'active' : '' ?>" href="l_catobjestrategicos">
					<i class="fa fa-check"></i>
					Objetivo Estratégico
				</a>
			</li>

			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catobjgeneral') ? 'active' : '' ?>" href="l_catobjgeneral">
					<i class="fa fa-check"></i>
					Objetivo General
				</a>
			</li>

			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catlineaaccion') ? 'active' : '' ?>" href="l_catlineaaccion">
					<i class="fa fa-check"></i>
					Linea de Acción
				</a>
			</li>

			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catalineat') ? 'active' : '' ?>" href="l_catalineat">
					<i class="fa fa-check"></i>
					AlineaT
				</a>
			</li>

			<hr>
			<li class="nav-item">
				<a class="nav-link" href="#">
					<i class="fa fa-arrow-right"></i>
					<i class="fa fa-arrow-right"></i>
					Catalogo de Entidad y Municipio
				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link <?php echo ($menu == 'entidad') ? 'active' : '' ?>" href="l_entidad">
				<i class="fa fa-check"></i>
					Entidad
				</a>
			</li>

			<li class="nav-item">
				<a class="nav-link <?php echo ($menu == 'municipio') ? 'active' : '' ?>" href="l_municipio">
					<i class="fa fa-check"></i>
					Municipio
            </a>

			<hr>
			<li class="nav-item">
				<a class="nav-link" href="#">
					<i class="fa fa-arrow-right"></i>
					<i class="fa fa-arrow-right"></i>
					Catalogo de ODS (Objetivo de Desarrollo Sustentable)
				</a>
			</li>
			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catodsobjetivos') ? 'active' : '' ?>" href="l_catodsobjetivos">
					<i class="fa fa-check"></i>
					Objetivos
				</a>
			</li>
			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catodsmetas') ? 'active' : '' ?>" href="l_catodsmetas">
					<i class="fa fa-check"></i>
					Metas
				</a>
			</li>
			
			<hr>
			<li class="nav-item">
				<a class="nav-link" href="#">
					<i class="fa fa-arrow-right"></i>
					<i class="fa fa-arrow-right"></i>
					Catalogo de GSDM (Guía consultiva de desempeño municipal)
				</a>
			</li>

			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catgdmm') ? 'active' : '' ?>" href="l_catgdmm">
					<i class="fa fa-check"></i>
					GDM - Módulos
				</a>
			</li>

			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catgdmt') ? 'active' : '' ?>" href="l_catgdmt">
					<i class="fa fa-check"></i>
					GDM - Temas
				</a>
			</li>

			<li class="nav-item">
				<a class="ms-2 nav-link <?php echo ($menu == 'catgdmi') ? 'active' : '' ?>" href="l_catgdmi">
					<i class="fa fa-check"></i>
					GDM - Indicadores
				</a>
			</li>
			
			<hr>
			<li class="nav-item">
				<a class="nav-link <?php echo ($menu == 'catcalidad') ? 'active' : '' ?>" href="l_catcalidad">
					<i class="fa fa-arrow-right"></i>
					Catalogo de Calidad
				</a>
			</li>
			
			<hr>
			<li class="nav-item">
				<a class="nav-link <?php echo ($menu == 'catsectorp') ? 'active' : '' ?>" href="l_catsectorp">
					<i class="fa fa-arrow-right"></i>
					Catalogo de Sector
				</a>
			</li>
	
			<hr>
			<li class="nav-item">
				<a class="nav-link <?php echo ($menu == 'catgrupoedad') ? 'active' : '' ?>" href="l_catgrupoedad">
					<i class="fa fa-arrow-right"></i>
					Catalogo de Grupo de edad
				</a>
			</li>

			<hr>
			<li class="nav-item">
				<a class="nav-link <?php echo ($menu == 'catgenero') ? 'active' : '' ?>" href="l_catgenero">
					<i class="fa fa-arrow-right"></i>
					Catalogo de Genero
				</a>
			</li>

			</li>
			
		</ul>
	</div>
</nav>
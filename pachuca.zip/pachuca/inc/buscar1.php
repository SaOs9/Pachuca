<div class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow" >

  <!--<form id="sender">-->
  <input id="bs" name="bs" class="form-control form-control-dark w-auto" type="text" placeholder="Buscar" autocomplete="off">
  <!--<input id="busca" class="bus" type="submit" value="Buscar">-->
<!--</form>-->

</div>
<script src="./assets/js/bootstrap.bundle.min.js"></script>
<script src="./assets/js/jquery-3.6.0.min.js"></script>
<script src="./assets/js/datatables.min.js"></script>
<script>
$(document).on("click","#bs", function (e) { 
	id=this.id;
	//e.preventDefault();
	var tipo = $('.tipo').attr("id");
	this.addEventListener("keyup", function () {
	$(".datos").html('');
	var fo = new FormData();
	var b=$('#bs').val();
	fo.append("bs",b);
	fo.append("tipo",tipo);
	if (b.length > 4 ) { 
		$.ajax({
		url: "./buscar.php",
		type: "POST",
		data: fo,
		async: true,
		cache: false,
		contentType: false,
		processData: false,
		success: (res) => {
        procesa(res)
	  },
	});
	}else if(b.length < 3){
	$(".datos").html('');	
	}
	})	 
})

function procesa(res){
	var html='';
			var resp = JSON.parse(res);
			item = resp.posts.row;
			$.each(item, (index, value) => { 
			html +=`<tr>
					<td>${value.id}</td>
					<td>${value.unidad}</td>
					<td>${value.alineat}</td>
					<td>${value.meta}</td>
					<td>${value.indicador}</td>
					<td>${value.calidad}</td>
					<td>${value.accion}</td>
					<td>${value.municipio}</td>
					<td>${value.edad}</td>
					<td>${value.genero}</td>
					<td>${value.sector}</td>
					<td>${value.botones}</td>
				</tr>`;
			$(".datos").prepend(html);
			html='';
		})
}
</script>
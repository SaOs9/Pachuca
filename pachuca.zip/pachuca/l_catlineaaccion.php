<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catlineaaccion';

$stmt = $conn->prepare("
	SELECT l.*,g.ObjGeneral
	FROM pmd_catlineaaccion l
	JOIN pmd_catobjgeneral g ON l.objGeneralId = g.idObjGeneral
");
$stmt->execute();

if(isset($_POST['idLineaAccion'])){
	$idLineaAccion = $_POST['idLineaAccion'];
	$stmt = $conn->prepare("DELETE FROM pmd_catlineaaccion WHERE idLineaAccion = :idLineaAccion");
	$stmt->execute([
		':idLineaAccion' => $idLineaAccion
	]);
	header('Location: l_catlineaaccion?msg='.urlencode('Registro eliminado'));
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="./assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">Linea de acción</h1>
				</div>
				<?php if(isset($_GET['msg'])): ?>
				<div class="alert alert-success">
					<i class="fa fa-exclamation-circle"></i> <?php echo $_GET['msg'] ?>
				</div>
				<?php endif; ?>
				<a href="c_catlineaaccion" class="btn btn-dark mb-4">
					<i class="fa fa-plus"></i> Nuevo
				</a>
				<div class="table-responsive">
					<table class="table table-striped align-middle dataTable">
						<thead class="table-dark">
							<tr>
								<th>ID</th>
								<th>Objetivo general</th>
								<th>Clave</th>
								<th>Linea de acción</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php while($row = $stmt->fetch(PDO::FETCH_OBJ)): ?>
							<tr>
								<td><?php echo $row->idLineaAccion ?></td>
								<td><?php echo $row->ObjGeneral ?></td>
								<td><?php echo $row->cveLineaAccion ?></td>
								<td><?php echo $row->lineaAccion ?></td>
								<td>
									<div class="d-flex gap-2">
										<a href="e_catlineaaccion?idLineaAccion=<?php echo $row->idLineaAccion ?>" class="btn btn-dark btn-sm"><i class="fa fa-pencil"></i></a>
										<form method="POST">
											<input type="hidden" name="idLineaAccion" value="<?php echo $row->idLineaAccion ?>">
											<button class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar?')"><i class="fa fa-trash-alt"></i></button>
										</form>
									</div>
								</td>
							</tr>
							<?php endwhile; ?>
						</tbody>
					</table>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
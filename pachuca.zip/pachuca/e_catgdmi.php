<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catgdmi';
$error = '';

if(isset($_GET['pah_GDIM_Id'])){
	$pah_GDIM_Id = $_GET['pah_GDIM_Id'];

	$stmt = $conn->prepare("SELECT * FROM pmd_catgdmi WHERE pah_GDIM_Id = :pah_GDIM_Id");
	$stmt->execute([
		':pah_GDIM_Id' => $pah_GDIM_Id
	]);
	
	if($stmt->rowCount() > 0){
		$row = $stmt->fetch(PDO::FETCH_OBJ);

		$stmt_gdmt = $conn->prepare("SELECT * FROM pmd_catgdmt");
		$stmt_gdmt->execute();
	}else{
		header('Location: l_catgdmi');
	}
}else{
	header('Location: l_catgdmi');
}

if($_POST){
	$pah_GDMT_Id = trim($_POST['pah_GDMT_Id']);
	$pah_GDMI_Numero = trim($_POST['pah_GDMI_Numero']);
	$pah_GDMI_Clave = trim($_POST['pah_GDMI_Clave']);
	$pah_GDI_Indicador = trim($_POST['pah_GDI_Indicador']);

	if(empty($pah_GDMT_Id) || empty($pah_GDMI_Numero) || empty($pah_GDMI_Clave) || empty($pah_GDI_Indicador)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("UPDATE pmd_catgdmi SET pah_GDMT_Id = :pah_GDMT_Id, pah_GDMI_Numero = :pah_GDMI_Numero, pah_GDMI_Clave = :pah_GDMI_Clave, pah_GDI_Indicador = :pah_GDI_Indicador WHERE pah_GDIM_Id = :pah_GDIM_Id");
		$stmt->execute([
			':pah_GDMT_Id' => $pah_GDMT_Id,
			':pah_GDMI_Numero' => $pah_GDMI_Numero,
			':pah_GDMI_Clave' => $pah_GDMI_Clave,
			':pah_GDI_Indicador' => $pah_GDI_Indicador,
			':pah_GDIM_Id' => $pah_GDIM_Id
		]);
		header('Location: l_catgdmi?msg='.urlencode('Registro actualizado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">GDMI</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Editar GDMI</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="pah_GDMT_Id" name="pah_GDMT_Id">
								<option value="">Seleccionar</option>
								<?php while($row_gdmt = $stmt_gdmt->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_gdmt->pah_GDMT_Id ?>"
										<?php echo $row_gdmt->pah_GDMT_Id == $row->pah_GDMT_Id ? 'selected' : '' ?>>
										<?php echo $row_gdmt->pah_GDMT_Tema ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="pah_GDMT_Id">Tema</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="pah_GDMI_Numero" name="pah_GDMI_Numero" placeholder="Número" value="<?php echo $row->pah_GDMI_Numero ?>">
							<label for="pah_GDMI_Numero">Número</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="pah_GDMI_Clave" name="pah_GDMI_Clave" placeholder="Clave" value="<?php echo $row->pah_GDMI_Clave ?>">
							<label for="pah_GDMI_Clave">Clave</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="pah_GDI_Indicador" name="pah_GDI_Indicador" placeholder="Indicador" value="<?php echo $row->pah_GDI_Indicador ?>">
							<label for="pah_GDI_Indicador">Indicador</label>
						</div>
						
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
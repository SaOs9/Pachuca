<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catlineaaccion';
$error = '';

if(isset($_GET['idLineaAccion'])){
	$idLineaAccion = $_GET['idLineaAccion'];
	$stmt = $conn->prepare("SELECT * FROM pmd_catlineaaccion WHERE idLineaAccion = :idLineaAccion");
	$stmt->execute([
		':idLineaAccion' => $idLineaAccion
	]);

	if($stmt->rowCount() > 0){
		$row = $stmt->fetch(PDO::FETCH_OBJ);

		$stmt_obj = $conn->prepare("SELECT * FROM pmd_catobjgeneral");
		$stmt_obj->execute();
	}else{
		header('Location: l_catlineaaccion');
	}
}else{
	header('Location: l_catlineaaccion');
}

if($_POST){
	$objGeneralId = trim($_POST['objGeneralId']);
	$cveLineaAccion = trim($_POST['cveLineaAccion']);
	$lineaAccion = trim($_POST['lineaAccion']);

	if(empty($objGeneralId) || empty($cveLineaAccion) || empty($lineaAccion)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("UPDATE pmd_catlineaaccion SET objGeneralId = :objGeneralId, cveLineaAccion = :cveLineaAccion, lineaAccion = :lineaAccion WHERE idLineaAccion = :idLineaAccion");
		$stmt->execute([
			':objGeneralId' => $objGeneralId,
			':cveLineaAccion' => $cveLineaAccion,
			':lineaAccion' => $lineaAccion,
			':idLineaAccion' => $idLineaAccion
		]);
		header('Location: l_catlineaaccion?msg='.urlencode('Registro actualizado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">Linea de acción</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Editar linea de acción</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="objGeneralId" name="objGeneralId">
								<option value="">Seleccionar</option>
								<?php while($row_obj = $stmt_obj->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_obj->idObjGeneral  ?>" <?php echo $row_obj->idObjGeneral  == $row->objGeneralId ? 'selected' : '' ?>>
										<?php echo $row_obj->ObjGeneral ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="objGeneralId">Eje</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="cveLineaAccion" name="cveLineaAccion" placeholder="Clave" value="<?php echo $row->cveLineaAccion ?>">
							<label for="cveLineaAccion">Clave</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="lineaAccion" name="lineaAccion" placeholder="Nombre" value="<?php echo $row->lineaAccion ?>">
							<label for="lineaAccion">Nombre</label>
						</div>
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
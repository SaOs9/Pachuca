<?php
require_once './php/connection.php';
require_once './php/security.php';

$menu = 'catodsmetas';
$error = '';

$stmt_obj = $conn->prepare("SELECT * FROM pmd_catodsobjetivos");

$stmt_obj->execute();

if($_POST){
	$objetivoOdsId = trim($_POST['objetivoOdsId']);
	$cveOdsMetas = trim($_POST['cveOdsMetas']);
	$ordenOdsMetas = trim($_POST['ordenOdsMetas']);
	$OdsMeta = trim($_POST['OdsMeta']);

	if(empty($objetivoOdsId) || empty($cveOdsMetas) || empty($ordenOdsMetas) || empty($OdsMeta)){
		$error = 'Todos los campos son requeridos';
	}else{
		$stmt = $conn->prepare("INSERT INTO pmd_catodsmetas (objetivoOdsId,cveOdsMetas,ordenOdsMetas,OdsMeta) VALUES (:objetivoOdsId,:cveOdsMetas,:ordenOdsMetas,:OdsMeta)");
		$stmt->execute([
			':objetivoOdsId' => $objetivoOdsId,
			':cveOdsMetas' => $cveOdsMetas,
			':ordenOdsMetas' => $ordenOdsMetas,
			':OdsMeta' => $OdsMeta
		]);
		header('Location: l_catodsmetas?msg='.urlencode('Registro creado'));
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<?php require_once './inc/head.php' ?>
	<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
	
	<?php require_once './inc/header.php' ?>

	<div class="container-fluid">
		<div class="row">

			<?php require_once './inc/sidebar.php' ?>

			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">Metas</h1>
				</div>
				<div class="col-md-4">
					<h5 class="mb-4">Crear Nueva Meta</h5>
					<?php if(!empty($error)): ?>
					<div class="alert alert-danger">
						<?php echo $error ?>
					</div>
					<?php endif; ?>
					<form method="POST">
						<div class="form-floating mb-3">
							<select type="text" class="form-select" id="objetivoOdsId" name="objetivoOdsId">
								<option value="">Seleccionar</option>
								<?php while($row_obj = $stmt_obj->fetch(PDO::FETCH_OBJ)): ?>
									<option value="<?php echo $row_obj->idOdsObjetivo ?>">
										<?php echo $row_obj->OdsObjetivo ?>		
									</option>
								<?php endwhile; ?>
							</select>
							<label for="objetivoOdsId">Objetivo</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="cveOdsMetas" name="cveOdsMetas" placeholder="Clave">
							<label for="cveOdsMetas">Clave</label>
						</div>
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="ordenOdsMetas" name="ordenOdsMetas" placeholder="Orden">
							<label for="ordenOdsMetas">Orden</label>
						</div>
						
						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="OdsMeta" name="OdsMeta" placeholder="Meta">
							<label for="OdsMeta">Meta</label>
						</div>
						<button type="submit" class="btn btn-dark">
							<i class="fa fa-save"></i> Guardar
						</button>
					</form>
				</div>
			</main>
		</div>
	</div>

	<?php require_once './inc/script.php' ?>
</body>
</html>
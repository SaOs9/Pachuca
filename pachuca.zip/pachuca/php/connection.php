<?php
session_start();

date_default_timezone_set('America/Lima');

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'pachucaw_pmd';

try {
    $dsn = "mysql:host=localhost;dbname=$db_name";
    $conn = new PDO($dsn, $db_user, $db_pass);
} catch (PDOException $e){
    die('Error: '.$e->getMessage());
}
header('Content-Type: text/html; charset=ISO-8859-1');
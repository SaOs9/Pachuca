<?php
require_once './php/connection.php';

if(isset($_SESSION['online'])){
	header('Location: index');
}

$error = '';

if(isset($_POST['usuario']) && isset($_POST['clave'])){
	$usuario = trim($_POST['usuario']);
	$clave = trim($_POST['clave']);

	if(empty($usuario) || empty($clave)){
		$error = 'Todos los campos son requeridos';
	}else{
		$clave = md5($clave);

		$stmt = $conn->prepare("SELECT * FROM usuarios WHERE usuario = :usuario AND clave = :clave");
		
		$stmt->execute([
			':usuario' => $usuario,
			':clave' => $clave
		]);

		if($stmt->rowCount() > 0){
			$row = $stmt->fetch(PDO::FETCH_OBJ);
			$_SESSION['online'] = true;
			$_SESSION['id'] = $row->id;
			$_SESSION['usuario'] = $row->usuario;
			header('Location: index');
		}else{
			$error = 'Usuario o contraseña incorrecta';
		}
	}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Pachuca PMD</title>
	<link rel="stylesheet" href="./assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="./assets/css/sign-in.css">
</head>
<body class="text-center">
	<main class="form-signin">
		<form method="POST">
			<h1 class="h3 mb-3 fw-normal">Ingreso al Sistema</h1>
			<?php if(!empty($error)): ?>
			<div class="alert alert-danger">
				<?php echo $error ?>
			</div>
			<?php endif; ?>
			<div class="form-floating">
				<input type="text" class="form-control" id="usuario" name="usuario" placeholder="Usuario" value="<?php echo isset($_POST['usuario']) ? $_POST['usuario'] : '' ?>">
				<label for="usuario">Usuario</label>
			</div>
			<div class="form-floating">
				<input type="password" class="form-control" id="clave" name="clave" placeholder="Contraseña">
				<label for="clave">Contraseña</label>
			</div>
			<button class="w-100 btn btn-lg btn-dark" type="submit">Ingresar</button>
			<p class="mt-5 mb-3 text-muted">&copy; Pachuca PMD</p>
		</form>
	</main>
</body>
</html>